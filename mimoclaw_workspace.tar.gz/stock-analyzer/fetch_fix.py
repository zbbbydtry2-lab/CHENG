#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""修复版数据采集 - 分步获取，逐个容错"""

import akshare as ak
import json
import os
import time
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

def sf(val, default=0.0):
    try:
        import pandas as pd
        v = float(val)
        return v if pd.notna(v) else default
    except:
        return default

# 读取已有数据
out_path = os.path.join(OUTPUT_DIR, "market_data.json")
existing = {}
if os.path.exists(out_path):
    with open(out_path, "r") as f:
        existing = json.load(f)

print("🚀 修复数据采集...\n")

# ── 1. 指数 ──
print("📊 指数...")
indices = existing.get("market", {}).get("indices", [])
if not indices:
    try:
        df = ak.stock_zh_index_spot_em()
        print(f"  获取到 {len(df)} 条指数数据")
        for code, name in [("000001", "上证指数"), ("399001", "深证成指"), ("399006", "创业板指")]:
            row = df[df["代码"] == code]
            if not row.empty:
                r = row.iloc[0]
                indices.append({
                    "name": name, "code": code,
                    "price": sf(r.get("最新价")),
                    "change_pct": sf(r.get("涨跌幅")),
                    "change_amt": sf(r.get("涨跌额")),
                })
                print(f"  ✅ {name}: {sf(r.get('最新价'))} {sf(r.get('涨跌幅')):+.2f}%")
            else:
                print(f"  ⚠️ {name} 未找到")
        time.sleep(1)
    except Exception as e:
        print(f"  ❌ 指数获取失败: {e}")

# ── 2. 板块资金 ──
print("\n💰 板块资金...")
sectors = existing.get("sectors", [])
if not sectors:
    # 尝试多种方式
    try:
        print("  尝试方式1: stock_sector_fund_flow_rank...")
        df = ak.stock_sector_fund_flow_rank(indicator="今日", sector_type="行业资金流")
        print(f"  获取到 {len(df)} 条板块数据")
        for _, r in df.head(12).iterrows():
            sectors.append({
                "name": str(r.get("名称", "")),
                "change_pct": sf(r.get("今日涨跌幅")),
                "main_net": sf(r.get("今日主力净流入-净额")),
                "main_pct": sf(r.get("今日主力净流入-净占比")),
            })
        time.sleep(1)
    except Exception as e1:
        print(f"  ⚠️ 方式1失败: {e1}")
        try:
            print("  尝试方式2: stock_board_industry_name_em...")
            df = ak.stock_board_industry_name_em()
            print(f"  获取到 {len(df)} 条行业板块")
            for _, r in df.head(12).iterrows():
                sectors.append({
                    "name": str(r.get("板块名称", r.get("名称", ""))),
                    "change_pct": sf(r.get("涨跌幅", 0)),
                    "main_net": sf(r.get("主力净流入-净额", 0)),
                    "main_pct": sf(r.get("主力净流入-净占比", 0)),
                })
        except Exception as e2:
            print(f"  ⚠️ 方式2失败: {e2}")

# ── 3. 北向资金 ──
print("\n🏦 北向资金...")
north_flow = existing.get("market", {}).get("north_flow", 0)
if not north_flow:
    try:
        df = ak.stock_hsgt_north_net_flow_in_em(symbol="北向")
        if not df.empty:
            north_flow = sf(df.iloc[-1].get("当日净流入", 0))
            print(f"  ✅ 北向净流入: {north_flow/1e8:.2f}亿")
    except Exception as e:
        print(f"  ⚠️ 北向获取失败: {e}")
        # 尝试备选
        try:
            df = ak.stock_hsgt_fund_flow_summary_em()
            if not df.empty:
                for _, r in df.iterrows():
                    if "北向" in str(r.get("资金方向", "")):
                        north_flow = sf(r.get("当日净流入", 0))
                        break
        except:
            pass

# ── 4. 补充涨停股行情(量比) ──
print("\n📈 补充涨停股行情...")
limit_up = existing.get("limit_up_stocks", [])
if limit_up and not limit_up[0].get("volume_ratio"):
    try:
        df = ak.stock_zh_a_spot_em()
        for s in limit_up:
            row = df[df["代码"] == s["code"]]
            if not row.empty:
                r = row.iloc[0]
                s["volume_ratio"] = sf(r.get("量比"))
                s["pe"] = sf(r.get("市盈率-动态"))
        print(f"  ✅ 补充了 {len(limit_up)} 只股票的量比数据")
    except Exception as e:
        print(f"  ⚠️ 行情补充失败: {e}")

# ── 5. 北向资金(尝试另一种方式) ──
if not north_flow:
    print("\n🏦 北向资金(备选)...")
    try:
        df = ak.stock_hsgt_north_acc_flow_in_em(symbol="北向")
        if not df.empty:
            north_flow = sf(df.iloc[-1].get("当日净流入", df.iloc[-1].values[-1]))
            print(f"  ✅ 北向: {north_flow/1e8:.2f}亿")
    except Exception as e:
        print(f"  ⚠️ 备选失败: {e}")

# ── 组装数据 ──
market = existing.get("market", {})
market["indices"] = indices
market["north_flow"] = north_flow

data = {
    "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "market": market,
    "limit_up_stocks": limit_up,
    "sectors": sectors,
    "recommendations": limit_up[:3] if limit_up else existing.get("recommendations", []),
}

with open(out_path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

# 同步到 canvas
import shutil
canvas_dir = os.path.expanduser("~/.openclaw/canvas/stock-analyzer")
os.makedirs(os.path.join(canvas_dir, "data"), exist_ok=True)
shutil.copy2(out_path, os.path.join(canvas_dir, "data", "market_data.json"))

print(f"\n{'='*50}")
print(f"✅ 数据修复完成!")
print(f"  指数: {len(indices)} 条")
print(f"  涨停: {market.get('limit_up_count', 0)} 家")
print(f"  板块: {len(sectors)} 条")
print(f"  北向: {north_flow/1e8:.2f}亿" if north_flow else "  北向: 未获取")
print(f"  推荐: {', '.join(s['name'] for s in data['recommendations'])}")
print(f"{'='*50}")
