#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
波段智能选股引擎 v3.0
功能:
1. 实时扫描全A股
2. 剔除ST、*ST、阴跌股
3. 结合政策/产业/市场热点
4. 判断题材强度、板块扩散
5. 个股相对强弱排序
6. 输出波段推荐标的
"""

import akshare as ak
import pandas as pd
import numpy as np
import json
import os
import time
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def sf(val, default=0.0):
    try:
        v = float(val)
        return v if pd.notna(v) else default
    except:
        return default


def safe_get(func, *args, retries=2, delay=3, **kwargs):
    for i in range(retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if i < retries - 1:
                time.sleep(delay)
            else:
                print(f"  ⚠️ {func.__name__} 失败: {e}")
                return None


# ── 1. 获取全量A股实时行情 ──
def fetch_all_stocks():
    print("📊 获取全量A股行情...")
    df = safe_get(ak.stock_zh_a_spot_em)
    if df is None:
        return None
    print(f"  获取到 {len(df)} 只股票")
    return df


# ── 2. 获取涨停股(判断热点方向) ──
def fetch_limit_up():
    print("🔴 获取涨停股...")
    try:
        df = safe_get(ak.stock_zt_pool_em, date=datetime.now().strftime("%Y%m%d"))
        if df is not None and not df.empty:
            print(f"  涨停 {len(df)} 家")
            return df
    except:
        pass
    return pd.DataFrame()


# ── 3. 获取板块行情 ──
def fetch_sectors():
    print("💰 获取板块数据...")
    try:
        df = safe_get(ak.stock_board_industry_name_em)
        if df is not None:
            print(f"  获取到 {len(df)} 个板块")
            return df
    except:
        pass
    return pd.DataFrame()


# ── 4. 获取板块资金流 ──
def fetch_sector_flow():
    print("💰 获取板块资金流...")
    try:
        df = safe_get(ak.stock_sector_fund_flow_rank, indicator="今日", sector_type="行业资金流")
        if df is not None:
            return df
    except:
        pass
    return pd.DataFrame()


# ── 核心筛选逻辑 ──

def is_st(name):
    """判断是否ST"""
    if pd.isna(name):
        return True
    name = str(name).upper()
    return 'ST' in name or '*ST' in name or 'S ' in name or name.startswith('S')


def is_yin_die(df, code, days=10, threshold=-0.15):
    """判断是否阴跌: 近N日累计跌幅超过阈值"""
    try:
        # 用实时数据判断: 60日涨跌幅
        row = df[df['代码'] == code]
        if row.empty:
            return False
        r = row.iloc[0]
        pct_60d = sf(r.get('60日涨跌幅', 0))
        pct_20d = sf(r.get('20日涨跌幅', 0))
        # 60日跌超20% 或 20日跌超10% 视为阴跌
        if pct_60d < -20 or pct_20d < -10:
            return True
        return False
    except:
        return False


def calc_ma_bias(close, ma20):
    """计算乖离率"""
    if ma20 <= 0:
        return 999
    return (close - ma20) / ma20 * 100


def score_stock(row, hot_sectors, limit_up_codes):
    """
    综合评分 (0-100)
    """
    score = 0
    name = str(row.get('名称', ''))
    code = str(row.get('代码', ''))
    industry = str(row.get('所属行业', ''))

    # 基础数据
    price = sf(row.get('最新价'))
    pct_1d = sf(row.get('涨跌幅'))
    pct_5d = sf(row.get('5日涨跌幅', 0))
    pct_20d = sf(row.get('20日涨跌幅', 0))
    pct_60d = sf(row.get('60日涨跌幅', 0))
    turnover = sf(row.get('换手率'))
    vol_ratio = sf(row.get('量比'))
    pe = sf(row.get('市盈率-动态'))
    total_mv = sf(row.get('总市值'))
    ma5 = sf(row.get('ma5', 0))
    ma10 = sf(row.get('ma10', 0))
    ma20 = sf(row.get('ma20', 0))

    # ── 排除条件 ──
    # 1. ST
    if is_st(name):
        return -1, "ST股"

    # 2. 价格过低或过高
    if price < 3 or price > 300:
        return -1, "价格异常"

    # 3. 停牌(成交量为0)
    if sf(row.get('成交量', 0)) <= 0:
        return -1, "停牌"

    # 4. 阴跌判断
    if pct_60d < -20:
        return -1, "60日阴跌"
    if pct_20d < -10:
        return -1, "20日阴跌"

    # 5. 当日大跌
    if pct_1d < -5:
        return -1, "当日大跌"

    # 6. 市值过小(流动性差)
    if total_mv > 0 and total_mv < 30e8:
        return -1, "市值过小"

    # ── 评分项 ──

    # 1. 趋势分 (30分) - 多头排列
    if ma5 > 0 and ma10 > 0 and ma20 > 0:
        if ma5 > ma10 > ma20:
            score += 30  # 完美多头
        elif ma5 > ma10:
            score += 20  # 短期多头
        elif price > ma20:
            score += 10  # 站上20日线

    # 2. 回踩分 (20分) - 回踩MA10附近
    if ma10 > 0:
        bias = abs(price - ma10) / ma10 * 100
        if bias < 3:
            score += 20  # 完美回踩
        elif bias < 5:
            score += 15  # 接近回踩
        elif bias < 8:
            score += 8

    # 3. 量能分 (15分) - 换手率适中
    if 3 <= turnover <= 25:
        score += 15
    elif 2 <= turnover <= 30:
        score += 8

    # 4. 量比加分 (10分)
    if vol_ratio > 1.5:
        score += 10
    elif vol_ratio > 1.0:
        score += 5

    # 5. 热点题材加分 (15分)
    for hot in hot_sectors[:5]:
        hot_name = hot.get('name', '')
        if hot_name and (hot_name in industry or hot_name in name):
            score += 15
            break
        elif hot_name and hot_name in str(row.get('所属行业', '')):
            score += 10
            break

    # 6. 涨停关联加分 (10分)
    if code in limit_up_codes:
        score += 10

    # 7. 近期涨幅适中 (不追高)
    if 0 < pct_5d < 8:
        score += 5
    if pct_5d > 15:
        score -= 5  # 近期涨幅过大

    return score, f"趋势{min(30,score)}分"


def scan_swing_stocks():
    """主扫描流程"""
    print("=" * 60)
    print("🚀 波段智能选股引擎 v3.0")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 1. 获取数据
    df = fetch_all_stocks()
    if df is None or df.empty:
        print("❌ 获取行情失败")
        return None

    time.sleep(1)

    # 2. 获取涨停股(判断热点)
    limit_up_df = fetch_limit_up()
    limit_up_codes = set()
    hot_industries = []
    if not limit_up_df.empty:
        limit_up_codes = set(limit_up_df['代码'].astype(str).tolist())
        # 统计涨停行业分布
        if '所属行业' in limit_up_df.columns:
            industry_count = limit_up_df['所属行业'].value_counts().head(10)
            hot_industries = [{'name': k, 'count': v} for k, v in industry_count.items()]
            print(f"\n🔥 今日热点题材:")
            for h in hot_industries[:5]:
                print(f"  {h['name']}: {h['count']}家涨停")

    time.sleep(1)

    # 3. 获取板块资金
    sector_flow = fetch_sector_flow()
    sector_flow_list = []
    if sector_flow is not None and not sector_flow.empty:
        for _, r in sector_flow.head(10).iterrows():
            sector_flow_list.append({
                'name': str(r.get('名称', '')),
                'net': sf(r.get('今日主力净流入-净额', 0)),
            })

    # 4. 全量扫描评分
    print(f"\n📊 扫描 {len(df)} 只股票...")
    results = []
    for idx, row in df.iterrows():
        score, reason = score_stock(row, hot_industries, limit_up_codes)
        if score > 0:
            results.append({
                'code': str(row.get('代码', '')),
                'name': str(row.get('名称', '')),
                'price': sf(row.get('最新价')),
                'pct_1d': sf(row.get('涨跌幅')),
                'pct_5d': sf(row.get('5日涨跌幅', 0)),
                'pct_20d': sf(row.get('20日涨跌幅', 0)),
                'turnover': sf(row.get('换手率')),
                'vol_ratio': sf(row.get('量比')),
                'pe': sf(row.get('市盈率-动态')),
                'total_mv': sf(row.get('总市值')),
                'industry': str(row.get('所属行业', '')),
                'score': score,
            })

    print(f"  通过筛选: {len(results)} 只")

    # 5. 排序
    results.sort(key=lambda x: x['score'], reverse=True)

    # 6. 取前10
    top10 = results[:10]

    print(f"\n🏆 Top 10 波段候选:")
    print(f"{'排名':>4} {'代码':>8} {'名称':>8} {'现价':>8} {'今日%':>7} {'5日%':>7} {'换手%':>7} {'量比':>6} {'行业':>8} {'评分':>5}")
    print("-" * 80)
    for i, s in enumerate(top10):
        print(f"{i+1:>4} {s['code']:>8} {s['name']:>8} {s['price']:>8.2f} {s['pct_1d']:>+7.2f} {s['pct_5d']:>+7.2f} {s['turnover']:>7.2f} {s['vol_ratio']:>6.2f} {s['industry']:>8} {s['score']:>5}")

    # 7. 输出JSON
    output = {
        'update_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'strategy': '波段选股 v3.0',
        'scan_count': len(df),
        'pass_count': len(results),
        'hot_industries': hot_industries,
        'sector_flow': sector_flow_list,
        'limit_up_count': len(limit_up_codes),
        'top10': top10,
        'recommendations': top10[:3],
    }

    out_path = os.path.join(OUTPUT_DIR, "swing_scan.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # 同步到canvas
    import shutil
    canvas_path = os.path.expanduser("~/.openclaw/canvas/stock-analyzer/data/swing_scan.json")
    os.makedirs(os.path.dirname(canvas_path), exist_ok=True)
    shutil.copy2(out_path, canvas_path)

    print(f"\n💾 已保存: {out_path}")
    print("=" * 60)

    return output


if __name__ == "__main__":
    scan_swing_stocks()
