#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
悟道MCP数据采集 - 一键复盘
工具: https://stock.quicktiny.cn/developer
"""

import requests
import json
import os
import time
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

KEY = "lb_1058c2bb2bb21048d4127e6cc038671d273a23868592ddf0746752233ee5d75f"
URL = "https://stock.quicktiny.cn/api/mcp-stream"
HEADERS = {
    "Authorization": f"Bearer {KEY}",
    "Content-Type": "application/json",
    "Accept": "application/json, text/event-stream",
}


def call_tool(name, args=None):
    body = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": name, "arguments": args or {}}}
    try:
        r = requests.post(URL, json=body, headers=HEADERS, timeout=30)
        r.encoding = "utf-8"  # 强制UTF-8编码
        for line in r.text.split("\n"):
            if line.startswith("data: "):
                data = json.loads(line[6:])
                result = data.get("result", {})
                content = result.get("content", [])
                for c in content:
                    if c.get("type") == "text":
                        try:
                            return json.loads(c["text"])
                        except:
                            return c["text"]
    except Exception as e:
        print(f"  ⚠️ {name}: {e}")
    return None


def main():
    print("=" * 60)
    print("🔌 悟道MCP 数据采集")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    data = {"update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

    # 1. 市场概览
    print("\n📊 市场概览...")
    r = call_tool("market_overview")
    if r:
        data["market_overview"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅ {json.dumps(r, ensure_ascii=False)[:100]}")

    # 2. 涨跌停统计
    print("\n📊 涨跌停统计...")
    r = call_tool("limit_stats")
    if r:
        data["limit_stats"] = r
        print(f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 3. 涨停梯队
    print("\n📊 涨停梯队...")
    r = call_tool("limit_up_ladder")
    if r:
        data["limit_up_ladder"] = r
        if isinstance(r, dict):
            for k, v in list(r.items())[:5]:
                print(f"  {k}: {v}")
        else:
            print(f"  {r}")

    # 4. 热门板块
    print("\n📊 热门板块...")
    r = call_tool("hot_sectors")
    if r:
        data["hot_sectors"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 5. 概念排行
    print("\n📊 概念排行...")
    r = call_tool("concept_ranking")
    if r:
        data["concept_ranking"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 6. 龙虎榜
    print("\n📊 龙虎榜...")
    r = call_tool("dragon_tiger")
    if r:
        data["dragon_tiger"] = r
        if isinstance(r, str):
            print(f"  {r[:200]}")
        elif isinstance(r, list):
            for item in r[:3]:
                print(f"  {item}")
        else:
            print(f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 7. 智能热榜
    print("\n📊 智能热榜...")
    r = call_tool("smart_hotlist")
    if r:
        data["smart_hotlist"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 8. 资金流向 (大盘)
    print("\n📊 资金流向...")
    r = call_tool("capital_flow", {"code": "000001"})
    if r:
        data["capital_flow"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 9. 板块分析
    print("\n📊 板块分析...")
    r = call_tool("sector_analysis")
    if r:
        data["sector_analysis"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅ {json.dumps(r, ensure_ascii=False)[:200]}")

    # 10. 一键复盘
    print("\n📊 一键复盘...")
    r = call_tool("market_replay_workflow")
    if r:
        data["market_replay"] = r
        print(f"  {r}" if isinstance(r, str) else f"  ✅")

    # 保存
    out_path = os.path.join(OUTPUT_DIR, "wudao_data.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)

    # 同步canvas
    import shutil
    canvas_path = os.path.expanduser("~/.openclaw/canvas/stock-analyzer/data/wudao_data.json")
    os.makedirs(os.path.dirname(canvas_path), exist_ok=True)
    shutil.copy2(out_path, canvas_path)

    print(f"\n💾 已保存: {out_path}")
    print("=" * 60)
    return data


if __name__ == "__main__":
    main()
