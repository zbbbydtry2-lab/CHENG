#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
波段策略 v1.0 - 200% 盈亏比目标
持股周期: 1-15 天
目标: 每笔盈利 >= 2倍止损幅度 (盈亏比 2:1)

策略逻辑:
1. 趋势确认: MA5 > MA10 > MA20 (多头排列)
2. 回踩买入: 价格回踩 MA10 附近 (偏离 < 3%)
3. 量能确认: 近5日成交量 > 20日均量 (放量)
4. RSI 过滤: RSI(14) 在 40-70 区间 (非超买超卖)
5. 买入: 回踩支撑位买入
6. 止损: 跌破 MA20 或买入价 -5%
7. 止盈: 买入价 +10% (盈亏比 2:1)
8. 时间止损: 持股超过 15 天强制卖出
"""

import akshare as ak
import pandas as pd
import numpy as np
import json
import os
import time
from datetime import datetime, timedelta

# ── 策略参数 ──────────────────────────────────────
MA_SHORT = 5
MA_MID = 10
MA_LONG = 20
RSI_PERIOD = 14
VOL_SHORT = 5
VOL_LONG = 20

BUY_BIAS_MAX = 0.03      # 回踩偏离MA10最大3%
STOP_LOSS_PCT = -0.05     # 止损 -5%
TAKE_PROFIT_PCT = 0.10    # 止盈 +10% (盈亏比 2:1)
MAX_HOLD_DAYS = 15        # 最大持股天数

# 测试股票池 (中大盘流动性好的)
TEST_STOCKS = [
    "000001", "000002", "000063", "000100", "000157",
    "000333", "000538", "000568", "000651", "000725",
    "000768", "000858", "000895", "000938", "000963",
    "002027", "002049", "002120", "002142", "002230",
    "002271", "002304", "002352", "002415", "002460",
    "002475", "002594", "002714", "002812", "002916",
    "300015", "300059", "300122", "300124", "300136",
    "300142", "300347", "300408", "300433", "300496",
    "300529", "300601", "300628", "300750", "300760",
    "600000", "600009", "600016", "600028", "600030",
    "600036", "600048", "600050", "600061", "600085",
    "600104", "600111", "600150", "600176", "600196",
    "600276", "600309", "600340", "600352", "600436",
    "600519", "600585", "600588", "600690", "600703",
    "600809", "600887", "600900", "601012", "601088",
    "601138", "601166", "601169", "601211", "601229",
    "601288", "601318", "601328", "601390", "601398",
    "601601", "601628", "601668", "601688", "601766",
    "601818", "601857", "601888", "601899", "601919",
    "601985", "601988", "601989", "601998", "603259",
    "603288", "603501", "603799", "603833", "603986",
]


def calc_rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def calc_indicators(df):
    df = df.copy()
    df['ma5'] = df['close'].rolling(MA_SHORT).mean()
    df['ma10'] = df['close'].rolling(MA_MID).mean()
    df['ma20'] = df['close'].rolling(MA_LONG).mean()
    df['rsi'] = calc_rsi(df['close'], RSI_PERIOD)
    df['vol_ma5'] = df['volume'].rolling(VOL_SHORT).mean()
    df['vol_ma20'] = df['volume'].rolling(VOL_LONG).mean()
    return df


def check_buy_signal(row, prev_row):
    """检查买入信号 - 多头排列 + 回踩买入"""
    # 1. 多头排列: MA5 > MA10 > MA20 (核心条件)
    if pd.isna(row['ma5']) or pd.isna(row['ma10']) or pd.isna(row['ma20']):
        return False
    if not (row['ma5'] > row['ma10'] > row['ma20']):
        return False

    # 2. 回踩 MA10: 价格接近 MA10 (放宽到 5%)
    bias = (row['close'] - row['ma10']) / row['ma10']
    if bias > 0.05 or bias < -0.03:
        return False

    # 3. RSI 在合理区间 (放宽)
    if pd.isna(row['rsi']) or row['rsi'] < 30 or row['rsi'] > 75:
        return False

    # 4. 量能确认: 近5日均量 > 20日均量的60% (放宽)
    if pd.notna(row['vol_ma5']) and pd.notna(row['vol_ma20']):
        if row['vol_ma20'] > 0 and row['vol_ma5'] < row['vol_ma20'] * 0.6:
            return False

    # 5. 当日非大跌 (跌幅 < 5%)
    if 'pct_change' in row.index and row['pct_change'] < -5:
        return False

    # 6. 价格在 MA20 之上 (趋势向上)
    if row['close'] < row['ma20'] * 0.98:
        return False

    return True


def backtest_stock(code, start_date="20250101", end_date="20260615"):
    """对单只股票进行回测"""
    try:
        # 根据代码判断市场前缀
        if code.startswith(('0', '3')):
            symbol = 'sz' + code
        else:
            symbol = 'sh' + code
        
        df = ak.stock_zh_a_daily(symbol=symbol, start_date=start_date, end_date=end_date, adjust="qfq")
        if df is None or len(df) < 40:
            return None

        # 确保列名正确
        if 'date' not in df.columns:
            df = df.rename(columns={
                '日期': 'date', '开盘': 'open', '收盘': 'close',
                '最高': 'high', '最低': 'low', '成交量': 'volume',
                '涨跌幅': 'pct_change'
            })
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date').reset_index(drop=True)
        
        # 计算涨跌幅(如果没有)
        if 'pct_change' not in df.columns:
            df['pct_change'] = df['close'].pct_change() * 100
        
        df = calc_indicators(df)

        trades = []
        in_position = False
        buy_price = 0
        buy_date = None
        stop_loss = 0
        take_profit = 0

        for i in range(MA_LONG + 5, len(df)):
            row = df.iloc[i]
            prev_row = df.iloc[i - 1]

            if not in_position:
                if check_buy_signal(row, prev_row):
                    buy_price = row['close']
                    buy_date = row['date']
                    stop_loss = buy_price * (1 + STOP_LOSS_PCT)
                    take_profit = buy_price * (1 + TAKE_PROFIT_PCT)
                    in_position = True
            else:
                # 检查卖出条件
                hold_days = (row['date'] - buy_date).days
                sell_reason = None
                sell_price = row['close']

                # 止损
                if row['low'] <= stop_loss:
                    sell_price = stop_loss
                    sell_reason = "止损"
                # 止盈
                elif row['high'] >= take_profit:
                    sell_price = take_profit
                    sell_reason = "止盈"
                # 时间止损
                elif hold_days >= MAX_HOLD_DAYS:
                    sell_reason = "超时"
                # 趋势破坏: 收盘跌破 MA20
                elif pd.notna(row['ma20']) and row['close'] < row['ma20']:
                    sell_reason = "破位"

                if sell_reason:
                    pnl_pct = (sell_price - buy_price) / buy_price
                    trades.append({
                        'code': code,
                        'buy_date': buy_date.strftime('%Y-%m-%d'),
                        'buy_price': round(buy_price, 2),
                        'sell_date': row['date'].strftime('%Y-%m-%d'),
                        'sell_price': round(sell_price, 2),
                        'hold_days': hold_days,
                        'pnl_pct': round(pnl_pct * 100, 2),
                        'reason': sell_reason,
                    })
                    in_position = False

        return trades
    except Exception as e:
        return None


def run_backtest():
    """运行完整回测"""
    print("=" * 60)
    print("🚀 波段策略回测 - 200% 盈亏比目标")
    print(f"📊 策略: 多头排列 + 回踩MA10 + 量能确认")
    print(f"🎯 止损: {STOP_LOSS_PCT*100}% | 止盈: {TAKE_PROFIT_PCT*100}% | 盈亏比: {abs(TAKE_PROFIT_PCT/STOP_LOSS_PCT):.1f}:1")
    print(f"⏱️  持股: 1-{MAX_HOLD_DAYS} 天")
    print(f"📈 测试股票: {len(TEST_STOCKS)} 只")
    print("=" * 60)

    all_trades = []
    stock_stats = []
    success_count = 0
    fail_count = 0

    for i, code in enumerate(TEST_STOCKS):
        print(f"\r  [{i+1}/{len(TEST_STOCKS)}] 回测 {code}...", end="", flush=True)
        trades = backtest_stock(code)
        time.sleep(0.5)  # 限速

        if trades:
            all_trades.extend(trades)
            wins = [t for t in trades if t['pnl_pct'] > 0]
            losses = [t for t in trades if t['pnl_pct'] <= 0]
            win_rate = len(wins) / len(trades) * 100 if trades else 0
            avg_win = np.mean([t['pnl_pct'] for t in wins]) if wins else 0
            avg_loss = np.mean([t['pnl_pct'] for t in losses]) if losses else 0
            total_pnl = sum(t['pnl_pct'] for t in trades)

            stock_stats.append({
                'code': code,
                'trades': len(trades),
                'win_rate': round(win_rate, 1),
                'avg_win': round(avg_win, 2),
                'avg_loss': round(avg_loss, 2),
                'total_pnl': round(total_pnl, 2),
            })
            success_count += 1
        else:
            fail_count += 1

    print("\n")

    # ── 统计汇总 ──
    if not all_trades:
        print("❌ 未产生任何交易信号")
        return None

    wins = [t for t in all_trades if t['pnl_pct'] > 0]
    losses = [t for t in all_trades if t['pnl_pct'] <= 0]
    total = len(all_trades)
    win_count = len(wins)
    loss_count = len(losses)
    win_rate = win_count / total * 100

    avg_win = np.mean([t['pnl_pct'] for t in wins]) if wins else 0
    avg_loss = np.mean([t['pnl_pct'] for t in losses]) if losses else 0
    avg_hold = np.mean([t['hold_days'] for t in all_trades])
    total_pnl = sum(t['pnl_pct'] for t in all_trades)
    avg_pnl = total_pnl / total

    # 盈亏比
    profit_ratio = abs(avg_win / avg_loss) if avg_loss != 0 else float('inf')

    # 最大单笔盈亏
    max_win = max(t['pnl_pct'] for t in all_trades)
    max_loss = min(t['pnl_pct'] for t in all_trades)

    # 连续亏损
    max_consecutive_loss = 0
    current_loss_streak = 0
    for t in all_trades:
        if t['pnl_pct'] <= 0:
            current_loss_streak += 1
            max_consecutive_loss = max(max_consecutive_loss, current_loss_streak)
        else:
            current_loss_streak = 0

    # 按卖出原因统计
    reason_stats = {}
    for t in all_trades:
        r = t['reason']
        if r not in reason_stats:
            reason_stats[r] = {'count': 0, 'pnl': 0, 'wins': 0}
        reason_stats[r]['count'] += 1
        reason_stats[r]['pnl'] += t['pnl_pct']
        if t['pnl_pct'] > 0:
            reason_stats[r]['wins'] += 1

    # ── 输出结果 ──
    print("=" * 60)
    print("📊 回测结果汇总")
    print("=" * 60)
    print(f"总交易次数:     {total}")
    print(f"盈利次数:       {win_count} ({win_rate:.1f}%)")
    print(f"亏损次数:       {loss_count} ({100-win_rate:.1f}%)")
    print(f"平均持股天数:   {avg_hold:.1f} 天")
    print()
    print(f"平均盈利:       {avg_win:+.2f}%")
    print(f"平均亏损:       {avg_loss:+.2f}%")
    print(f"盈亏比:         {profit_ratio:.2f}:1")
    print(f"平均收益/笔:    {avg_pnl:+.2f}%")
    print()
    print(f"总收益:         {total_pnl:+.2f}%")
    print(f"最大单笔盈利:   {max_win:+.2f}%")
    print(f"最大单笔亏损:   {max_loss:+.2f}%")
    print(f"最大连续亏损:   {max_consecutive_loss} 次")
    print()
    print("📋 按卖出原因统计:")
    for reason, stats in reason_stats.items():
        r_win = stats['wins'] / stats['count'] * 100
        print(f"  {reason:6} | {stats['count']:3}次 | 胜率 {r_win:.0f}% | 总收益 {stats['pnl']:+.1f}%")
    print()

    # Top 10 最佳股票
    if stock_stats:
        top_stocks = sorted(stock_stats, key=lambda x: x['total_pnl'], reverse=True)[:10]
        print("🏆 Top 10 最佳标的:")
        for s in top_stocks:
            print(f"  {s['code']} | {s['trades']}次 | 胜率 {s['win_rate']}% | 总收益 {s['total_pnl']:+.1f}%")

    # ── 保存结果 ──
    result = {
        'strategy': '波段策略 v1.0 - 200%盈亏比',
        'backtest_period': '2025-01-01 ~ 2026-06-15',
        'stock_count': len(TEST_STOCKS),
        'summary': {
            'total_trades': total,
            'win_count': win_count,
            'loss_count': loss_count,
            'win_rate': round(win_rate, 1),
            'avg_win': round(avg_win, 2),
            'avg_loss': round(avg_loss, 2),
            'profit_ratio': round(profit_ratio, 2),
            'avg_pnl': round(avg_pnl, 2),
            'total_pnl': round(total_pnl, 2),
            'avg_hold_days': round(avg_hold, 1),
            'max_win': round(max_win, 2),
            'max_loss': round(max_loss, 2),
            'max_consecutive_loss': max_consecutive_loss,
        },
        'reason_stats': reason_stats,
        'top_stocks': sorted(stock_stats, key=lambda x: x['total_pnl'], reverse=True)[:10],
        'recent_trades': sorted(all_trades, key=lambda x: x['sell_date'], reverse=True)[:20],
    }

    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "backtest_result.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\n💾 详细结果已保存: {out_path}")
    print("=" * 60)

    return result


if __name__ == "__main__":
    run_backtest()
