#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""快速波段策略回测 - 20只股票"""

import akshare as ak
import pandas as pd
import numpy as np
import json
import os
import time
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 策略参数
MA_SHORT, MA_MID, MA_LONG = 5, 10, 20
RSI_PERIOD = 14
STOP_LOSS_PCT = -0.05
TAKE_PROFIT_PCT = 0.10
MAX_HOLD_DAYS = 15

# 精选测试池
STOCKS = [
    "000001", "000333", "000651", "000858", "002415",
    "002594", "300015", "300750", "600036", "600519",
    "601318", "601166", "600276", "600887", "601888",
]

def calc_rsi(s, p=14):
    d = s.diff()
    g = d.clip(lower=0).rolling(p).mean()
    l = (-d).clip(lower=0).rolling(p).mean()
    return 100 - 100/(1+g/l.replace(0,np.nan))

def get_data(code):
    prefix = 'sz' if code.startswith(('0','3')) else 'sh'
    try:
        df = ak.stock_zh_a_daily(symbol=prefix+code, start_date='20250101', end_date='20260615', adjust='qfq')
        if df is None or len(df) < 40: return None
        df['pct'] = df['close'].pct_change()*100
        df['ma5'] = df['close'].rolling(5).mean()
        df['ma10'] = df['close'].rolling(10).mean()
        df['ma20'] = df['close'].rolling(20).mean()
        df['rsi'] = calc_rsi(df['close'])
        df['vma5'] = df['volume'].rolling(5).mean()
        df['vma20'] = df['volume'].rolling(20).mean()
        return df
    except Exception as e:
        return None

def backtest(code):
    df = get_data(code)
    if df is None: return []
    trades = []
    in_pos = False
    buy_px = buy_dt = sl = tp = 0
    
    for i in range(25, len(df)):
        r = df.iloc[i]
        if pd.isna(r['ma5']) or pd.isna(r['rsi']): continue
        
        if not in_pos:
            # 买入: 多头排列 + 回踩MA10 + RSI合理
            if (r['ma5'] > r['ma10'] > r['ma20'] and
                abs(r['close']-r['ma10'])/r['ma10'] < 0.05 and
                30 < r['rsi'] < 75 and
                r['close'] > r['ma20']*0.98):
                buy_px = r['close']
                buy_dt = r['date']
                sl = buy_px * 0.95
                tp = buy_px * 1.10
                in_pos = True
        else:
            hold = (r['date'] - buy_dt).days
            sell_px = r['close']
            reason = None
            
            if r['low'] <= sl: sell_px, reason = sl, "止损"
            elif r['high'] >= tp: sell_px, reason = tp, "止盈"
            elif hold >= MAX_HOLD_DAYS: reason = "超时"
            elif r['close'] < r['ma20']: reason = "破位"
            
            if reason:
                pnl = (sell_px-buy_px)/buy_px*100
                trades.append({'code':code,'buy_date':str(buy_dt)[:10],'buy_price':round(buy_px,2),
                    'sell_date':str(r['date'])[:10],'sell_price':round(sell_px,2),
                    'hold_days':hold,'pnl':round(pnl,2),'reason':reason})
                in_pos = False
    return trades

print("🚀 快速波段策略回测")
print(f"📊 止损 {STOP_LOSS_PCT*100}% | 止盈 {TAKE_PROFIT_PCT*100}% | 盈亏比 {abs(TAKE_PROFIT_PCT/STOP_LOSS_PCT)}:1")
print(f"⏱️  持股 1-{MAX_HOLD_DAYS} 天 | 测试 {len(STOCKS)} 只\n")

all_trades = []
for i, code in enumerate(STOCKS):
    print(f"  [{i+1}/{len(STOCKS)}] {code}...", end=" ", flush=True)
    trades = backtest(code)
    if trades:
        print(f"✅ {len(trades)}笔")
        all_trades.extend(trades)
    else:
        print("无信号")
    time.sleep(0.5)

if not all_trades:
    print("\n❌ 无交易信号，策略条件可能过严")
    exit(1)

# 统计
wins = [t for t in all_trades if t['pnl']>0]
losses = [t for t in all_trades if t['pnl']<=0]
win_rate = len(wins)/len(all_trades)*100
avg_win = np.mean([t['pnl'] for t in wins]) if wins else 0
avg_loss = np.mean([t['pnl'] for t in losses]) if losses else 0
avg_hold = np.mean([t['hold_days'] for t in all_trades])
total_pnl = sum(t['pnl'] for t in all_trades)
ratio = abs(avg_win/avg_loss) if avg_loss else 0

# 按原因
reason_stats = {}
for t in all_trades:
    r = t['reason']
    if r not in reason_stats: reason_stats[r] = {'cnt':0,'pnl':0,'wins':0}
    reason_stats[r]['cnt']+=1; reason_stats[r]['pnl']+=t['pnl']
    if t['pnl']>0: reason_stats[r]['wins']+=1

print("\n" + "="*55)
print("📊 回测结果")
print("="*55)
print(f"总交易: {len(all_trades)} | 盈: {len(wins)} | 亏: {len(losses)}")
print(f"胜率: {win_rate:.1f}%")
print(f"平均盈: {avg_win:+.2f}% | 平均亏: {avg_loss:+.2f}%")
print(f"盈亏比: {ratio:.2f}:1")
print(f"平均收益/笔: {total_pnl/len(all_trades):+.2f}%")
print(f"总收益: {total_pnl:+.2f}%")
print(f"平均持股: {avg_hold:.1f}天")
print(f"最大单笔盈: {max(t['pnl'] for t in all_trades):+.2f}%")
print(f"最大单笔亏: {min(t['pnl'] for t in all_trades):+.2f}%")
print()
print("📋 卖出原因:")
for r,s in reason_stats.items():
    print(f"  {r:4} | {s['cnt']:2}次 | 胜率 {s['wins']/s['cnt']*100:.0f}% | 收益 {s['pnl']:+.1f}%")
print()
print("📝 最近10笔:")
for t in sorted(all_trades, key=lambda x:x['sell_date'], reverse=True)[:10]:
    print(f"  {t['code']} {t['buy_date']}→{t['sell_date']} {t['pnl']:+.2f}% {t['reason']}")

# 保存
result = {
    'strategy': '波段策略 v1.0',
    'params': {'stop_loss':-5,'take_profit':10,'max_hold':15,'profit_ratio':'2:1'},
    'summary': {
        'total_trades':len(all_trades),'win_rate':round(win_rate,1),
        'avg_win':round(avg_win,2),'avg_loss':round(avg_loss,2),
        'profit_ratio':round(ratio,2),'total_pnl':round(total_pnl,2),
        'avg_hold':round(avg_hold,1),
    },
    'reason_stats':reason_stats,
    'trades':all_trades,
}
with open(os.path.join(OUTPUT_DIR,"backtest_result.json"),"w") as f:
    json.dump(result,f,ensure_ascii=False,indent=2)
print(f"\n💾 已保存到 data/backtest_result.json")
