#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""补充采集跌停股和炸板股"""

import akshare as ak
import json
import os
import time
from datetime import datetime

path = "/home/work/.openclaw/workspace/stock-analyzer/data/market_data.json"
with open(path, "r") as f:
    data = json.load(f)

today = datetime.now().strftime("%Y%m%d")

# 跌停股
print("🟢 获取跌停股...")
try:
    df = ak.stock_zt_pool_dtgc_em(date=today)
    if df is not None and not df.empty:
        stocks = []
        for _, r in df.iterrows():
            stocks.append({
                "name": str(r.get("名称", "")),
                "code": str(r.get("代码", "")),
                "price": float(r.get("最新价", 0) or 0),
                "change_pct": float(r.get("涨跌幅", 0) or 0),
                "turnover": float(r.get("换手率", 0) or 0),
                "reason": str(r.get("所属行业", "")),
            })
        data["limit_down_stocks"] = stocks
        print(f"  ✅ 跌停 {len(stocks)} 家")
    else:
        data["limit_down_stocks"] = []
        print("  ⚠️ 无跌停数据")
except Exception as e:
    data["limit_down_stocks"] = []
    print(f"  ❌ 失败: {e}")

time.sleep(1)

# 炸板股
print("💥 获取炸板股...")
try:
    df = ak.stock_zt_pool_zbgc_em(date=today)
    if df is not None and not df.empty:
        stocks = []
        for _, r in df.iterrows():
            stocks.append({
                "name": str(r.get("名称", "")),
                "code": str(r.get("代码", "")),
                "price": float(r.get("最新价", 0) or 0),
                "change_pct": float(r.get("涨跌幅", 0) or 0),
                "turnover": float(r.get("换手率", 0) or 0),
                "reason": str(r.get("所属行业", "")),
            })
        data["broken_stocks"] = stocks
        print(f"  ✅ 炸板 {len(stocks)} 家")
    else:
        data["broken_stocks"] = []
        print("  ⚠️ 无炸板数据")
except Exception as e:
    data["broken_stocks"] = []
    print(f"  ❌ 失败: {e}")

# 保存
with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

import shutil
canvas = os.path.expanduser("~/.openclaw/canvas/stock-analyzer/data/market_data.json")
os.makedirs(os.path.dirname(canvas), exist_ok=True)
shutil.copy2(path, canvas)

print(f"\n✅ 完成! 跌停 {len(data.get('limit_down_stocks',[]))} 家 | 炸板 {len(data.get('broken_stocks',[]))} 家")
