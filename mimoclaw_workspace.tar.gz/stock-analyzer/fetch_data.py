# -*- coding: utf-8 -*-
"""
StockPulse 数据采集模块
基于 AkShare 获取 A股实时行情、涨停、板块资金流等数据
数据源参考: https://github.com/ZhuLinsen/daily_stock_analysis
"""

import akshare as ak
import pandas as pd
import json
import os
import time
import random
from datetime import datetime, timedelta

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def safe_float(val, default=0.0):
    try:
        v = float(val)
        return v if pd.notna(v) else default
    except:
        return default


def retry_call(func, *args, retries=3, delay=2, **kwargs):
    for i in range(retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if i < retries - 1:
                time.sleep(delay + random.uniform(0, 1))
            else:
                print(f"  ⚠️  {func.__name__} 失败: {e}")
                return None


# ── 1. 大盘指数 ──────────────────────────────────────
def fetch_indices():
    print("📊 获取大盘指数...")
    indices = {
        "sh000001": "上证指数",
        "sz399001": "深证成指",
        "sz399006": "创业板指",
    }
    result = []
    for code, name in indices.items():
        try:
            df = retry_call(ak.stock_zh_index_spot_em)
            if df is not None:
                row = df[df["代码"] == code.replace("sh", "").replace("sz", "")]
                if not row.empty:
                    r = row.iloc[0]
                    result.append({
                        "name": name,
                        "code": code,
                        "price": safe_float(r.get("最新价")),
                        "change_pct": safe_float(r.get("涨跌幅")),
                        "change_amt": safe_float(r.get("涨跌额")),
                        "volume": safe_float(r.get("成交量")),
                        "amount": safe_float(r.get("成交额")),
                    })
        except Exception as e:
            print(f"  ⚠️  {name} 获取失败: {e}")
    return result


# ── 2. 涨停股 ────────────────────────────────────────
def fetch_limit_up():
    print("🔴 获取涨停股...")
    try:
        df = retry_call(ak.stock_zt_pool_em, date=datetime.now().strftime("%Y%m%d"))
        if df is None or df.empty:
            return [], 0
        stocks = []
        for _, r in df.head(30).iterrows():
            stocks.append({
                "name": str(r.get("名称", "")),
                "code": str(r.get("代码", "")),
                "price": safe_float(r.get("最新价")),
                "change_pct": safe_float(r.get("涨跌幅")),
                "turnover": safe_float(r.get("换手率")),
                "amount": safe_float(r.get("成交额")),
                "reason": str(r.get("所属行业", "")),
                "limit_times": int(safe_float(r.get("连板数", 1))),
            })
        return stocks, len(df)
    except Exception as e:
        print(f"  ⚠️  涨停获取失败: {e}")
        return [], 0


# ── 3. 跌停股 ────────────────────────────────────────
def fetch_limit_down():
    print("🟢 获取跌停股...")
    try:
        df = retry_call(ak.stock_zt_pool_dtgc_em, date=datetime.now().strftime("%Y%m%d"))
        if df is None or df.empty:
            return [], 0
        return [], len(df)
    except:
        return [], 0


# ── 4. 板块资金流 ────────────────────────────────────
def fetch_sector_flow():
    print("💰 获取板块资金流...")
    try:
        df = retry_call(ak.stock_sector_fund_flow_rank, indicator="今日", sector_type="行业资金流")
        if df is None or df.empty:
            return []
        sectors = []
        for _, r in df.head(15).iterrows():
            sectors.append({
                "name": str(r.get("名称", "")),
                "change_pct": safe_float(r.get("今日涨跌幅")),
                "main_net": safe_float(r.get("今日主力净流入-净额")),
                "main_pct": safe_float(r.get("今日主力净流入-净占比")),
            })
        return sectors
    except Exception as e:
        print(f"  ⚠️  板块资金流获取失败: {e}")
        return []


# ── 5. 个股实时行情 ──────────────────────────────────
def fetch_stock_quote(codes):
    """获取指定股票的实时行情"""
    print("📈 获取个股行情...")
    result = []
    try:
        df = retry_call(ak.stock_zh_a_spot_em)
        if df is None:
            return result
        for code in codes:
            row = df[df["代码"] == code]
            if not row.empty:
                r = row.iloc[0]
                result.append({
                    "code": code,
                    "name": str(r.get("名称", "")),
                    "price": safe_float(r.get("最新价")),
                    "change_pct": safe_float(r.get("涨跌幅")),
                    "turnover": safe_float(r.get("换手率")),
                    "volume_ratio": safe_float(r.get("量比")),
                    "amount": safe_float(r.get("成交额")),
                    "pe": safe_float(r.get("市盈率-动态")),
                    "total_mv": safe_float(r.get("总市值")),
                })
    except Exception as e:
        print(f"  ⚠️  个股行情获取失败: {e}")
    return result


# ── 6. 炸板股 ────────────────────────────────────────
def fetch_broken_limit():
    print("💥 获取炸板股...")
    try:
        df = retry_call(ak.stock_zt_pool_zbgc_em, date=datetime.now().strftime("%Y%m%d"))
        if df is None or df.empty:
            return 0
        return len(df)
    except:
        return 0


# ── 7. 北向资金 ──────────────────────────────────────
def fetch_north_flow():
    print("🏦 获取北向资金...")
    try:
        df = retry_call(ak.stock_hsgt_north_net_flow_in_em, symbol="北向")
        if df is None or df.empty:
            return 0
        latest = df.iloc[-1]
        return safe_float(latest.get("当日净流入", 0))
    except:
        return 0


# ── 8. 涨停强度排序 ──────────────────────────────────
def rank_limit_up_stocks(stocks):
    """根据换手率、量比、封单强度排序"""
    for s in stocks:
        score = 0
        # 换手率适中 (5-20%) 得分高
        tr = s.get("turnover", 0)
        if 5 <= tr <= 20:
            score += 30
        elif tr < 5:
            score += 10
        # 连板数加分
        score += s.get("limit_times", 1) * 20
        # 行业加分 (AI/低空等热门)
        hot_themes = ["AI", "算力", "低空", "飞行", "光模块", "CPO", "固态", "电池", "芯片"]
        for t in hot_themes:
            if t in s.get("reason", ""):
                score += 15
                break
        s["score"] = score
    return sorted(stocks, key=lambda x: x.get("score", 0), reverse=True)


# ── 主函数 ───────────────────────────────────────────
def main():
    print("=" * 50)
    print("🚀 StockPulse 数据采集开始")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)

    # 1. 大盘指数
    indices = fetch_indices()

    # 2. 涨停股
    limit_up, limit_up_count = fetch_limit_up()

    # 3. 跌停股
    _, limit_down_count = fetch_limit_down()

    # 4. 炸板数
    broken_count = fetch_broken_limit()

    # 5. 板块资金流
    sectors = fetch_sector_flow()

    # 6. 北向资金
    north_flow = fetch_north_flow()

    # 7. 涨停强度排序
    ranked = rank_limit_up_stocks(limit_up)

    # 8. 推荐标的 (取前3)
    top3 = ranked[:3] if len(ranked) >= 3 else ranked

    # 获取推荐标的详细行情
    top3_codes = [s["code"] for s in top3]
    top3_detail = fetch_stock_quote(top3_codes)

    # 合并推荐数据
    recommendations = []
    for i, stock in enumerate(top3):
        detail = next((d for d in top3_detail if d["code"] == stock["code"]), {})
        recommendations.append({
            "rank": i + 1,
            "name": stock["name"],
            "code": stock["code"],
            "price": detail.get("price", stock.get("price", 0)),
            "change_pct": detail.get("change_pct", stock.get("change_pct", 0)),
            "turnover": detail.get("turnover", stock.get("turnover", 0)),
            "volume_ratio": detail.get("volume_ratio", 0),
            "amount": detail.get("amount", stock.get("amount", 0)),
            "reason": stock.get("reason", ""),
            "limit_times": stock.get("limit_times", 1),
            "pe": detail.get("pe", 0),
            "total_mv": detail.get("total_mv", 0),
            "score": stock.get("score", 0),
        })

    # 板块按资金流排序
    sector_ranked = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)

    # 构建输出
    data = {
        "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "market": {
            "indices": indices,
            "limit_up_count": limit_up_count,
            "limit_down_count": limit_down_count,
            "broken_count": broken_count,
            "north_flow": north_flow,
        },
        "limit_up_stocks": ranked[:20],
        "sectors": sector_ranked[:10],
        "recommendations": recommendations,
    }

    # 写入 JSON
    out_path = os.path.join(OUTPUT_DIR, "market_data.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print("=" * 50)
    print(f"✅ 数据已保存到 {out_path}")
    print(f"📊 涨停 {limit_up_count} 家 | 跌停 {limit_down_count} 家 | 炸板 {broken_count} 家")
    print(f"🎯 推荐标的: {', '.join(s['name'] for s in recommendations)}")
    print("=" * 50)

    return data


if __name__ == "__main__":
    main()
