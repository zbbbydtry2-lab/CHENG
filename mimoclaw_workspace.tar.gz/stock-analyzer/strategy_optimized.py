#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
波段策略 v2.0 - 优化版
优化点:
1. 增加趋势强度过滤 (ADX)
2. 回踩确认后等企稳再买 (连续2日站稳MA10)
3. 动态止损 (跟踪止损)
4. 优化时间止损 (超时后看盈亏决定)
"""

import akshare as ak
import pandas as pd
import numpy as np
import json
import os
import time

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

STOCKS = [
    "000001", "000333", "000651", "000858", "002415",
    "002594", "300015", "300750", "600036", "600519",
    "601318", "601166", "600276", "600887", "601888",
    "000002", "000725", "002049", "300122", "600030",
    "600050", "600104", "600150", "600309", "601088",
]

def calc_rsi(s, p=14):
    d = s.diff()
    g = d.clip(lower=0).rolling(p).mean()
    l = (-d).clip(lower=0).rolling(p).mean()
    return 100 - 100/(1+g/l.replace(0,np.nan))

def calc_adx(df, p=14):
    high = df['high']; low = df['low']; close = df['close']
    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm[plus_dm < 0] = 0
    minus_dm[minus_dm < 0] = 0
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(p).mean()
    plus_di = 100 * (plus_dm.rolling(p).mean() / atr)
    minus_di = 100 * (minus_dm.rolling(p).mean() / atr)
    dx = 100 * ((plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan))
    return dx.rolling(p).mean()

def get_data(code):
    prefix = 'sz' if code.startswith(('0','3')) else 'sh'
    try:
        df = ak.stock_zh_a_daily(symbol=prefix+code, start_date='20250101', end_date='20260615', adjust='qfq')
        if df is None or len(df) < 45: return None
        df['pct'] = df['close'].pct_change()*100
        df['ma5'] = df['close'].rolling(5).mean()
        df['ma10'] = df['close'].rolling(10).mean()
        df['ma20'] = df['close'].rolling(20).mean()
        df['rsi'] = calc_rsi(df['close'])
        df['adx'] = calc_adx(df)
        df['vma5'] = df['volume'].rolling(5).mean()
        df['vma20'] = df['volume'].rolling(20).mean()
        # 计算近3日最低
        df['low3'] = df['low'].rolling(3).min()
        return df
    except:
        return None

def backtest_v2(code):
    df = get_data(code)
    if df is None: return []
    trades = []
    in_pos = False
    buy_px = sl = tp = 0
    buy_dt = None
    max_px = 0  # 跟踪最高价

    for i in range(30, len(df)):
        r = df.iloc[i]
        prev = df.iloc[i-1]
        if pd.isna(r['ma5']) or pd.isna(r['rsi']) or pd.isna(r['adx']):
            continue

        if not in_pos:
            # ── 买入条件 v2 ──
            # 1. 多头排列
            if not (r['ma5'] > r['ma10'] > r['ma20']):
                continue
            # 2. 回踩MA10附近 (3%以内)
            bias = (r['close'] - r['ma10']) / r['ma10']
            if bias > 0.03 or bias < -0.02:
                continue
            # 3. 企稳确认: 今日收盘 > 昨日收盘 (止跌)
            if r['close'] < prev['close'] * 0.99:
                continue
            # 4. RSI 40-70 (非超买)
            if r['rsi'] < 40 or r['rsi'] > 70:
                continue
            # 5. ADX > 20 (趋势存在)
            if r['adx'] < 20:
                continue
            # 6. 价格在MA20之上
            if r['close'] < r['ma20']:
                continue

            buy_px = r['close']
            buy_dt = r['date']
            sl = buy_px * 0.95
            tp = buy_px * 1.10
            max_px = buy_px
            in_pos = True

        else:
            # 更新最高价
            max_px = max(max_px, r['high'])
            # 移动止损: 最高价回落5%止损
            trailing_sl = max_px * 0.95
            effective_sl = max(sl, trailing_sl)

            hold = (r['date'] - buy_dt).days
            sell_px = r['close']
            reason = None

            # 止损 (固定或跟踪)
            if r['low'] <= effective_sl:
                sell_px = effective_sl
                reason = "止损" if effective_sl == sl else "跟踪止损"
            # 止盈
            elif r['high'] >= tp:
                sell_px = tp
                reason = "止盈"
            # 超时: 看盈亏决定
            elif hold >= 15:
                if r['close'] > buy_px * 1.02:
                    reason = "超时止盈"
                elif r['close'] < buy_px * 0.98:
                    reason = "超时止损"
                else:
                    reason = "超时平仓"
            # 趋势破坏: 收盘跌破MA20 且 已持股>3天
            elif hold > 3 and r['close'] < r['ma20'] * 0.98:
                reason = "破位"

            if reason:
                pnl = (sell_px-buy_px)/buy_px*100
                trades.append({
                    'code':code,'buy_date':str(buy_dt)[:10],'buy_price':round(buy_px,2),
                    'sell_date':str(r['date'])[:10],'sell_price':round(sell_px,2),
                    'hold_days':hold,'pnl':round(pnl,2),'reason':reason
                })
                in_pos = False
    return trades

print("🚀 波段策略 v2.0 优化版回测")
print("📊 优化: ADX趋势过滤 + 企稳确认 + 跟踪止损")
print(f"⏱️  持股 1-15天 | 止损5% | 止盈10% | 盈亏比 2:1")
print(f"📈 测试 {len(STOCKS)} 只\n")

all_trades = []
for i, code in enumerate(STOCKS):
    print(f"  [{i+1}/{len(STOCKS)}] {code}...", end=" ", flush=True)
    trades = backtest_v2(code)
    if trades:
        print(f"✅ {len(trades)}笔")
        all_trades.extend(trades)
    else:
        print("无信号")
    time.sleep(0.5)

if not all_trades:
    print("\n❌ 无交易信号")
    exit(1)

# 统计
wins = [t for t in all_trades if t['pnl']>0]
losses = [t for t in all_trades if t['pnl']<=0]
win_rate = len(wins)/len(all_trades)*100
avg_win = np.mean([t['pnl'] for t in wins]) if wins else 0
avg_loss = np.mean([t['pnl'] for t in losses]) if losses else 0
avg_hold = np.mean([t['hold_days'] for t in all_trades])
total_pnl = sum(t['pnl'] for t in all_trades)
ratio = abs(avg_win/avg_loss) if avg_loss else 0

reason_stats = {}
for t in all_trades:
    r = t['reason']
    if r not in reason_stats: reason_stats[r] = {'cnt':0,'pnl':0,'wins':0}
    reason_stats[r]['cnt']+=1; reason_stats[r]['pnl']+=t['pnl']
    if t['pnl']>0: reason_stats[r]['wins']+=1

# 连续亏损
max_consec = 0; cur = 0
for t in all_trades:
    if t['pnl']<=0: cur+=1; max_consec=max(max_consec,cur)
    else: cur=0

print("\n" + "="*60)
print("📊 波段策略 v2.0 回测结果")
print("="*60)
print(f"总交易:   {len(all_trades)} 笔")
print(f"盈利:     {len(wins)} 笔 ({win_rate:.1f}%)")
print(f"亏损:     {len(losses)} 笔 ({100-win_rate:.1f}%)")
print(f"平均盈:   {avg_win:+.2f}%")
print(f"平均亏:   {avg_loss:+.2f}%")
print(f"盈亏比:   {ratio:.2f}:1")
print(f"平均收益: {total_pnl/len(all_trades):+.2f}%/笔")
print(f"总收益:   {total_pnl:+.2f}%")
print(f"平均持股: {avg_hold:.1f} 天")
print(f"最大连续亏: {max_consec} 次")
print()
print("📋 卖出原因统计:")
for r,s in sorted(reason_stats.items(), key=lambda x:-x[1]['pnl']):
    wr = s['wins']/s['cnt']*100
    print(f"  {r:8} | {s['cnt']:3}次 | 胜率 {wr:5.1f}% | 收益 {s['pnl']:+7.1f}%")
print()
print("📝 最近15笔交易:")
for t in sorted(all_trades, key=lambda x:x['sell_date'], reverse=True)[:15]:
    emoji = "✅" if t['pnl']>0 else "❌"
    print(f"  {emoji} {t['code']} {t['buy_date']}→{t['sell_date']} {t['pnl']:+.2f}% {t['reason']} {t['hold_days']}天")

# 保存
result = {
    'strategy': '波段策略 v2.0 (优化版)',
    'version': '2.0',
    'params': {
        'entry': '多头排列+回踩MA10+企稳确认+ADX>20+RSI40-70',
        'exit': '止损5%/跟踪止损5%/止盈10%/超时15天/破MA20',
        'profit_ratio': '2:1',
        'hold_range': '1-15天',
    },
    'summary': {
        'total_trades':len(all_trades),'win_rate':round(win_rate,1),
        'avg_win':round(avg_win,2),'avg_loss':round(avg_loss,2),
        'profit_ratio':round(ratio,2),'total_pnl':round(total_pnl,2),
        'avg_hold':round(avg_hold,1),'max_consecutive_loss':max_consec,
    },
    'reason_stats':reason_stats,
    'trades':all_trades,
}
with open(os.path.join(OUTPUT_DIR,"backtest_v2.json"),"w") as f:
    json.dump(result,f,ensure_ascii=False,indent=2)
print(f"\n💾 已保存到 data/backtest_v2.json")
