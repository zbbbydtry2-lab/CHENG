#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
StockPulse 数据中枢 v4.0
多数据源整合: 悟道MCP + AKShare + 新浪/腾讯 + TickFlow/iTick

数据源优先级:
  盘后复盘: 悟道MCP > AKShare
  实时行情: TickFlow/iTick > 新浪/腾讯 > AKShare
  涨停/板块: 悟道MCP > AKShare
  资金流向: 悟道MCP > AKShare
  龙虎榜: 悟道MCP > AKShare
"""

import json
import os
import time
import requests
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ══════════════════════════════════════════════════════
# 配置区 - 填入你的 API Key
# ══════════════════════════════════════════════════════

# 悟道数据 MCP (https://stock.quicktiny.cn/developer 获取)
WUDAO_API_KEY = os.environ.get("WUDAO_API_KEY", "lb_1058c2bb2bb21048d4127e6cc038671d273a23868592ddf0746752233ee5d75f")
WUDAO_BASE_URL = "https://stock.quicktiny.cn/api/openclaw"

# TickFlow (https://tickflow.org 注册获取)
TICKFLOW_API_KEY = os.environ.get("TICKFLOW_API_KEY", "tk_188bb53da97c47e0a6fce04b82f689f4")
TICKFLOW_BASE_URL = "https://api.tickflow.org/v1"

# iTick (https://docs.itick.org 注册获取)
ITICK_API_KEY = os.environ.get("ITICK_API_KEY", "909ddc93c5e848b6af0dce0ea74d88dc4fd0d637c48a4467b5167d7fc3235488")
ITICK_BASE_URL = "https://api-free.itick.org"


# ══════════════════════════════════════════════════════
# 通用工具
# ══════════════════════════════════════════════════════

def sf(val, default=0.0):
    try:
        v = float(val)
        return v if v == v else default  # NaN check
    except:
        return default

def api_get(url, headers=None, params=None, timeout=10):
    try:
        r = requests.get(url, headers=headers, params=params, timeout=timeout)
        if r.status_code == 200:
            r.encoding = "utf-8"
            return r.json()
    except Exception as e:
        pass
    return None


# ══════════════════════════════════════════════════════
# 数据源 1: 悟道数据 MCP (盘后复盘首选)
# ══════════════════════════════════════════════════════

class WudaoSource:
    """悟道数据 - 61个工具覆盖涨停梯队/资金流向/龙虎榜/题材热度"""

    def __init__(self, api_key=""):
        self.api_key = api_key
        self.base = WUDAO_BASE_URL
        self.headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}

    def available(self):
        return bool(self.api_key)

    def call_tool(self, tool_name, params=None):
        """调用悟道MCP工具"""
        if not self.available():
            return None
        url = f"{self.base}/tools/call"
        body = {"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                "params": {"name": tool_name, "arguments": params or {}}}
        try:
            r = requests.post(url, json=body, headers=self.headers, timeout=15)
            r.encoding = "utf-8"
            if r.status_code == 200:
                for line in r.text.split("\n"):
                    if line.startswith("data: "):
                        data = json.loads(line[6:])
                        result = data.get("result", {})
                        content = result.get("content", [])
                        for c in content:
                            if c.get("type") == "text":
                                try:
                                    return json.loads(c["text"])
                                except:
                                    return c["text"]
        except:
            pass
        return None

    def market_overview(self):
        """市场概览: 涨跌家数/涨停/跌停/炸板/成交额"""
        return self.call_tool("get_market_overview")

    def limit_up_ladder(self):
        """涨停梯队: 连板高度/各板层个股"""
        return self.call_tool("get_limit_up_ladder")

    def hot_sectors(self):
        """热门板块/概念排行"""
        return self.call_tool("get_hot_sectors")

    def capital_flow(self):
        """资金流向: 主力/北向/板块资金"""
        return self.call_tool("get_capital_flow")

    def dragon_tiger(self):
        """龙虎榜: 游资/机构动向"""
        return self.call_tool("get_dragon_tiger")

    def stock_search(self, query):
        """股票搜索"""
        return self.call_tool("search_stock", {"query": query})

    def realtime_quote(self, codes):
        """实时行情"""
        return self.call_tool("get_realtime_quote", {"codes": codes})

    def limit_up_pool(self, date=None):
        """涨停池"""
        return self.call_tool("get_limit_up_pool", {"date": date or datetime.now().strftime("%Y%m%d")})

    def broken_limit_pool(self, date=None):
        """炸板池"""
        return self.call_tool("get_broken_limit_pool", {"date": date or datetime.now().strftime("%Y%m%d")})

    def sector_fund_flow(self):
        """板块资金流"""
        return self.call_tool("get_sector_fund_flow")

    def concept_ranking(self):
        """概念排行"""
        return self.call_tool("get_concept_ranking")


# ══════════════════════════════════════════════════════
# 数据源 2: TickFlow (实时行情首选)
# ══════════════════════════════════════════════════════

class TickFlowSource:
    """TickFlow - REST实时快照 + WebSocket推送"""

    def __init__(self, api_key=""):
        self.api_key = api_key
        self._tf = None

    def available(self):
        return bool(self.api_key)

    def _get_tf(self):
        if self._tf is None and self.api_key:
            try:
                from tickflow import TickFlow
                self._tf = TickFlow(api_key=self.api_key)
            except:
                pass
        return self._tf

    def snapshot(self, symbol):
        """获取单只股票实时快照"""
        tf = self._get_tf()
        if tf is None:
            return None
        try:
            df = tf.quotes.get(symbols=[symbol], as_dataframe=True)
            if df is not None and not df.empty:
                return df.iloc[0].to_dict()
        except:
            pass
        return None

    def batch_snapshot(self, symbols):
        """批量获取实时快照"""
        tf = self._get_tf()
        if tf is None:
            return None
        try:
            df = tf.quotes.get(symbols=symbols, as_dataframe=True)
            if df is not None:
                return df.to_dict('records')
        except:
            pass
        return None

    def kline(self, symbol, period="1d", limit=30):
        """获取K线数据"""
        tf = self._get_tf()
        if tf is None:
            return None
        try:
            df = tf.klines.get(symbol, period=period, count=limit, as_dataframe=True)
            if df is not None:
                return df.to_dict('records')
        except:
            pass
        return None


# ══════════════════════════════════════════════════════
# 数据源 3: iTick (免费实时行情)
# ══════════════════════════════════════════════════════

class ITickSource:
    """iTick - 永久免费A股基础行情"""

    def __init__(self, api_key=""):
        self.api_key = api_key
        self.base = ITICK_BASE_URL
        self.headers = {"token": api_key} if api_key else {}

    def available(self):
        return bool(self.api_key)

    def quote(self, code, region="SZ"):
        """实时报价"""
        if not self.available():
            return None
        url = f"{self.base}/stock/quote"
        return api_get(url, headers=self.headers, params={"code": code, "region": region})

    def batch_quote(self, codes):
        """批量报价 - 逐个获取"""
        if not self.available():
            return None
        results = []
        for code in codes:
            clean = code.replace(".SZ", "").replace(".SH", "").replace("sz", "").replace("sh", "")
            region = "SZ" if clean.startswith(("0", "3")) else "SH"
            data = self.quote(clean, region)
            if data and data.get("data"):
                d = data["data"]
                results.append({
                    "code": d.get("s", clean),
                    "price": d.get("ld", 0),
                    "pct": d.get("chp", 0),
                    "volume": d.get("v", 0),
                    "amount": d.get("tu", 0),
                })
        return results if results else None


# ══════════════════════════════════════════════════════
# 数据源 4: 腾讯/新浪 (备选/应急)
# ══════════════════════════════════════════════════════

class TencentSource:
    """腾讯证券接口 - 3秒更新频率"""

    @staticmethod
    def quote(codes):
        """批量获取行情
        codes: ['sz000001', 'sh600000', ...]
        """
        url = f"https://qt.gtimg.cn/q={','.join(codes)}"
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                results = []
                for line in r.text.strip().split("\n"):
                    if "~" in line:
                        parts = line.split("~")
                        if len(parts) > 45:
                            results.append({
                                "code": parts[2],
                                "name": parts[1],
                                "price": sf(parts[3]),
                                "pct": sf(parts[32]),
                                "volume": sf(parts[6]),
                                "amount": sf(parts[37]),
                                "turnover": sf(parts[38]),
                            })
                return results
        except:
            pass
        return None


class SinaSource:
    """新浪财经接口 - 基础行情"""

    @staticmethod
    def quote(codes):
        """批量获取行情
        codes: ['sh600000', 'sz000001', ...]
        """
        url = f"http://hq.sinajs.cn/list={','.join(codes)}"
        try:
            r = requests.get(url, timeout=5, headers={"Referer": "http://finance.sina.com.cn"})
            if r.status_code == 200:
                results = []
                for line in r.text.strip().split("\n"):
                    if "=" in line and '"' in line:
                        data = line.split('"')[1].split(",")
                        if len(data) > 30:
                            code = line.split("_")[-1].split("=")[0]
                            results.append({
                                "code": code,
                                "name": data[0],
                                "price": sf(data[3]),
                                "pct": round(sf(data[3]) / sf(data[2]) * 100 - 100, 2) if sf(data[2]) > 0 else 0,
                                "volume": sf(data[8]),
                                "amount": sf(data[9]),
                            })
                return results
        except:
            pass
        return None


# ══════════════════════════════════════════════════════
# 数据中枢 - 统一调度
# ══════════════════════════════════════════════════════

class DataHub:
    """StockPulse 数据中枢 - 多源整合"""

    def __init__(self):
        self.wudao = WudaoSource(WUDAO_API_KEY)
        self.tickflow = TickFlowSource(TICKFLOW_API_KEY)
        self.itick = ITickSource(ITICK_API_KEY)
        self.tencent = TencentSource()
        self.sina = SinaSource()

    def status(self):
        """检查各数据源状态"""
        return {
            "悟道MCP": "✅ 已配置" if self.wudao.available() else "❌ 未配置 (设置 WUDAO_API_KEY)",
            "TickFlow": "✅ 已配置" if self.tickflow.available() else "❌ 未配置 (设置 TICKFLOW_API_KEY)",
            "iTick": "✅ 已配置" if self.itick.available() else "❌ 未配置 (设置 ITICK_API_KEY)",
            "腾讯证券": "✅ 可用",
            "新浪财经": "✅ 可用",
            "AKShare": "✅ 可用",
        }

    def get_market_overview(self):
        """获取市场概览 - 多源回退"""
        # 优先悟道MCP
        if self.wudao.available():
            data = self.wudao.market_overview()
            if data:
                return {"source": "wudao", "data": data}

        # 回退AKShare
        try:
            import akshare as ak
            limit_up = ak.stock_zt_pool_em(date=datetime.now().strftime("%Y%m%d"))
            limit_down = ak.stock_zt_pool_dtgc_em(date=datetime.now().strftime("%Y%m%d"))
            broken = ak.stock_zt_pool_zbgc_em(date=datetime.now().strftime("%Y%m%d"))
            return {
                "source": "akshare",
                "data": {
                    "limit_up_count": len(limit_up) if limit_up is not None else 0,
                    "limit_down_count": len(limit_down) if limit_down is not None else 0,
                    "broken_count": len(broken) if broken is not None else 0,
                }
            }
        except:
            pass
        return None

    def get_limit_up_ladder(self):
        """涨停梯队 - 多源回退"""
        if self.wudao.available():
            data = self.wudao.limit_up_ladder()
            if data:
                return {"source": "wudao", "data": data}

        try:
            import akshare as ak
            df = ak.stock_zt_pool_em(date=datetime.now().strftime("%Y%m%d"))
            if df is not None and not df.empty:
                ladder = {}
                for _, r in df.iterrows():
                    lt = int(sf(r.get("连板数", 1)))
                    if lt not in ladder:
                        ladder[lt] = []
                    ladder[lt].append({
                        "name": str(r.get("名称", "")),
                        "code": str(r.get("代码", "")),
                    })
                return {"source": "akshare", "data": ladder}
        except:
            pass
        return None

    def get_hot_sectors(self):
        """热门板块 - 多源回退"""
        if self.wudao.available():
            data = self.wudao.hot_sectors()
            if data:
                return {"source": "wudao", "data": data}

        try:
            import akshare as ak
            df = ak.stock_sector_fund_flow_rank(indicator="今日", sector_type="行业资金流")
            if df is not None and not df.empty:
                sectors = []
                for _, r in df.head(10).iterrows():
                    sectors.append({
                        "name": str(r.get("名称", "")),
                        "change_pct": sf(r.get("今日涨跌幅")),
                        "main_net": sf(r.get("今日主力净流入-净额")),
                    })
                return {"source": "akshare", "data": sectors}
        except:
            pass
        return None

    def get_capital_flow(self):
        """资金流向 - 多源回退"""
        if self.wudao.available():
            data = self.wudao.capital_flow()
            if data:
                return {"source": "wudao", "data": data}

        try:
            import akshare as ak
            df = ak.stock_hsgt_fund_flow_summary_em()
            if df is not None:
                north = 0
                for _, r in df.iterrows():
                    if str(r.get("资金方向")) == "北向":
                        north += sf(r.get("成交净买额", 0))
                return {"source": "akshare", "data": {"north_flow": north}}
        except:
            pass
        return None

    def get_realtime_quotes(self, codes):
        """实时行情 - 多源回退"""
        # TickFlow
        if self.tickflow.available():
            data = self.tickflow.batch_snapshot(codes)
            if data:
                return {"source": "tickflow", "data": data}

        # iTick
        if self.itick.available():
            data = self.itick.batch_quote(codes)
            if data:
                return {"source": "itick", "data": data}

        # 腾讯
        tc_codes = []
        for c in codes:
            c = c.replace(".", "")
            if c.startswith(("0", "3")):
                tc_codes.append("sz" + c)
            elif c.startswith("6"):
                tc_codes.append("sh" + c)
        data = self.tencent.quote(tc_codes)
        if data:
            return {"source": "tencent", "data": data}

        return None

    def get_dragon_tiger(self):
        """龙虎榜"""
        if self.wudao.available():
            data = self.wudao.dragon_tiger()
            if data:
                return {"source": "wudao", "data": data}
        return None


# ══════════════════════════════════════════════════════
# 主程序 - 测试所有数据源
# ══════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("🔌 StockPulse 数据中枢 v4.0")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    hub = DataHub()

    # 数据源状态
    print("\n📡 数据源状态:")
    for name, status in hub.status().items():
        print(f"  {name}: {status}")

    # 测试各接口
    print("\n📊 测试市场概览...")
    overview = hub.get_market_overview()
    if overview:
        print(f"  来源: {overview['source']}")
        print(f"  数据: {json.dumps(overview['data'], ensure_ascii=False)[:200]}")

    print("\n📊 测试涨停梯队...")
    ladder = hub.get_limit_up_ladder()
    if ladder:
        print(f"  来源: {ladder['source']}")
        if isinstance(ladder['data'], dict):
            for k, v in sorted(ladder['data'].items(), reverse=True)[:5]:
                names = [s['name'] for s in v[:3]]
                print(f"  {k}连板: {', '.join(names)} ({len(v)}只)")

    print("\n📊 测试热门板块...")
    sectors = hub.get_hot_sectors()
    if sectors:
        print(f"  来源: {sectors['source']}")
        if isinstance(sectors['data'], list):
            for s in sectors['data'][:5]:
                print(f"  {s.get('name', '')}: {s.get('main_net', 0)/1e8:.1f}亿")

    print("\n📊 测试资金流向...")
    flow = hub.get_capital_flow()
    if flow:
        print(f"  来源: {flow['source']}")
        print(f"  北向: {flow['data'].get('north_flow', 0):.1f}亿")

    print("\n📊 测试实时行情...")
    quotes = hub.get_realtime_quotes(["000001", "600000", "300750"])
    if quotes:
        print(f"  来源: {quotes['source']}")
        if isinstance(quotes['data'], list):
            for q in quotes['data'][:3]:
                print(f"  {q.get('name', q.get('code', ''))}: {q.get('price', '--')} {q.get('pct', '--')}%")

    # 保存状态
    status_data = {
        "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "sources": hub.status(),
        "overview": overview,
        "ladder": ladder,
        "sectors": sectors,
        "capital_flow": flow,
    }
    out_path = os.path.join(OUTPUT_DIR, "hub_status.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(status_data, f, ensure_ascii=False, indent=2, default=str)

    print(f"\n💾 状态已保存: {out_path}")
    print("=" * 60)
    print("\n💡 配置更多数据源:")
    print("  export WUDAO_API_KEY='lb_xxx'    # https://stock.quicktiny.cn/developer")
    print("  export TICKFLOW_API_KEY='tf_xxx'  # https://tickflow.org")
    print("  export ITICK_API_KEY='ik_xxx'     # https://docs.itick.org")


if __name__ == "__main__":
    main()
