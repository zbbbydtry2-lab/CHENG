#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
超短策略 v1.0 - 分歧转一致
核心逻辑:
1. 换手充分 (非一字板，有换手)
2. 分歧后有承接 (炸板后回封，或分歧放量后一致)
3. 一致性 (封单坚决，不反复开板)
4. 扛跌 (大盘回调时抗跌，不跟跌)
5. 回避一字涨停 (无换手，无法参与)
6. 回避高炸板低回封 (炸板率高且不回封，情绪差)
"""

import akshare as ak
import pandas as pd
import numpy as np
import json
import os
import time
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def sf(val, default=0.0):
    try:
        v = float(val)
        return v if pd.notna(v) else default
    except:
        return default


# ── 评分函数 ──

def score_ultra_short(row, market_data=None):
    """
    超短策略评分 (0-100)
    
    核心维度:
    1. 换手充分 (25分) - 不能一字板，要有换手
    2. 分歧承接 (25分) - 炸板后能回封，有资金承接
    3. 一致性 (20分) - 封单坚决，不反复开板
    4. 扛跌性 (15分) - 大盘回调时不跟跌
    5. 题材强度 (15分) - 热门题材加分
    """
    score = 0
    name = str(row.get("name", ""))
    code = str(row.get("code", ""))
    turnover = sf(row.get("turnover"))
    limit_times = int(sf(row.get("limit_times", 1)))
    change_pct = sf(row.get("change_pct"))
    amount = sf(row.get("amount"))
    reason = str(row.get("reason", ""))
    
    # ── 排除条件 ──
    # 1. 一字涨停 (换手率极低)
    if turnover < 1.0:
        return -1, "一字涨停，无法参与"
    
    # 2. 换手率过高 (筹码松动)
    if turnover > 30:
        return -1, "换手过高，筹码松动"
    
    # 3. 成交额过小 (流动性差)
    if amount < 50000000:  # 5000万
        return -1, "成交额过小"
    
    # ── 评分项 ──
    
    # 1. 换手充分 (25分)
    # 理想换手率: 5-20%
    if 8 <= turnover <= 18:
        score += 25  # 最佳换手
    elif 5 <= turnover <= 25:
        score += 20  # 合理换手
    elif 3 <= turnover <= 30:
        score += 10  # 可接受
    
    # 2. 分歧承接 (25分)
    # 通过连板数和换手率判断
    if limit_times >= 2:
        # 2板以上说明有分歧后一致的过程
        score += 20
        if 8 <= turnover <= 15:
            score += 5  # 换手适中，分歧充分
    
    # 3. 一致性 (20分)
    # 涨停说明封住了，有资金做多
    if change_pct >= 9.9:
        score += 15
        # 换手率适中说明封单坚决
        if 5 <= turnover <= 15:
            score += 5
    
    # 4. 扛跌性 (15分)
    # 通过成交额判断资金参与度
    if amount > 500000000:  # 5亿
        score += 15  # 大资金参与，扛跌
    elif amount > 200000000:  # 2亿
        score += 10
    elif amount > 100000000:  # 1亿
        score += 5
    
    # 5. 题材强度 (15分)
    hot_themes = ["AI", "算力", "低空", "飞行", "光模块", "CPO", "固态", "电池", "芯片", "华为", "机器人"]
    for t in hot_themes:
        if t in reason:
            score += 15
            break
    
    return score, ""


def check_avoid_conditions(row, market_data=None):
    """
    回避条件检查
    """
    name = str(row.get("name", ""))
    turnover = sf(row.get("turnover"))
    limit_times = int(sf(row.get("limit_times", 1)))
    
    # 1. 回避一字涨停
    if turnover < 1.0:
        return True, "一字涨停"
    
    # 2. 回避ST
    if "ST" in name or "*ST" in name:
        return True, "ST股"
    
    # 3. 回避换手过高
    if turnover > 30:
        return True, "换手过高"
    
    # 4. 回避成交额过小
    if sf(row.get("amount", 0)) < 50000000:
        return True, "流动性差"
    
    return False, ""


def get_market_sentiment():
    """获取市场情绪数据"""
    try:
        # 涨停数
        df = ak.stock_zt_pool_em(date=datetime.now().strftime("%Y%m%d"))
        limit_up_count = len(df) if df is not None else 0
        
        # 跌停数
        df2 = ak.stock_zt_pool_dtgc_em(date=datetime.now().strftime("%Y%m%d"))
        limit_down_count = len(df2) if df2 is not None else 0
        
        # 炸板数
        df3 = ak.stock_zt_pool_zbgc_em(date=datetime.now().strftime("%Y%m%d"))
        broken_count = len(df3) if df3 is not None else 0
        
        return {
            "limit_up": limit_up_count,
            "limit_down": limit_down_count,
            "broken": broken_count,
            "seal_rate": limit_up_count / (limit_up_count + broken_count) * 100 if (limit_up_count + broken_count) > 0 else 0,
        }
    except:
        return {"limit_up": 0, "limit_down": 0, "broken": 0, "seal_rate": 0}


def check_market_avoid(sentiment):
    """
    市场级回避条件
    高炸板低回封 = 情绪差，回避
    """
    # 炸板率 > 40% 且回封率 < 60%
    if sentiment["seal_rate"] < 60:
        return True, f"封板率仅{sentiment['seal_rate']:.0f}%，情绪差"
    
    # 跌停 > 20 家
    if sentiment["limit_down"] > 20:
        return True, f"跌停{sentiment['limit_down']}家，市场恐慌"
    
    return False, ""


def scan_ultra_short():
    """主扫描流程"""
    print("=" * 60)
    print("⚡ 超短策略扫描 v1.0")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 1. 市场情绪检查
    print("\n📊 检查市场情绪...")
    sentiment = get_market_sentiment()
    print(f"  涨停: {sentiment['limit_up']}家 | 跌停: {sentiment['limit_down']}家 | 炸板: {sentiment['broken']}家")
    print(f"  封板率: {sentiment['seal_rate']:.1f}%")
    
    market_avoid, market_reason = check_market_avoid(sentiment)
    if market_avoid:
        print(f"\n🚫 市场回避: {market_reason}")
        print("  今日不宜做超短，建议观望")
        return {"avoid": True, "reason": market_reason, "stocks": []}
    
    # 2. 获取涨停池
    print("\n🔴 获取涨停池...")
    try:
        df = ak.stock_zt_pool_em(date=datetime.now().strftime("%Y%m%d"))
        if df is None or df.empty:
            print("  ❌ 获取失败")
            return None
        print(f"  涨停 {len(df)} 家")
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return None
    
    # 3. 评分筛选
    print("\n📊 评分筛选中...")
    results = []
    avoid_count = 0
    
    for _, row in df.iterrows():
        stock = {
            "name": str(row.get("名称", "")),
            "code": str(row.get("代码", "")),
            "price": sf(row.get("最新价")),
            "change_pct": sf(row.get("涨跌幅")),
            "turnover": sf(row.get("换手率")),
            "amount": sf(row.get("成交额")),
            "limit_times": int(sf(row.get("连板数", 1))),
            "reason": str(row.get("所属行业", "")),
        }
        
        # 回避条件检查
        avoid, avoid_reason = check_avoid_conditions(stock)
        if avoid:
            avoid_count += 1
            continue
        
        # 评分
        score, score_reason = score_ultra_short(stock, sentiment)
        if score > 0:
            stock["score"] = score
            stock["avoid_reason"] = avoid_reason
            results.append(stock)
    
    print(f"  回避: {avoid_count}家 (一字/ST/换手过高)")
    print(f"  通过: {len(results)}家")
    
    # 4. 排序
    results.sort(key=lambda x: -x["score"])
    
    # 5. 输出Top10
    print(f"\n🏆 超短推荐 Top 10:")
    print(f"{'排名':>4} {'代码':>8} {'名称':>8} {'现价':>8} {'涨幅':>7} {'换手':>7} {'连板':>4} {'成交额':>10} {'题材':>8} {'评分':>5}")
    print("-" * 80)
    for i, s in enumerate(results[:10]):
        print(f"{i+1:>4} {s['code']:>8} {s['name']:>8} {s['price']:>8.2f} {s['change_pct']:>+7.2f} {s['turnover']:>7.2f} {s['limit_times']:>4} {s['amount']/1e8:>9.2f}亿 {s['reason']:>8} {s['score']:>5}")
    
    # 6. 保存结果
    output = {
        "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "strategy": "超短策略 v1.0 - 分歧转一致",
        "market_sentiment": sentiment,
        "market_avoid": market_avoid,
        "scan_count": len(df),
        "avoid_count": avoid_count,
        "pass_count": len(results),
        "recommendations": results[:3],
        "top10": results[:10],
    }
    
    out_path = os.path.join(OUTPUT_DIR, "ultra_scan.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    
    # 同步canvas
    import shutil
    canvas_path = os.path.expanduser("~/.openclaw/canvas/stock-analyzer/data/ultra_scan.json")
    os.makedirs(os.path.dirname(canvas_path), exist_ok=True)
    shutil.copy2(out_path, canvas_path)
    
    # 7. 输出推荐
    recs = results[:3]
    if recs:
        print(f"\n{'='*60}")
        print("⚡ 超短推荐 TOP 3")
        print("="*60)
        for i, s in enumerate(recs):
            print(f"\n{'🥇🥈🥉'[i]} NO.{i+1} - {s['name']} ({s['code']})")
            print(f"  现价: {s['price']:.2f} | 涨幅: {s['change_pct']:+.2f}%")
            print(f"  换手: {s['turnover']:.2f}% | 连板: {s['limit_times']}板 | 成交: {s['amount']/1e8:.2f}亿")
            print(f"  题材: {s['reason']} | 评分: {s['score']}")
            
            # 买入策略
            buy_low = s['price'] * 0.97
            buy_high = s['price'] * 1.01
            stop_loss = s['price'] * 0.95
            target = s['price'] * 1.10
            print(f"  📌 策略:")
            print(f"    买入: {buy_low:.2f} - {buy_high:.2f}")
            print(f"    止损: {stop_loss:.2f} (-5%)")
            print(f"    目标: {target:.2f} (+10%)")
    
    print(f"\n💾 已保存: {out_path}")
    print("=" * 60)
    
    return output


if __name__ == "__main__":
    scan_ultra_short()
