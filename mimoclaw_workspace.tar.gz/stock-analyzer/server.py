#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
StockPulse 服务器 - 用户认证 + 激活码管理
"""

import os
import json
import hashlib
import secrets
import time
from datetime import datetime, timedelta
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import threading

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
CODES_FILE = os.path.join(DATA_DIR, "activation_codes.json")
SESSIONS_FILE = os.path.join(DATA_DIR, "sessions.json")

os.makedirs(DATA_DIR, exist_ok=True)

# ── 数据管理 ──

def load_json(path, default=None):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default if default is not None else {}

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

# ── 初始化超级管理员 ──

def init_admin():
    users = load_json(USERS_FILE, {"users": []})
    admin_exists = any(u.get("role") == "super_admin" for u in users["users"])
    if not admin_exists:
        users["users"].append({
            "id": "admin_001",
            "username": "982628468",
            "password": hash_pw("1008611.+"),
            "email": "982628468@qq.com",
            "nickname": "chentong",
            "role": "super_admin",
            "created_at": datetime.now().isoformat(),
            "status": "active",
            "activation_code": None,
        })
        save_json(USERS_FILE, users)
        print("✅ 超级管理员已创建: 982628468")

# ── 激活码管理 ──

def generate_codes(count=1, days=30, prefix="SP"):
    codes = load_json(CODES_FILE, {"codes": []})
    new_codes = []
    for _ in range(count):
        code = f"{prefix}-{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}"
        codes["codes"].append({
            "code": code,
            "days": days,
            "created_at": datetime.now().isoformat(),
            "expires_at": None,
            "used_by": None,
            "used_at": None,
            "status": "unused",
        })
        new_codes.append(code)
    save_json(CODES_FILE, codes)
    return new_codes

def activate_code(code, user_id):
    codes = load_json(CODES_FILE, {"codes": []})
    for c in codes["codes"]:
        if c["code"] == code and c["status"] == "unused":
            c["status"] = "used"
            c["used_by"] = user_id
            c["used_at"] = datetime.now().isoformat()
            c["expires_at"] = (datetime.now() + timedelta(days=c["days"])).isoformat()
            save_json(CODES_FILE, codes)
            return True, c["expires_at"]
    return False, None

def check_user_access(user_id):
    """检查用户是否有有效访问权限"""
    users = load_json(USERS_FILE, {"users": []})
    for u in users["users"]:
        if u["id"] == user_id:
            if u["role"] == "super_admin":
                return True, "永久"
            # 检查激活码
            if u.get("activation_code"):
                codes = load_json(CODES_FILE, {"codes": []})
                for c in codes["codes"]:
                    if c["code"] == u["activation_code"] and c["status"] == "used":
                        exp = datetime.fromisoformat(c["expires_at"])
                        if exp > datetime.now():
                            return True, exp.strftime("%Y-%m-%d %H:%M")
            break
    return False, None

# ── 会话管理 ──

def create_session(user_id):
    sessions = load_json(SESSIONS_FILE, {"sessions": {}})
    token = secrets.token_hex(32)
    sessions["sessions"][token] = {
        "user_id": user_id,
        "created_at": datetime.now().isoformat(),
        "expires_at": (datetime.now() + timedelta(days=7)).isoformat(),
    }
    # 清理过期会话
    now = datetime.now()
    expired = [k for k, v in sessions["sessions"].items()
               if datetime.fromisoformat(v["expires_at"]) < now]
    for k in expired:
        del sessions["sessions"][k]
    save_json(SESSIONS_FILE, sessions)
    return token

def verify_session(token):
    sessions = load_json(SESSIONS_FILE, {"sessions": {}})
    s = sessions["sessions"].get(token)
    if s:
        exp = datetime.fromisoformat(s["expires_at"])
        if exp > datetime.now():
            return s["user_id"]
    return None

# ── HTTP 处理 ──

class StockPulseHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.path.dirname(os.path.abspath(__file__)), **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # 页面路由
        if path == "/" or path == "/index.html":
            self.send_file("index.html")
        elif path == "/login":
            self.send_file("login.html")
        elif path == "/admin":
            self.send_file("admin.html")
        elif path == "/api/check":
            self.handle_check_access()
        elif path == "/api/codes":
            self.handle_list_codes()
        elif path == "/api/users":
            self.handle_list_users()
        elif path.startswith("/data/") or path.endswith((".js", ".css", ".png", ".ico")):
            super().do_GET()
        else:
            super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len).decode("utf-8") if content_len > 0 else "{}"
        try:
            data = json.loads(body) if body else {}
        except:
            data = parse_qs(body)

        if path == "/api/login":
            self.handle_login(data)
        elif path == "/api/register":
            self.handle_register(data)
        elif path == "/api/activate":
            self.handle_activate(data)
        elif path == "/api/generate_codes":
            self.handle_generate_codes(data)
        elif path == "/api/delete_code":
            self.handle_delete_code(data)
        else:
            self.send_json(404, {"error": "Not found"})

    def send_file(self, filename):
        filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
        if os.path.exists(filepath):
            with open(filepath, "rb") as f:
                content = f.read()
            self.send_response(200)
            if filename.endswith(".html"):
                self.send_header("Content-Type", "text/html; charset=utf-8")
            elif filename.endswith(".js"):
                self.send_header("Content-Type", "application/javascript")
            elif filename.endswith(".css"):
                self.send_header("Content-Type", "text/css")
            else:
                self.send_header("Content-Type", "application/octet-stream")
            self.end_headers()
            self.wfile.write(content)
        else:
            self.send_json(404, {"error": "File not found"})

    def send_json(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def get_token_user(self):
        token = self.headers.get("Authorization", "").replace("Bearer ", "")
        if not token:
            cookie = self.headers.get("Cookie", "")
            for part in cookie.split(";"):
                if "token=" in part:
                    token = part.split("token=")[1].strip()
        return verify_session(token)

    def handle_login(self, data):
        users = load_json(USERS_FILE, {"users": []})
        username = data.get("username", "")
        password = data.get("password", "")
        for u in users["users"]:
            if u["username"] == username and u["password"] == hash_pw(password):
                if u["status"] != "active":
                    self.send_json(403, {"error": "账号已被禁用"})
                    return
                token = create_session(u["id"])
                access, expire = check_user_access(u["id"])
                self.send_json(200, {
                    "token": token,
                    "user": {
                        "id": u["id"],
                        "username": u["username"],
                        "nickname": u.get("nickname", ""),
                        "role": u.get("role", "user"),
                        "access": access,
                        "expire": expire,
                    }
                })
                return
        self.send_json(401, {"error": "用户名或密码错误"})

    def handle_register(self, data):
        users = load_json(USERS_FILE, {"users": []})
        username = data.get("username", "")
        password = data.get("password", "")
        email = data.get("email", "")
        nickname = data.get("nickname", "")
        code = data.get("activation_code", "")

        if not username or not password:
            self.send_json(400, {"error": "用户名和密码必填"})
            return

        # 检查用户名重复
        if any(u["username"] == username for u in users["users"]):
            self.send_json(400, {"error": "用户名已存在"})
            return

        # 验证激活码
        if code:
            codes = load_json(CODES_FILE, {"codes": []})
            valid = any(c["code"] == code and c["status"] == "unused" for c in codes["codes"])
            if not valid:
                self.send_json(400, {"error": "激活码无效或已使用"})
                return

        user_id = f"user_{secrets.token_hex(6)}"
        user = {
            "id": user_id,
            "username": username,
            "password": hash_pw(password),
            "email": email,
            "nickname": nickname or username,
            "role": "user",
            "created_at": datetime.now().isoformat(),
            "status": "active",
            "activation_code": code if code else None,
        }
        users["users"].append(user)
        save_json(USERS_FILE, users)

        # 激活码
        if code:
            activate_code(code, user_id)

        token = create_session(user_id)
        self.send_json(200, {"token": token, "user": {"id": user_id, "username": username, "nickname": user["nickname"], "role": "user"}})

    def handle_activate(self, data):
        user_id = self.get_token_user()
        if not user_id:
            self.send_json(401, {"error": "未登录"})
            return
        code = data.get("code", "")
        ok, expires = activate_code(code, user_id)
        if ok:
            # 更新用户的激活码
            users = load_json(USERS_FILE, {"users": []})
            for u in users["users"]:
                if u["id"] == user_id:
                    u["activation_code"] = code
                    break
            save_json(USERS_FILE, users)
            self.send_json(200, {"success": True, "expires": expires})
        else:
            self.send_json(400, {"error": "激活码无效或已使用"})

    def handle_check_access(self):
        user_id = self.get_token_user()
        if not user_id:
            self.send_json(200, {"access": False})
            return
        access, expire = check_user_access(user_id)
        self.send_json(200, {"access": access, "expire": expire})

    def handle_list_codes(self):
        user_id = self.get_token_user()
        if not user_id:
            self.send_json(401, {"error": "未登录"})
            return
        users = load_json(USERS_FILE, {"users": []})
        user = next((u for u in users["users"] if u["id"] == user_id), None)
        if not user or user.get("role") != "super_admin":
            self.send_json(403, {"error": "无权限"})
            return
        codes = load_json(CODES_FILE, {"codes": []})
        self.send_json(200, codes)

    def handle_list_users(self):
        user_id = self.get_token_user()
        if not user_id:
            self.send_json(401, {"error": "未登录"})
            return
        users = load_json(USERS_FILE, {"users": []})
        user = next((u for u in users["users"] if u["id"] == user_id), None)
        if not user or user.get("role") != "super_admin":
            self.send_json(403, {"error": "无权限"})
            return
        safe_users = []
        for u in users["users"]:
            safe_users.append({
                "id": u["id"],
                "username": u["username"],
                "nickname": u.get("nickname", ""),
                "email": u.get("email", ""),
                "role": u.get("role", "user"),
                "status": u.get("status", "active"),
                "created_at": u.get("created_at", ""),
                "activation_code": u.get("activation_code"),
            })
        self.send_json(200, {"users": safe_users})

    def handle_generate_codes(self, data):
        user_id = self.get_token_user()
        if not user_id:
            self.send_json(401, {"error": "未登录"})
            return
        users = load_json(USERS_FILE, {"users": []})
        user = next((u for u in users["users"] if u["id"] == user_id), None)
        if not user or user.get("role") != "super_admin":
            self.send_json(403, {"error": "无权限"})
            return
        count = data.get("count", 1)
        days = data.get("days", 30)
        prefix = data.get("prefix", "SP")
        new_codes = generate_codes(count, days, prefix)
        self.send_json(200, {"codes": new_codes})

    def handle_delete_code(self, data):
        user_id = self.get_token_user()
        if not user_id:
            self.send_json(401, {"error": "未登录"})
            return
        users = load_json(USERS_FILE, {"users": []})
        user = next((u for u in users["users"] if u["id"] == user_id), None)
        if not user or user.get("role") != "super_admin":
            self.send_json(403, {"error": "无权限"})
            return
        code_to_del = data.get("code", "")
        codes = load_json(CODES_FILE, {"codes": []})
        codes["codes"] = [c for c in codes["codes"] if c["code"] != code_to_del]
        save_json(CODES_FILE, codes)
        self.send_json(200, {"success": True})

    def log_message(self, format, *args):
        pass  # 静默日志


def run_server(port=8080):
    init_admin()
    # 预生成一些激活码
    codes = load_json(CODES_FILE, {"codes": []})
    if len(codes["codes"]) == 0:
        new = generate_codes(5, 30, "SP")
        print(f"✅ 已生成 5 个激活码 (30天):")
        for c in new:
            print(f"   {c}")

    server = HTTPServer(("0.0.0.0", port), StockPulseHandler)
    print(f"🚀 StockPulse 服务器启动: http://0.0.0.0:{port}")
    server.serve_forever()


if __name__ == "__main__":
    run_server()
