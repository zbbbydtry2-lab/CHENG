#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
波段智能选股引擎 v3.1
使用新浪接口获取全量数据，速度更快
"""

import akshare as ak
import pandas as pd
import numpy as np
import json
import os
import time
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def sf(val, default=0.0):
    try:
        v = float(val)
        return v if pd.notna(v) else default
    except:
        return default


def is_st(name):
    if pd.isna(name): return True
    n = str(name).upper()
    return 'ST' in n or '*ST' in n or n.startswith('S ')


def calc_rsi_from_prices(prices, period=14):
    """从价格列表计算RSI"""
    if len(prices) < period + 1:
        return 50
    deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
    gains = [d if d > 0 else 0 for d in deltas[-period:]]
    losses = [-d if d < 0 else 0 for d in deltas[-period:]]
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def get_stock_history(code, days=30):
    """获取单只股票历史数据"""
    prefix = 'sz' if code.startswith(('0', '3')) else 'sh'
    try:
        df = ak.stock_zh_a_daily(symbol=prefix+code, adjust='qfq')
        if df is not None and len(df) > 5:
            return df.tail(days)
    except:
        pass
    return None


def score_stock_swing(row, hot_industries):
    """波段策略评分"""
    score = 0
    name = str(row.get('名称', ''))
    code = str(row.get('代码', ''))
    price = sf(row.get('最新价'))
    pct = sf(row.get('涨跌幅'))
    volume = sf(row.get('成交量'))
    amount = sf(row.get('成交额'))

    # ── 排除条件 ──
    if is_st(name):
        return -1, "ST"
    if price < 3 or price > 500:
        return -1, "价格异常"
    if volume <= 0:
        return -1, "停牌"
    if pct < -5:
        return -1, "当日大跌"

    # ── 评分 ──
    # 1. 当日涨幅 (20分)
    if 2 <= pct <= 7:
        score += 20
    elif 0 < pct < 2:
        score += 10
    elif 7 < pct < 10:
        score += 15
    elif pct >= 9.9:
        score += 25  # 涨停

    # 2. 成交额 (15分) - 流动性
    if amount > 5e8:
        score += 15
    elif amount > 2e8:
        score += 10
    elif amount > 1e8:
        score += 5

    # 3. 市值适中 (10分)
    # 用成交额/换手率估算市值
    turnover_est = sf(row.get('换手率', 0))
    if turnover_est > 0:
        mv_est = amount / (turnover_est / 100)
        if 50e8 < mv_est < 500e8:
            score += 10
        elif 20e8 < mv_est < 1000e8:
            score += 5

    return score, ""


def fetch_and_score():
    """获取数据并评分"""
    print("📊 获取全量A股行情 (新浪)...")
    time.sleep(2)
    df = ak.stock_zh_a_spot()
    if df is None or df.empty:
        print("❌ 获取失败")
        return None
    print(f"  获取到 {len(df)} 只股票")

    # 获取涨停股
    print("🔴 获取涨停股...")
    limit_up_codes = set()
    hot_industries = []
    try:
        time.sleep(2)
        ldf = ak.stock_zt_pool_em(date=datetime.now().strftime("%Y%m%d"))
        if ldf is not None and not ldf.empty:
            limit_up_codes = set(ldf['代码'].astype(str).tolist())
            print(f"  涨停 {len(ldf)} 家")
            if '所属行业' in ldf.columns:
                ic = ldf['所属行业'].value_counts().head(10)
                hot_industries = [{'name': k, 'count': int(v)} for k, v in ic.items()]
                print("  热点题材:")
                for h in hot_industries[:5]:
                    print(f"    {h['name']}: {h['count']}家涨停")
    except Exception as e:
        print(f"  ⚠️ 涨停获取失败: {e}")

    # 评分
    print(f"\n📊 扫描评分中...")
    results = []
    for _, row in df.iterrows():
        score, reason = score_stock_swing(row, hot_industries)
        if score > 0:
            results.append({
                'code': str(row.get('代码', '')),
                'name': str(row.get('名称', '')),
                'price': sf(row.get('最新价')),
                'pct_1d': sf(row.get('涨跌幅')),
                'volume': sf(row.get('成交量')),
                'amount': sf(row.get('成交额')),
                'score': score,
            })

    print(f"  通过初筛: {len(results)} 只")

    # 对Top20获取历史数据做精细评分
    results.sort(key=lambda x: x['score'], reverse=True)
    top30 = results[:30]

    print(f"\n📈 Top30 精细分析 (获取历史数据)...")
    final = []
    for i, s in enumerate(top30):
        code = s['code']
        # 清理代码 (去掉市场前缀)
        clean_code = code.replace('sz', '').replace('sh', '').replace('bj', '')
        print(f"  [{i+1}/30] {s['name']}({clean_code})...", end=" ", flush=True)

        hist = get_stock_history(clean_code, days=30)
        if hist is not None and len(hist) >= 20:
            closes = hist['close'].tolist()
            current = s['price']

            # 计算均线
            ma5 = np.mean(closes[-5:])
            ma10 = np.mean(closes[-10:])
            ma20 = np.mean(closes[-20:])

            # 计算RSI
            rsi = calc_rsi_from_prices(closes)

            # 计算近5日涨幅
            pct_5d = (closes[-1] / closes[-6] - 1) * 100 if len(closes) >= 6 else 0

            # 阴跌判断
            if len(closes) >= 20:
                pct_20d = (closes[-1] / closes[-20] - 1) * 100
                if pct_20d < -10:
                    print(f"阴跌{pct_20d:.1f}%")
                    continue

            # 趋势分
            trend_score = 0
            if ma5 > ma10 > ma20:
                trend_score = 30
            elif ma5 > ma10:
                trend_score = 20
            elif current > ma20:
                trend_score = 10

            # 回踩分
            pullback_score = 0
            if ma10 > 0:
                bias = abs(current - ma10) / ma10 * 100
                if bias < 3:
                    pullback_score = 20
                elif bias < 5:
                    pullback_score = 15
                elif bias < 8:
                    pullback_score = 8

            # RSI分
            rsi_score = 0
            if 40 <= rsi <= 65:
                rsi_score = 15
            elif 35 <= rsi <= 70:
                rsi_score = 10

            # 总分
            total_score = s['score'] + trend_score + pullback_score + rsi_score

            s.update({
                'ma5': round(ma5, 2),
                'ma10': round(ma10, 2),
                'ma20': round(ma20, 2),
                'rsi': round(rsi, 1),
                'pct_5d': round(pct_5d, 2),
                'trend_score': trend_score,
                'pullback_score': pullback_score,
                'rsi_score': rsi_score,
                'final_score': total_score,
                'trend': '多头排列' if ma5 > ma10 > ma20 else ('短期多头' if ma5 > ma10 else '震荡'),
            })
            final.append(s)
            print(f"✅ 评分{total_score} 趋势{trend_score} 回踩{pullback_score} RSI{rsi:.0f}")
        else:
            print("数据不足")
        time.sleep(0.3)

    # 最终排序
    final.sort(key=lambda x: x.get('final_score', 0), reverse=True)

    return {
        'update_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'scan_count': len(df),
        'pass_count': len(final),
        'hot_industries': hot_industries,
        'limit_up_count': len(limit_up_codes),
        'recommendations': final[:3],
        'top10': final[:10],
    }


def main():
    print("=" * 60)
    print("🚀 波段智能选股引擎 v3.1")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    result = fetch_and_score()
    if not result:
        return

    recs = result['recommendations']
    top10 = result['top10']

    print("\n" + "=" * 60)
    print("🏆 波段推荐 TOP 3")
    print("=" * 60)
    for i, s in enumerate(recs):
        print(f"\n{'🥇🥈🥉'[i]} NO.{i+1} - {s['name']} ({s['code']})")
        print(f"  现价: {s['price']:.2f} | 今日: {s['pct_1d']:+.2f}% | 5日: {s.get('pct_5d',0):+.2f}%")
        print(f"  MA5: {s.get('ma5',0):.2f} | MA10: {s.get('ma10',0):.2f} | MA20: {s.get('ma20',0):.2f}")
        print(f"  RSI: {s.get('rsi',0):.1f} | 趋势: {s.get('trend','')}")
        print(f"  评分: {s.get('final_score',0)} (趋势{s.get('trend_score',0)}+回踩{s.get('pullback_score',0)}+RSI{s.get('rsi_score',0)}+基础{s['score']})")

    print(f"\n📊 Top 10:")
    for i, s in enumerate(top10):
        print(f"  {i+1:>2}. {s['name']:>6} {s['code']:>8} {s['price']:>8.2f} {s['pct_1d']:>+6.2f}% 趋势:{s.get('trend',''):>6} 评分:{s.get('final_score',0):>3}")

    # 保存
    out_path = os.path.join(OUTPUT_DIR, "swing_scan.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    import shutil
    canvas_path = os.path.expanduser("~/.openclaw/canvas/stock-analyzer/data/swing_scan.json")
    os.makedirs(os.path.dirname(canvas_path), exist_ok=True)
    shutil.copy2(out_path, canvas_path)

    print(f"\n💾 已保存: {out_path}")
    print("=" * 60)


if __name__ == "__main__":
    main()
