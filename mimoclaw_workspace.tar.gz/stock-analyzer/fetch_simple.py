#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""简化版数据采集 - 直接获取核心数据"""

import akshare as ak
import json
import os
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUTPUT_DIR, exist_ok=True)

def sf(val, default=0.0):
    try:
        import pandas as pd
        v = float(val)
        return v if pd.notna(v) else default
    except:
        return default

print("🚀 开始采集...")

# 1. 大盘指数
print("📊 指数...")
indices = []
try:
    df = ak.stock_zh_index_spot_em()
    for code, name in [("000001", "上证指数"), ("399001", "深证成指"), ("399006", "创业板指")]:
        row = df[df["代码"] == code]
        if not row.empty:
            r = row.iloc[0]
            indices.append({
                "name": name, "code": code,
                "price": sf(r.get("最新价")),
                "change_pct": sf(r.get("涨跌幅")),
                "change_amt": sf(r.get("涨跌额")),
            })
except Exception as e:
    print(f"  ⚠️ 指数: {e}")

# 2. 涨停
print("🔴 涨停...")
limit_up = []
limit_up_count = 0
try:
    df = ak.stock_zt_pool_em(date=datetime.now().strftime("%Y%m%d"))
    limit_up_count = len(df)
    for _, r in df.head(25).iterrows():
        limit_up.append({
            "name": str(r.get("名称", "")),
            "code": str(r.get("代码", "")),
            "price": sf(r.get("最新价")),
            "change_pct": sf(r.get("涨跌幅")),
            "turnover": sf(r.get("换手率")),
            "amount": sf(r.get("成交额")),
            "reason": str(r.get("所属行业", "")),
            "limit_times": int(sf(r.get("连板数", 1))),
        })
except Exception as e:
    print(f"  ⚠️ 涨停: {e}")

# 3. 跌停
print("🟢 跌停...")
limit_down_count = 0
try:
    df = ak.stock_zt_pool_dtgc_em(date=datetime.now().strftime("%Y%m%d"))
    limit_down_count = len(df)
except:
    pass

# 4. 炸板
print("💥 炸板...")
broken_count = 0
try:
    df = ak.stock_zt_pool_zbgc_em(date=datetime.now().strftime("%Y%m%d"))
    broken_count = len(df)
except:
    pass

# 5. 板块资金
print("💰 板块...")
sectors = []
try:
    df = ak.stock_sector_fund_flow_rank(indicator="今日", sector_type="行业资金流")
    for _, r in df.head(12).iterrows():
        sectors.append({
            "name": str(r.get("名称", "")),
            "change_pct": sf(r.get("今日涨跌幅")),
            "main_net": sf(r.get("今日主力净流入-净额")),
            "main_pct": sf(r.get("今日主力净流入-净占比")),
        })
except Exception as e:
    print(f"  ⚠️ 板块: {e}")

# 6. 北向
print("🏦 北向...")
north_flow = 0
try:
    df = ak.stock_hsgt_north_net_flow_in_em(symbol="北向")
    if not df.empty:
        north_flow = sf(df.iloc[-1].get("当日净流入", 0))
except:
    pass

# 7. 排序推荐
def calc_score(s):
    score = 0
    tr = s.get("turnover", 0)
    if 5 <= tr <= 20: score += 30
    score += s.get("limit_times", 1) * 20
    for t in ["AI", "算力", "低空", "飞行", "光模块", "CPO", "固态", "电池", "芯片", "华为"]:
        if t in s.get("reason", ""):
            score += 15; break
    return score

for s in limit_up:
    s["score"] = calc_score(s)
ranked = sorted(limit_up, key=lambda x: x["score"], reverse=True)

# 板块按资金排序
sector_ranked = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)

data = {
    "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "market": {
        "indices": indices,
        "limit_up_count": limit_up_count,
        "limit_down_count": limit_down_count,
        "broken_count": broken_count,
        "north_flow": north_flow,
    },
    "limit_up_stocks": ranked[:20],
    "sectors": sector_ranked[:10],
    "recommendations": ranked[:3],
}

out = os.path.join(OUTPUT_DIR, "market_data.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print(f"\n✅ 完成! 涨停 {limit_up_count} | 跌停 {limit_down_count} | 炸板 {broken_count}")
print(f"🎯 推荐: {', '.join(s['name'] for s in ranked[:3])}")
print(f"📁 {out}")
