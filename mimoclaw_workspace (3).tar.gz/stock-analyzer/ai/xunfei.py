#!/usr/bin/env python3
"""
讯飞星辰 AI 智能体
OpenAI兼容格式接入
"""
import json
import os
import urllib.request
import urllib.error
from typing import Dict, List


CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "cache", "xunfei_config.json")
API_URL = "https://spark-api-open.xf-yun.com/v1/chat/completions"
MODEL = "generalv3.5"


# ─── 配置管理 ───

def _load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {}


def _save_config(cfg: dict):
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def get_api_key() -> str:
    return _load_config().get("api_key", "")


def set_api_key(key: str) -> bool:
    cfg = _load_config()
    cfg["api_key"] = key
    _save_config(cfg)
    return True


def get_status() -> dict:
    key = get_api_key()
    return {
        "configured": bool(key),
        "key_preview": key[:12] + "***" if len(key) > 12 else ("已配置" if key else "未配置"),
        "model": MODEL,
        "api_url": API_URL,
    }


def test_connection() -> dict:
    key = get_api_key()
    if not key:
        return {"ok": False, "error": "API Key 未配置"}
    try:
        result = _call_xunfei("你是AI助手", "请回复连接成功", max_tokens=50)
        if "Error" in result or "error" in result:
            return {"ok": False, "error": result}
        return {"ok": True, "response": result[:100]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ─── 调用 ───

def _call_xunfei(system: str, user: str, temperature: float = 0.7, max_tokens: int = 2000) -> str:
    api_key = get_api_key()
    if not api_key:
        return "[Error] 讯飞 API Key 未配置"

    payload = json.dumps({
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return f"[讯飞 HTTP {e.code}] {body[:200]}"
    except Exception as e:
        return f"[讯飞 Error] {e}"


# ─── 分析功能 ───

SYSTEM_PROMPT = """你是一个专业的A股超短线选股AI分析师。
从候选池中精选最强的1-3只龙头股，给出买入理由和风险提示。
输出要求：精选1-3只，每只给名称、代码、推荐理由、风险提示。用中文回复。"""


def analyze_leaders(candidates: List[Dict], market: Dict) -> Dict:
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})
    sectors = market.get("sectors", [])

    market_info = f"情绪{sent.get('temperature','--')}° 涨停{stats.get('limit_up_count','--')}家 跌停{stats.get('limit_down_count','--')}家"
    hot = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]
    market_info += f" 最强板块：{', '.join([s['name'] for s in hot])}"

    stock_lines = []
    for i, s in enumerate(candidates, 1):
        line = f"{i}. {s['name']}({s['code']}) {s.get('sector','')} ¥{s.get('price',0):.2f} {s.get('change_pct',0):+.2f}% 量比{s.get('volume_ratio',0):.1f} 换手{s.get('turnover',0):.1f}% 连板{s.get('limit_times',1)}"
        stock_lines.append(line)

    user_msg = f"{market_info}\n\n候选池：\n{chr(10).join(stock_lines)}\n\n请精选1-3只最强龙头。"

    answer = _call_xunfei(SYSTEM_PROMPT, user_msg, temperature=0.6)
    return {"answer": answer, "confidence": 75, "model": f"xunfei-{MODEL}"}


def chat(question: str, market: Dict = None) -> Dict:
    context = ""
    if market:
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})
        context = f"市场：情绪{sent.get('temperature','--')}° {stats.get('limit_up_count','--')}家涨停"

    user_msg = f"{context}\n\n{question}" if context else question
    answer = _call_xunfei("你是专业A股投资顾问", user_msg)
    return {"answer": answer, "confidence": 75, "model": f"xunfei-{MODEL}"}
