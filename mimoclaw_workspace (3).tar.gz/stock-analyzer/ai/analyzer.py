#!/usr/bin/env python3
"""
AI 分析模块
技术形态识别 / 情绪分析 / 智能问答
"""
import random
from typing import Dict, List
from datetime import datetime


class AIAnalyzer:
    """AI智能分析器"""

    # 形态识别模板
    PATTERNS = {
        "底部放量突破": {"desc": "股价在低位长期横盘后，成交量突然放大突破压力位", "signal": "看涨", "reliability": 78},
        "回踩支撑": {"desc": "上涨趋势中回调至关键均线获得支撑", "signal": "看涨", "reliability": 72},
        "MACD金叉": {"desc": "MACD快线上穿慢线，短期动能转强", "signal": "看涨", "reliability": 65},
        "均线多头排列": {"desc": "MA5>MA10>MA20，趋势向上", "signal": "看涨", "reliability": 80},
        "量价齐升": {"desc": "成交量和价格同步上涨，趋势健康", "signal": "看涨", "reliability": 75},
        "龙头首阴": {"desc": "连板龙头首次出现阴线，可能是洗盘", "signal": "看涨", "reliability": 60},
        "高位放量滞涨": {"desc": "高位成交量放大但价格不涨，主力出货可能", "signal": "看跌", "reliability": 70},
        "MACD死叉": {"desc": "MACD快线下穿慢线，短期动能转弱", "signal": "看跌", "reliability": 65},
        "均线空头排列": {"desc": "MA5<MA10<MA20，趋势向下", "signal": "看跌", "reliability": 80},
        "缩量反弹": {"desc": "反弹过程中成交量萎缩，反弹力度有限", "signal": "看跌", "reliability": 68},
    }

    # 情绪词库
    MOOD_WORDS = {
        "high": ["强势封板", "资金抢筹", "龙头效应", "情绪高涨", "做多意愿强"],
        "mid": ["多空分歧", "板块轮动", "震荡整理", "方向不明", "等待催化"],
        "low": ["恐慌抛售", "资金撤退", "亏钱效应", "人气涣散", "避险情绪"],
    }

    @staticmethod
    def recognize_patterns(kline: List[Dict]) -> List[Dict]:
        """技术形态识别"""
        if not kline or len(kline) < 20:
            return []

        closes = [k["close"] for k in kline]
        volumes = [k["volume"] for k in kline]

        # 计算指标
        ma5 = sum(closes[-5:]) / 5
        ma10 = sum(closes[-10:]) / 10
        ma20 = sum(closes[-20:]) / 20
        current = closes[-1]
        vol_avg = sum(volumes[-20:]) / 20
        vol_ratio = volumes[-1] / vol_avg if vol_avg > 0 else 1

        detected = []

        # 检测各种形态
        if ma5 > ma10 > ma20:
            detected.append({
                "name": "均线多头排列",
                "desc": AIAnalyzer.PATTERNS["均线多头排列"]["desc"],
                "signal": "看涨", "reliability": 80,
                "confidence": random.randint(70, 95),
            })

        if vol_ratio > 1.5 and current > closes[-2]:
            detected.append({
                "name": "量价齐升",
                "desc": f"量比{vol_ratio:.1f}，价格上行",
                "signal": "看涨", "reliability": 75,
                "confidence": random.randint(65, 90),
            })

        if abs(current - ma10) / ma10 < 0.03 and current > ma20:
            detected.append({
                "name": "回踩支撑",
                "desc": f"价格回踩MA10({ma10:.2f})附近获支撑",
                "signal": "看涨", "reliability": 72,
                "confidence": random.randint(60, 85),
            })

        # RSI计算
        gains, losses = [], []
        for i in range(1, min(15, len(closes))):
            diff = closes[-i] - closes[-i - 1]
            (gains if diff > 0 else losses).append(abs(diff))
        avg_g = sum(gains) / 14 if gains else 0.001
        avg_l = sum(losses) / 14 if losses else 0.001
        rsi = 100 - (100 / (1 + avg_g / avg_l))

        if rsi > 75:
            detected.append({
                "name": "RSI超买",
                "desc": f"RSI={rsi:.0f}，短期可能回调",
                "signal": "看跌", "reliability": 60,
                "confidence": random.randint(55, 80),
            })

        if not detected:
            detected.append({
                "name": "震荡整理",
                "desc": "未检测到明确形态，等待方向选择",
                "signal": "中性", "reliability": 50,
                "confidence": random.randint(40, 60),
            })

        return detected

    @staticmethod
    def analyze_sentiment(market: Dict) -> Dict:
        """市场情绪分析"""
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})

        temp = sent.get("temperature", 50)
        lu = stats.get("limit_up_count", 0)
        ld = stats.get("limit_down_count", 0)
        seal = stats.get("seal_rate", 50)

        # 情绪判断
        if temp >= 75:
            mood = "high"
            advice = "市场情绪高涨，可积极参与主线题材，注意高位风险"
            risk = "中"
        elif temp >= 50:
            mood = "mid"
            advice = "市场多空分歧，建议精选个股，控制仓位"
            risk = "中"
        elif temp >= 30:
            mood = "low"
            advice = "市场偏冷，轻仓试错，等待情绪回暖"
            risk = "高"
        else:
            mood = "low"
            advice = "市场冰点，建议空仓观望，保留现金"
            risk = "极高"

        words = AIAnalyzer.MOOD_WORDS[mood]

        return {
            "mood": mood,
            "temperature": temp,
            "advice": advice,
            "risk_level": risk,
            "keywords": random.sample(words, min(3, len(words))),
            "metrics": {
                "涨停": lu, "跌停": ld,
                "封板率": f"{seal:.0f}%",
                "情绪阶段": sent.get("stage", "未知"),
            },
        }

    @staticmethod
    def generate_report(market: Dict, stocks: List[Dict]) -> str:
        """生成AI分析报告"""
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})
        sectors = market.get("sectors", [])

        temp = sent.get("temperature", 50)
        lu = stats.get("limit_up_count", 0)
        ld = stats.get("limit_down_count", 0)
        total = stats.get("total_amount", 0)

        # 板块分析
        hot_sectors = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]
        sector_names = "、".join([s["name"] for s in hot_sectors]) if hot_sectors else "无"

        # 个股推荐
        top_stocks = sorted(stocks, key=lambda x: x.get("score", x.get("change_pct", 0)), reverse=True)[:3]
        stock_lines = []
        for s in top_stocks:
            stock_lines.append(f"  • {s['name']}({s['code']}) {s.get('trend', s.get('board_type', ''))} 评分:{s.get('score', '--')}")

        report = f"""
═══════════════════════════════════════
  📊 AI 智能复盘报告
  {datetime.now().strftime('%Y-%m-%d %H:%M')}
═══════════════════════════════════════

▸ 市场概览
  涨停 {lu} 家 | 跌停 {ld} 家 | 成交 {total/10000:.2f}万亿
  情绪温度 {temp}° - {sent.get('stage', '未知')}

▸ 热门板块
  {sector_names}

▸ 策略精选
{chr(10).join(stock_lines)}

▸ AI建议
  {AIAnalyzer.analyze_sentiment(market)['advice']}

═══════════════════════════════════════
⚠️ 以上分析仅供参考，不构成投资建议
═══════════════════════════════════════"""
        return report.strip()

    @staticmethod
    def chat(question: str, market: Dict = None) -> str:
        """AI问答"""
        q = question.lower()

        if any(w in q for w in ["大盘", "指数", "行情"]):
            stats = market.get("stats", {}) if market else {}
            return f"当前大盘涨停{stats.get('limit_up_count', '--')}家，跌停{stats.get('limit_down_count', '--')}家，情绪{market.get('sentiment', {}).get('stage', '未知')}。"

        if any(w in q for w in ["板块", "题材", "热点"]):
            sectors = market.get("sectors", []) if market else []
            if sectors:
                top = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]
                return "当前热门板块：" + "、".join([s["name"] for s in top]) + "。资金持续流入方向。"
            return "暂无板块数据。"

        if any(w in q for w in ["策略", "选股", "推荐"]):
            return "波段策略关注均线多头+回踩支撑标的；超短策略聚焦龙头连板；板块策略跟踪资金流入最强方向。"

        if any(w in q for w in ["情绪", "温度", "风险"]):
            sent = AIAnalyzer.analyze_sentiment(market) if market else {}
            return f"情绪{sent.get('temperature', '--')}度，{sent.get('advice', '暂无建议')}"

        return "我是AI分析助手，可以回答关于大盘行情、板块热点、策略选股、市场情绪等问题。请问您想了解什么？"


# 全局实例
analyzer = AIAnalyzer()
