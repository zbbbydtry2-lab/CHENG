#!/usr/bin/env python3
"""
DeepSeek AI 智能体
支持可视化配置API Key
"""
import json
import os
import urllib.request
import urllib.error
from typing import Dict, List


API_URL = "https://api.deepseek.com/chat/completions"
MODEL = "deepseek-chat"

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "cache", "deepseek_config.json")


# ─── 配置管理 ───

def _load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {}


def _save_config(cfg: dict):
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def get_api_key() -> str:
    cfg = _load_config()
    return cfg.get("api_key", "")


def set_api_key(key: str) -> bool:
    cfg = _load_config()
    cfg["api_key"] = key
    _save_config(cfg)
    return True


def get_status() -> dict:
    key = get_api_key()
    return {
        "configured": bool(key),
        "key_preview": key[:8] + "***" + key[-4:] if len(key) > 12 else ("已配置" if key else "未配置"),
        "model": MODEL,
        "api_url": API_URL,
    }


def test_connection() -> dict:
    """测试API连接"""
    key = get_api_key()
    if not key:
        return {"ok": False, "error": "API Key 未配置"}

    try:
        result = _call_deepseek("你是AI助手", "请回复连接成功", key=key, max_tokens=50)
        if "Error" in result or "error" in result:
            return {"ok": False, "error": result}
        return {"ok": True, "response": result[:100]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ─── DeepSeek 调用 ───

def _call_deepseek(system: str, user: str, key: str = None, temperature: float = 0.7, max_tokens: int = 2000) -> str:
    """调用 DeepSeek API"""
    api_key = key or get_api_key()
    if not api_key:
        return "[Error] API Key 未配置，请在设置中配置 DeepSeek API Key"

    payload = json.dumps({
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return f"[DeepSeek HTTP {e.code}] {body[:200]}"
    except Exception as e:
        return f"[DeepSeek Error] {e}"


# ─── AI 分析功能 ───

SYSTEM_PROMPT = """你是一个专业的A股超短线选股AI分析师。

你的任务：
1. 分析市场数据和候选股票
2. 从候选池中精选最强的1-3只龙头股
3. 给出明确的买入理由和风险提示

分析维度：
- 板块强度：所属板块是否是当日最强方向
- 龙头辨识度：连板高度、市场关注度、板块地位
- 资金承接：量比、换手率、成交额
- 量价配合：量价齐升为佳
- 情绪共振：市场情绪温度是否配合
- 风险收益比：止损空间vs盈利空间

输出要求：
- 必须精选1-3只，不要多选
- 每只给出：名称、代码、推荐理由（2-3句话）、风险提示
- 最后给出整体操作建议
- 语气专业、简洁、有判断力
- 用中文回复"""


def analyze_leaders(candidates: List[Dict], market: Dict) -> Dict:
    """DeepSeek AI 精选龙头"""
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})
    sectors = market.get("sectors", [])

    market_summary = f"""当前市场数据：
- 情绪温度：{sent.get('temperature', '--')}°（{sent.get('stage', '未知')}）
- 涨停家数：{stats.get('limit_up_count', '--')}
- 跌停家数：{stats.get('limit_down_count', '--')}
- 封板率：{stats.get('seal_rate', '--')}%
- 北向资金：{stats.get('north_flow', '--')}亿
- 两市成交：{stats.get('total_amount', '--')}亿

板块资金流向（前5）："""

    for s in sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:5]:
        flow = s.get("main_net", 0) / 1e8
        market_summary += f"\n- {s['name']}: 涨幅{s['change_pct']:.2f}% 净流入{flow:.2f}亿"

    stock_lines = []
    for i, s in enumerate(candidates, 1):
        line = f"{i}. {s['name']}({s['code']}) {s.get('sector','')}"
        line += f" | 现价¥{s.get('price',0):.2f} 涨跌{s.get('change_pct',0):+.2f}%"
        line += f" | 量比{s.get('volume_ratio',0):.1f} 换手{s.get('turnover',0):.1f}%"
        line += f" | 连板{s.get('limit_times',1)} 评分{s.get('total_score',0)}"
        if s.get('reasons'):
            line += f" | {', '.join(s['reasons'][:2])}"
        stock_lines.append(line)

    user_msg = f"""{market_summary}

候选股票池（{len(candidates)}只）：
{chr(10).join(stock_lines)}

请从以上候选池中精选1-3只最强龙头股，给出分析和操作建议。"""

    answer = _call_deepseek(SYSTEM_PROMPT, user_msg, temperature=0.6)
    confidence = min(95, 60 + len(candidates) * 2)
    return {"answer": answer, "confidence": confidence, "model": MODEL}


def analyze_swing(stocks: List[Dict], market: Dict) -> Dict:
    """DeepSeek AI 波段分析"""
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})

    stock_lines = []
    for s in stocks:
        line = f"- {s['name']}({s['code']}) ¥{s.get('price',0):.2f} {s.get('change_pct',0):+.2f}% {s.get('trend','')}"
        line += f" MA5:{s.get('ma5','--')} MA10:{s.get('ma10','--')} 评分:{s.get('score','--')}"
        stock_lines.append(line)

    user_msg = f"""市场环境：情绪{sent.get('temperature','--')}° {stats.get('limit_up_count','--')}家涨停

波段策略推荐标的：
{chr(10).join(stock_lines)}

请分析这些波段标的的买入时机、支撑位、目标位和风险点。"""

    answer = _call_deepseek(SYSTEM_PROMPT, user_msg, temperature=0.6)
    return {"answer": answer, "confidence": 70, "model": MODEL}


def analyze_ultra(stocks: List[Dict], market: Dict) -> Dict:
    """DeepSeek AI 超短分析"""
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})

    stock_lines = []
    for s in stocks:
        line = f"- {s['name']}({s['code']}) ¥{s.get('price',0):.2f} {s.get('change_pct',0):+.2f}%"
        line += f" 连板{s.get('limit_times',1)} 量比{s.get('volume_ratio',0):.1f} {s.get('board_type','')}"
        stock_lines.append(line)

    user_msg = f"""市场环境：情绪{sent.get('temperature','--')}° {stats.get('limit_up_count','--')}家涨停 封板率{stats.get('seal_rate','--')}%

超短策略推荐标的：
{chr(10).join(stock_lines)}

请评估这些超短标的的打板风险、情绪共振度和次日预期。"""

    answer = _call_deepseek(SYSTEM_PROMPT, user_msg, temperature=0.6)
    return {"answer": answer, "confidence": 70, "model": MODEL}


def chat(question: str, market: Dict = None, stocks: List[Dict] = None) -> Dict:
    """DeepSeek AI 对话"""
    context = ""
    if market:
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})
        context = f"当前市场：情绪{sent.get('temperature','--')}° {stats.get('limit_up_count','--')}家涨停"
    if stocks:
        context += "\n当前推荐：" + ", ".join([f"{s['name']}(¥{s.get('price',0):.2f})" for s in stocks[:5]])

    user_msg = f"{context}\n\n用户问题：{question}" if context else question

    answer = _call_deepseek(
        "你是一个专业的A股投资顾问，用简洁专业的语言回答用户关于股票、策略、市场的问题。",
        user_msg,
        temperature=0.7,
    )
    return {"answer": answer, "confidence": 80, "model": MODEL}
