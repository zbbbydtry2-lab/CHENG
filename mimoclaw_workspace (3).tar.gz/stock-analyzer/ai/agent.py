#!/usr/bin/env python3
"""
AI 智能体 - 自动选股
多步分析 / 推理链 / 可交互问答
"""
import random
from typing import Dict, List, Optional
from datetime import datetime


class AIAgent:
    """AI选股智能体"""

    def __init__(self):
        self.history = []

    def select_leaders(self, candidates: List[Dict], market: Dict) -> Dict:
        """
        AI智能体从候选池中精选1-3只最强龙头
        核心逻辑: 综合评分 + 板块共振 + 资金承接 + 风险评估
        """
        if not candidates:
            return {"picks": [], "reasoning": [], "answer": "暂无符合条件的标的", "confidence": 0}

        stats = market.get("stats", {})
        sent = market.get("sentiment", {})
        sectors = market.get("sectors", [])
        temp = sent.get("temperature", 50)
        lu = stats.get("limit_up_count", 0)

        reasoning = []

        # 步骤1: 市场环境判断
        if temp >= 70:
            env_score = 3
            env_desc = f"情绪{temp}°偏暖，适合积极操作"
        elif temp >= 50:
            env_score = 2
            env_desc = f"情绪{temp}°震荡，精选龙头"
        else:
            env_score = 1
            env_desc = f"情绪{temp}°偏冷，谨慎操作"

        reasoning.append({"step": "市场环境", "detail": env_desc, "icon": "📊"})

        # 步骤2: 板块强度排序
        hot_sectors = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]
        hot_names = [s["name"] for s in hot_sectors]
        reasoning.append({"step": "最强板块", "detail": f"{', '.join(hot_names)}", "icon": "🔥"})

        # 步骤3: 逐只分析打分
        scored = []
        for s in candidates:
            agent_score = s.get("total_score", 50)
            reasons = []

            # 板块共振加分
            sector = s.get("sector", "")
            if any(h in sector for h in hot_names):
                agent_score += 10
                reasons.append(f"属于最强板块{sector}")

            # 资金承接
            vr = s.get("volume_ratio", 1)
            if vr >= 2.0:
                agent_score += 8
                reasons.append(f"量比{vr:.1f}强放量")
            elif vr >= 1.5:
                agent_score += 4

            # 涨跌幅
            pct = s.get("change_pct", 0)
            if 3 <= pct <= 8:
                agent_score += 6
                reasons.append(f"涨{pct:.1f}%强势")
            elif pct > 8:
                agent_score += 3
                reasons.append(f"涨{pct:.1f}%超强但追高")
            elif pct < -3:
                agent_score -= 5
                reasons.append(f"跌{pct:.1f}%弱势")

            # 连板高度
            lt = s.get("limit_times", 1)
            if lt >= 3:
                agent_score += 8
                reasons.append(f"{lt}连板龙头")
            elif lt >= 2:
                agent_score += 4

            # 换手率
            tr = s.get("turnover", 10)
            if 8 <= tr <= 25:
                agent_score += 3
                reasons.append(f"换手{tr:.0f}%健康")
            elif tr > 30:
                agent_score -= 3
                reasons.append(f"换手{tr:.0f}%过高")

            # 市值
            cap = s.get("cap", 100)
            if 50 <= cap <= 500:
                agent_score += 3
                reasons.append(f"市值{cap}亿适中")

            # 情绪共振
            if temp >= 70 and lt >= 2:
                agent_score += 5
                reasons.append("情绪+龙头共振")

            agent_score = max(0, min(100, agent_score))
            scored.append({**s, "agent_score": agent_score, "agent_reasons": reasons})

        # 步骤4: 排序精选1-3只
        scored.sort(key=lambda x: x["agent_score"], reverse=True)

        # 智能体决策: 根据市场环境决定推荐数量
        if env_score >= 3:
            pick_count = min(3, len(scored))
        elif env_score >= 2:
            pick_count = min(2, len(scored))
        else:
            pick_count = min(1, len(scored))

        picks = scored[:pick_count]

        # 步骤5: 生成分析报告
        if picks:
            lines = [f"📊 市场{env_desc}"]
            lines.append(f"\n🔍 从{len(candidates)}只候选中精选{len(picks)}只最强龙头:\n")
            for i, p in enumerate(picks, 1):
                lines.append(f"{i}. {p['name']}({p['code']}) 评分{p['agent_score']} {p['sector']}")
                lines.append(f"   现价¥{p['price']} 涨跌{p['change_pct']:+.2f}% 量比{p.get('volume_ratio',0):.1f}")
                if p.get('agent_reasons'):
                    lines.append(f"   理由: {', '.join(p['agent_reasons'][:3])}")
                lines.append("")

            if temp >= 70:
                lines.append("💡 情绪偏暖，可积极参与龙头接力，注意止盈纪律。")
            elif temp >= 50:
                lines.append("💡 情绪震荡，精选1-2只最强标的，严格止损。")
            else:
                lines.append("💡 情绪偏冷，极轻仓试错或观望。")

            confidence = min(90, 50 + env_score * 10 + len(picks) * 5)
        else:
            lines = ["暂未找到符合条件的龙头标的，建议观望。"]
            confidence = 30

        return {
            "picks": picks,
            "reasoning": reasoning,
            "answer": "\n".join(lines),
            "confidence": confidence,
        }

    def query(self, question: str, market: Dict, stocks: List[Dict]) -> Dict:
        """
        处理用户查询，返回选股结果+推理过程

        返回:
        {
            "answer": "回答文本",
            "picks": [...],  # 推荐股票
            "reasoning": [...],  # 推理步骤
            "confidence": 0-100,
        }
        """
        q = question.lower().strip()
        reasoning = []
        picks = []
        confidence = 70

        # 步骤1: 理解意图
        intent = self._parse_intent(q)
        reasoning.append({
            "step": "意图识别",
            "detail": f"用户需求: {intent['desc']}",
            "icon": "🎯",
        })

        # 步骤2: 市场环境判断
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})
        temp = sent.get("temperature", 50)
        stage = sent.get("stage", "震荡")

        reasoning.append({
            "step": "市场环境",
            "detail": f"情绪温度{temp}° ({stage})，涨停{stats.get('limit_up_count', '--')}家",
            "icon": "📊",
        })

        # 步骤3: 策略选股
        if intent["type"] == "swing":
            picks = self._pick_swing(stocks, intent, reasoning)
        elif intent["type"] == "ultra":
            picks = self._pick_ultra(stocks, intent, reasoning)
        elif intent["type"] == "sector":
            picks = self._pick_sector(stocks, market, intent, reasoning)
        elif intent["type"] == "screen":
            picks = self._screen_stocks(stocks, intent, reasoning)
        elif intent["type"] == "risk":
            picks = self._risk_analysis(stocks, market, intent, reasoning)
        else:
            picks = self._general_advice(stocks, market, intent, reasoning)

        # 步骤4: 风险评估
        risk_level = self._assess_risk(picks, market)
        reasoning.append({
            "step": "风险评估",
            "detail": f"推荐{len(picks)}只标的，整体风险: {risk_level}",
            "icon": "⚠️",
        })

        # 步骤5: 生成建议
        if temp < 30:
            advice = "市场冰点，建议空仓观望。"
            confidence = 30
        elif temp < 50:
            advice = "市场偏冷，轻仓试错，严格止损。"
            confidence = 50
        elif temp < 70:
            advice = "市场震荡，精选个股，控制仓位。"
            confidence = 65
        else:
            advice = "市场偏暖，可积极参与主线龙头。"
            confidence = 80

        reasoning.append({
            "step": "操作建议",
            "detail": advice,
            "icon": "💡",
        })

        # 生成回答
        answer = self._format_answer(intent, picks, advice, risk_level)

        result = {
            "answer": answer,
            "picks": picks[:10],
            "reasoning": reasoning,
            "confidence": confidence,
            "intent": intent,
            "timestamp": datetime.now().isoformat(),
        }

        self.history.append({
            "question": question,
            "answer": answer,
            "picks_count": len(picks),
            "timestamp": result["timestamp"],
        })

        return result

    def _parse_intent(self, q: str) -> Dict:
        """解析用户意图"""
        if any(w in q for w in ["波段", "中线", "趋势", "均线"]):
            return {"type": "swing", "desc": "波段/趋势策略选股", "keywords": ["波段"]}
        if any(w in q for w in ["超短", "打板", "龙头", "连板", "涨停"]):
            return {"type": "ultra", "desc": "超短/打板策略选股", "keywords": ["超短"]}
        if any(w in q for w in ["板块", "题材", "轮动", "热点"]):
            return {"type": "sector", "desc": "板块轮动分析", "keywords": ["板块"]}
        if any(w in q for w in ["筛选", "条件", "选出", "找", "搜索"]):
            return {"type": "screen", "desc": "条件筛选选股", "keywords": ["筛选"]}
        if any(w in q for w in ["风险", "止损", "回避", "危险"]):
            return {"type": "risk", "desc": "风险分析", "keywords": ["风险"]}

        # 提取关键词
        keywords = []
        for w in ["AI", "半导体", "新能源", "医药", "军工", "消费", "银行", "白酒"]:
            if w.lower() in q or w in q:
                keywords.append(w)

        if keywords:
            return {"type": "screen", "desc": f"按关键词筛选: {', '.join(keywords)}", "keywords": keywords}

        return {"type": "general", "desc": "综合分析建议", "keywords": []}

    def _pick_swing(self, stocks: List[Dict], intent: Dict, reasoning: List) -> List[Dict]:
        """波段选股"""
        reasoning.append({
            "step": "波段筛选",
            "detail": "条件: 均线多头 + RSI 35-70 + 放量确认",
            "icon": "📈",
        })

        # 使用关键词过滤
        keywords = intent.get("keywords", [])
        pool = stocks
        if keywords:
            pool = [s for s in stocks if any(k in s.get("sector", "") for k in keywords)] or stocks

        scored = []
        for s in pool:
            score = 0
            reasons = []

            rsi = s.get("rsi", 50)
            if 35 <= rsi <= 70:
                score += 20
                reasons.append(f"RSI健康({rsi:.0f})")

            vr = s.get("volume_ratio", 1)
            if vr > 1.3:
                score += 15
                reasons.append(f"放量({vr:.1f}倍)")

            pct = s.get("change_pct", 0)
            if 0 < pct < 5:
                score += 10
                reasons.append("温和上涨")

            ma5 = s.get("ma5", 0)
            ma10 = s.get("ma10", 0)
            ma20 = s.get("ma20", 0)
            if ma5 and ma10 and ma20 and ma5 > ma10 > ma20:
                score += 20
                reasons.append("均线多头")

            if score >= 30:
                s_copy = dict(s)
                s_copy["agent_score"] = score
                s_copy["agent_reasons"] = reasons
                scored.append(s_copy)

        scored.sort(key=lambda x: x["agent_score"], reverse=True)

        reasoning.append({
            "step": "波段结果",
            "detail": f"筛选出{len(scored)}只符合条件的标的",
            "icon": "✅",
        })

        return scored

    def _pick_ultra(self, stocks: List[Dict], intent: Dict, reasoning: List) -> List[Dict]:
        """超短选股"""
        reasoning.append({
            "step": "超短筛选",
            "detail": "条件: 连板+高换手+量比放大",
            "icon": "⚡",
        })

        scored = []
        for s in stocks:
            score = 0
            reasons = []

            lt = s.get("limit_times", 1)
            if lt >= 3:
                score += 25
                reasons.append(f"{lt}连板")
            elif lt >= 2:
                score += 15
                reasons.append(f"{lt}连板")

            pct = s.get("change_pct", 0)
            if pct >= 7:
                score += 15
                reasons.append("强势涨停")

            tr = s.get("turnover", 0)
            if 8 <= tr <= 25:
                score += 10
                reasons.append("换手健康")

            vr = s.get("volume_ratio", 1)
            if vr >= 2:
                score += 10
                reasons.append(f"量比{vr:.1f}")

            if score >= 20:
                s_copy = dict(s)
                s_copy["agent_score"] = score
                s_copy["agent_reasons"] = reasons
                scored.append(s_copy)

        scored.sort(key=lambda x: x["agent_score"], reverse=True)

        reasoning.append({
            "step": "超短结果",
            "detail": f"筛选出{len(scored)}只龙头标的",
            "icon": "✅",
        })

        return scored

    def _pick_sector(self, stocks: List[Dict], market: Dict, intent: Dict, reasoning: List) -> List[Dict]:
        """板块选股"""
        sectors = market.get("sectors", [])
        hot = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]
        hot_names = [s["name"] for s in hot]

        reasoning.append({
            "step": "热门板块",
            "detail": f"资金流入前三: {', '.join(hot_names)}",
            "icon": "🔥",
        })

        # 按板块匹配
        matched = []
        for s in stocks:
            sector = s.get("sector", "")
            if any(h in sector for h in hot_names):
                s_copy = dict(s)
                s_copy["agent_score"] = 80
                s_copy["agent_reasons"] = [f"属于热门板块: {sector}"]
                matched.append(s_copy)

        if not matched:
            # 退化到通用推荐
            matched = [dict(s) for s in stocks[:5]]
            for s in matched:
                s["agent_score"] = 50
                s["agent_reasons"] = ["非热门板块，仅供参考"]

        reasoning.append({
            "step": "板块结果",
            "detail": f"匹配到{len(matched)}只热门板块标的",
            "icon": "✅",
        })

        return matched

    def _screen_stocks(self, stocks: List[Dict], intent: Dict, reasoning: List) -> List[Dict]:
        """条件筛选"""
        keywords = intent.get("keywords", [])

        reasoning.append({
            "step": "条件筛选",
            "detail": f"关键词: {', '.join(keywords) if keywords else '无'}",
            "icon": "🔍",
        })

        matched = []
        for s in stocks:
            score = 0
            reasons = []

            # 关键词匹配
            if keywords:
                sector = s.get("sector", "")
                name = s.get("name", "")
                if any(k in sector or k in name for k in keywords):
                    score += 30
                    reasons.append(f"匹配关键词")

            # 综合评分
            pct = s.get("change_pct", 0)
            if pct > 0:
                score += min(pct * 3, 20)
                reasons.append(f"涨{pct:.1f}%")

            vr = s.get("volume_ratio", 1)
            if vr > 1.5:
                score += 10
                reasons.append("放量")

            if score > 0:
                s_copy = dict(s)
                s_copy["agent_score"] = score
                s_copy["agent_reasons"] = reasons
                matched.append(s_copy)

        matched.sort(key=lambda x: x["agent_score"], reverse=True)

        reasoning.append({
            "step": "筛选结果",
            "detail": f"共{len(matched)}只标的",
            "icon": "✅",
        })

        return matched

    def _risk_analysis(self, stocks: List[Dict], market: Dict, intent: Dict, reasoning: List) -> List[Dict]:
        """风险分析"""
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})

        reasoning.append({
            "step": "风险扫描",
            "detail": f"跌停{stats.get('limit_down_count', '--')}家，情绪{sent.get('stage', '未知')}",
            "icon": "🚨",
        })

        # 找出高风险标的
        risky = []
        for s in stocks:
            risk_factors = []
            risk_score = 0

            rsi = s.get("rsi", 50)
            if rsi > 80:
                risk_factors.append(f"RSI超买({rsi:.0f})")
                risk_score += 20

            pct = s.get("change_pct", 0)
            if pct > 8:
                risk_factors.append("涨幅过大")
                risk_score += 15

            tr = s.get("turnover", 0)
            if tr > 30:
                risk_factors.append("换手过高")
                risk_score += 10

            if risk_factors:
                s_copy = dict(s)
                s_copy["agent_score"] = risk_score
                s_copy["agent_reasons"] = risk_factors
                risky.append(s_copy)

        reasoning.append({
            "step": "风险结果",
            "detail": f"发现{len(risky)}只高风险标的",
            "icon": "⚠️",
        })

        return risky

    def _general_advice(self, stocks: List[Dict], market: Dict, intent: Dict, reasoning: List) -> List[Dict]:
        """综合建议"""
        sent = market.get("sentiment", {})
        temp = sent.get("temperature", 50)

        reasoning.append({
            "step": "综合分析",
            "detail": f"情绪{temp}°，综合推荐评分最高的标的",
            "icon": "📋",
        })

        # 返回评分最高的
        sorted_stocks = sorted(stocks, key=lambda x: x.get("score", x.get("change_pct", 0)), reverse=True)
        result = []
        for s in sorted_stocks[:5]:
            s_copy = dict(s)
            s_copy["agent_score"] = s.get("score", 60)
            s_copy["agent_reasons"] = ["综合评分较高"]
            result.append(s_copy)

        return result

    def _assess_risk(self, picks: List[Dict], market: Dict) -> str:
        """评估推荐整体风险"""
        if not picks:
            return "无推荐"

        avg_change = sum(p.get("change_pct", 0) for p in picks) / len(picks)
        if avg_change > 7:
            return "高"
        elif avg_change > 3:
            return "中"
        else:
            return "低"

    def _format_answer(self, intent: Dict, picks: List[Dict], advice: str, risk: str) -> str:
        """格式化回答"""
        lines = [f"📊 {intent['desc']}"]

        if picks:
            lines.append(f"\n找到 {len(picks)} 只标的:\n")
            for i, p in enumerate(picks[:5], 1):
                score = p.get("agent_score", 0)
                reasons = ", ".join(p.get("agent_reasons", [])[:2])
                lines.append(f"{i}. {p['name']}({p['code']}) "
                             f"价格:{p.get('price','--')} "
                             f"涨跌:{p.get('change_pct',0):.1f}% "
                             f"评分:{score}")
                if reasons:
                    lines.append(f"   理由: {reasons}")
        else:
            lines.append("\n暂未找到符合条件的标的。")

        lines.append(f"\n💡 {advice}")
        lines.append(f"⚠️ 整体风险等级: {risk}")

        return "\n".join(lines)

    def get_history(self) -> List[Dict]:
        """获取查询历史"""
        return self.history[-20:]


# 全局实例
agent = AIAgent()
