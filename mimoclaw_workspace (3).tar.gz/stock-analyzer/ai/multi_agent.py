#!/usr/bin/env python3
"""
多智能体协同投票系统 v2
架构: 多AI接入 → 独立分析 → 投票聚合 → 精选输出

支持:
- DeepSeek
- 讯飞星辰
- 本地规则引擎（备用）
- 可扩展更多AI
"""
import json
import os
import time
from typing import Dict, List, Optional
from datetime import datetime


# ─── 智能体注册表 ───

AGENT_REGISTRY = {}


def register_agent(name: str, provider: str, analyze_fn, chat_fn=None):
    """注册一个AI智能体"""
    AGENT_REGISTRY[name] = {
        "name": name,
        "provider": provider,
        "analyze": analyze_fn,
        "chat": chat_fn,
        "enabled": True,
    }


def _auto_register():
    """自动注册所有可用AI智能体"""
    # DeepSeek
    try:
        from ai.deepseek import _call_deepseek, get_api_key as ds_key
        def ds_analyze(system, user):
            if not ds_key():
                print("[Agent] DeepSeek: Key未配置，跳过")
                return {"answer": "[DeepSeek未配置]", "confidence": 0}
            print(f"[Agent] DeepSeek: 调用API...")
            answer = _call_deepseek(system, user, temperature=0.6)
            print(f"[Agent] DeepSeek: 完成，回复{len(answer)}字")
            return {"answer": answer, "confidence": 75}
        register_agent("DeepSeek", "deepseek", ds_analyze)
        print("[Agent] DeepSeek: 已注册")
    except Exception as e:
        print(f"[Agent] DeepSeek注册失败: {e}")

    # 讯飞星辰
    try:
        from ai.xunfei import _call_xunfei, get_api_key as xf_key
        def xf_analyze(system, user):
            if not xf_key():
                print("[Agent] 讯飞: Key未配置，跳过")
                return {"answer": "[讯飞未配置]", "confidence": 0}
            print(f"[Agent] 讯飞: 调用API...")
            answer = _call_xunfei(system, user, temperature=0.6)
            print(f"[Agent] 讯飞: 完成，回复{len(answer)}字")
            return {"answer": answer, "confidence": 70}
        register_agent("讯飞星辰", "xunfei", xf_analyze)
        print("[Agent] 讯飞: 已注册")
    except Exception as e:
        print(f"[Agent] 讯飞注册失败: {e}")


_auto_register()


def get_available_agents() -> List[Dict]:
    """获取所有可用智能体"""
    agents = []
    for name, info in AGENT_REGISTRY.items():
        if info["enabled"]:
            agents.append({"name": name, "provider": info["provider"]})
    return agents


# ─── 智能体角色 ───

ROLES = {
    "technical": {
        "name": "技术分析师",
        "emoji": "📊",
        "system": """你是A股技术分析师，专注技术形态和指标。
从以下角度分析候选股票：
- 均线系统：MA5>MA10>MA20多头排列
- 量价关系：量价齐升、放量突破
- 指标：RSI(35-70健康)、MACD金叉
- 支撑压力位
只推荐技术面最强的1-2只，给名称+代码+一句话理由。""",
    },
    "sentiment": {
        "name": "情绪分析师",
        "emoji": "🧠",
        "system": """你是A股情绪分析师，专注市场情绪和资金动向。
从以下角度分析候选股票：
- 涨停家数、封板率、连板高度
- 北向资金流向
- 板块资金净流入
- 龙头辨识度和人气
只推荐情绪面最强的1-2只，给名称+代码+一句话理由。""",
    },
    "sector": {
        "name": "板块轮动分析师",
        "emoji": "🔥",
        "system": """你是A股板块轮动分析师，专注板块轮动和产业逻辑。
从以下角度分析候选股票：
- 当日最强板块（资金流入前3）
- 板块生命周期（启动→发酵→高潮→退潮）
- 板块内龙头vs跟风
- 产业链联动和政策催化
只推荐板块面最强的1-2只，给名称+代码+一句话理由。""",
    },
    "risk": {
        "name": "风控分析师",
        "emoji": "🛡️",
        "system": """你是A股风控分析师，专注风险评估。
从以下角度分析候选股票：
- 盈亏比（止损空间vs盈利空间）
- 流动性（成交额、换手率）
- 波动率和追高风险
- 市值适中（50-500亿最佳）
只推荐风险收益比最优的1-2只，给名称+代码+一句话理由。""",
    },
}


# ─── 投票系统 ───

class VoteAggregator:
    """投票聚合器"""

    def __init__(self):
        self.votes = {}       # code -> {count, agents, reasons, stock}
        self.agent_results = []  # 每个智能体的分析结果

    def add_vote(self, agent_name: str, code: str, stock: dict, reason: str = ""):
        """添加一票"""
        if code not in self.votes:
            self.votes[code] = {
                "count": 0,
                "agents": [],
                "reasons": [],
                "stock": stock,
            }
        self.votes[code]["count"] += 1
        self.votes[code]["agents"].append(agent_name)
        if reason:
            self.votes[code]["reasons"].append(f"{agent_name}: {reason}")

    def add_agent_result(self, agent_name: str, role: str, result: str, picks: List[str]):
        """记录智能体分析结果"""
        self.agent_results.append({
            "agent": agent_name,
            "role": role,
            "result": result,
            "picks": picks,
        })

    def get_ranking(self) -> List[Dict]:
        """按票数排序"""
        ranking = []
        for code, info in sorted(self.votes.items(), key=lambda x: x[1]["count"], reverse=True):
            s = info["stock"]
            ranking.append({
                "code": code,
                "name": s.get("name", ""),
                "sector": s.get("sector", ""),
                "price": s.get("price", 0),
                "change_pct": s.get("change_pct", 0),
                "votes": info["count"],
                "agents": info["agents"],
                "reasons": info["reasons"],
            })
        return ranking

    def get_winners(self, hot_sectors: List[str] = None, max_picks: int = 3) -> List[Dict]:
        """从最强板块中选出获胜者"""
        ranking = self.get_ranking()
        winners = []

        # 优先选热门板块的
        if hot_sectors:
            for r in ranking:
                if any(h in r.get("sector", "") for h in hot_sectors):
                    r["in_hot_sector"] = True
                    winners.append(r)
                if len(winners) >= max_picks:
                    break

        # 不足则从剩余补充
        if len(winners) < max_picks:
            for r in ranking:
                if r["code"] not in [w["code"] for w in winners]:
                    r["in_hot_sector"] = False
                    winners.append(r)
                if len(winners) >= max_picks:
                    break

        return winners


# ─── 协同引擎 ───

def parse_picks_from_text(text: str, candidates: List[Dict]) -> List[str]:
    """从AI回复中解析推荐的股票代码"""
    picks = []
    for s in candidates:
        if s["code"] in text or s["name"] in text:
            if s["code"] not in picks:
                picks.append(s["code"])
    return picks


def run_multi_agent_vote(
    candidates: List[Dict],
    market: Dict,
    agents_config: List[Dict] = None,
) -> Dict:
    """
    多智能体协同投票主入口

    参数:
        candidates: 候选股票池
        market: 市场数据
        agents_config: 智能体配置 [{"name": "deepseek", "roles": ["technical","sentiment"]}]

    返回:
        {
            "winners": [...],           # 最终精选1-3只
            "ranking": [...],           # 全部投票排名
            "agent_results": [...],     # 每个智能体的分析
            "vote_summary": {...},      # 投票统计
        }
    """
    # 构造市场摘要
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})
    sectors = market.get("sectors", [])
    hot_sectors = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]
    hot_names = [s["name"] for s in hot_sectors]

    market_info = f"""市场环境：
情绪{sent.get('temperature','--')}° {sent.get('stage','未知')}
涨停{stats.get('limit_up_count','--')}家 跌停{stats.get('limit_down_count','--')}家
封板率{stats.get('seal_rate','--')}% 北向{stats.get('north_flow','--')}亿
最强板块：{', '.join(hot_names)}"""

    # 构造候选列表
    stock_lines = []
    for i, s in enumerate(candidates, 1):
        line = f"{i}. {s['name']}({s['code']}) {s.get('sector','')}"
        line += f" ¥{s.get('price',0):.2f} {s.get('change_pct',0):+.2f}%"
        line += f" 量比{s.get('volume_ratio',0):.1f} 换手{s.get('turnover',0):.1f}%"
        line += f" 连板{s.get('limit_times',1)} 评分{s.get('total_score',0)}"
        stock_lines.append(line)

    candidate_text = f"候选池（{len(candidates)}只）：\n" + "\n".join(stock_lines)

    # 默认配置：每个AI分析所有4个角色
    if not agents_config:
        agents_config = []
        for name in AGENT_REGISTRY:
            agents_config.append({
                "name": name,
                "roles": list(ROLES.keys()),
            })

    # 初始化投票器
    aggregator = VoteAggregator()

    # 执行分析（每个AI一次调用，4个角色合并）
    all_roles = list(ROLES.keys())
    combined_system = """你是一个专业A股分析师团队，同时具备以下4个角色的分析能力：
1. 📊 技术分析师：均线、量价、RSI、MACD
2. 🧠 情绪分析师：涨停效应、北向资金、封板率
3. 🔥 板块轮动分析师：板块强度、轮动节奏、产业链
4. 🛡️ 风控分析师：盈亏比、流动性、波动率

请分别从4个角度各推荐1只最强标的，格式：
📊技术推荐：股票名(代码) - 理由
🧠情绪推荐：股票名(代码) - 理由
🔥板块推荐：股票名(代码) - 理由
🛡️风控推荐：股票名(代码) - 理由"""

    for agent_cfg in agents_config:
        agent_name = agent_cfg["name"]
        agent_info = AGENT_REGISTRY.get(agent_name)
        if not agent_info or not agent_info["enabled"]:
            continue

        analyze_fn = agent_info["analyze"]
        user_msg = f"{market_info}\n\n{candidate_text}"

        try:
            result = analyze_fn(combined_system, user_msg)
            answer = result.get("answer", "")

            # 解析每个角色的推荐
            for role_key in all_roles:
                role = ROLES.get(role_key)
                if not role:
                    continue

                # 从回复中提取该角色的部分
                role_label = {"technical": "技术", "sentiment": "情绪", "sector": "板块", "risk": "风控"}[role_key]
                role_text = ""
                for line in answer.split("\n"):
                    if role_label in line and "推荐" in line:
                        role_text = line
                        break
                    elif role_label in line:
                        role_text = line

                picks = parse_picks_from_text(role_text or answer, candidates)

                aggregator.add_agent_result(
                    agent_name=f"{role['emoji']} {role['name']}({agent_name})",
                    role=role_key,
                    result=role_text or "见综合分析",
                    picks=picks,
                )

                for code in picks:
                    stock = next((s for s in candidates if s["code"] == code), None)
                    if stock:
                        aggregator.add_vote(
                            agent_name=f"{role['emoji']} {agent_name}",
                            code=code,
                            stock=stock,
                        )

        except Exception as e:
            for role_key in all_roles:
                role = ROLES.get(role_key)
                if role:
                    aggregator.add_agent_result(
                        agent_name=f"{role['emoji']} {role['name']}({agent_name})",
                        role=role_key,
                        result=f"分析失败: {e}",
                        picks=[],
                    )

    # 聚合结果
    ranking = aggregator.get_ranking()
    winners = aggregator.get_winners(hot_names, max_picks=3)

    # 操作建议
    temp = sent.get("temperature", 50)
    if temp >= 70:
        advice = "🟢 情绪偏暖，多智能体一致推荐，可积极参与"
    elif temp >= 50:
        advice = "🟡 情绪震荡，精选票数最高的1-2只，严格止损"
    else:
        advice = "🔴 情绪偏冷，建议观望或极轻仓"

    return {
        "winners": winners,
        "ranking": ranking,
        "agent_results": aggregator.agent_results,
        "hot_sectors": hot_names,
        "advice": advice,
        "agents_count": len(agents_config),
        "roles_count": len(ROLES),
        "total_votes": sum(v["count"] for v in aggregator.votes.values()),
        "timestamp": datetime.now().isoformat(),
    }
