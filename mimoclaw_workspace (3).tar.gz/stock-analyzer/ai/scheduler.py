#!/usr/bin/env python3
"""
定时任务调度器
每天4个时段自动运行多智能体协同分析:
  09:30 早盘开盘
  11:30 午盘收盘
  13:00 午后开盘
  15:00 收盘

自动分类: 波段推荐 / 超短推荐
"""
import json
import os
import time
import threading
from datetime import datetime
from typing import Dict, List


SCHEDULE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "cache", "scheduler_state.json")
RESULT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "cache", "strategy_results.json")

# 4个交易时段
SCHEDULES = [
    {"time": "09:30", "name": "早盘开盘", "emoji": "🌅", "desc": "开盘扫描，捕捉早盘龙头"},
    {"time": "11:30", "name": "午盘收盘", "emoji": "☀️", "desc": "午盘复盘，调整持仓"},
    {"time": "13:00", "name": "午后开盘", "emoji": "🌤️", "desc": "午后扫描，寻找接力机会"},
    {"time": "15:00", "name": "尾盘收盘", "emoji": "🌙", "desc": "收盘总结，布局明日"},
]


def _load_state() -> dict:
    if os.path.exists(SCHEDULE_FILE):
        try:
            with open(SCHEDULE_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {"last_run": {}, "history": []}


def _save_state(state: dict):
    os.makedirs(os.path.dirname(SCHEDULE_FILE), exist_ok=True)
    with open(SCHEDULE_FILE, "w") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


def _save_results(results: dict):
    os.makedirs(os.path.dirname(RESULT_FILE), exist_ok=True)
    with open(RESULT_FILE, "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)


def load_results() -> dict:
    if os.path.exists(RESULT_FILE):
        try:
            with open(RESULT_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {}


def run_analysis(session_name: str = "手动触发") -> Dict:
    """
    执行一次完整的多智能体协同分析

    流程:
    1. 获取实时行情
    2. 多智能体协同投票
    3. 分类: 波段 / 超短
    4. 保存结果
    """
    from data.provider import provider
    from data.stock_pool import fetch_real_prices, STOCKS
    from strategies.ultra_v2 import pick_ultra_v2
    from ai.multi_agent import run_multi_agent_vote

    print(f"[调度器] 开始执行: {session_name}")

    # 1. 刷新实时价格
    fetch_real_prices([s["code"] for s in STOCKS])

    # 2. 获取市场数据
    market = provider.get_market_overview()

    # 3. 多因子选股（候选池）
    candidates = pick_ultra_v2(market).get("stocks", [])

    # 4. 多智能体协同投票
    from ai.deepseek import get_api_key as ds_key
    from ai.xunfei import get_api_key as xf_key

    agents_config = []
    if ds_key():
        agents_config.append({"name": "DeepSeek", "roles": ["technical", "sentiment", "sector", "risk"]})
    if xf_key():
        agents_config.append({"name": "讯飞星辰", "roles": ["technical", "sentiment", "sector", "risk"]})

    if not agents_config:
        return {"error": "无可用AI智能体，请配置API Key", "session": session_name}

    vote_result = run_multi_agent_vote(candidates, market, agents_config)

    # 5. 分类: 波段 vs 超短
    winners = vote_result.get("winners", [])
    swing_picks = []  # 波段: 趋势稳定、量价健康
    ultra_picks = []  # 超短: 连板、高换手、爆发力

    for stock in winners:
        lt = stock.get("limit_times", 1)
        pct = stock.get("change_pct", 0)
        tr = stock.get("turnover", 10)
        vr = stock.get("volume_ratio", 1)

        # 判断逻辑
        is_ultra = (
            lt >= 2                    # 连板
            or pct >= 7                # 大涨
            or (pct >= 3 and vr >= 2)  # 放量强势
        )

        if is_ultra:
            ultra_picks.append(stock)
        else:
            swing_picks.append(stock)

    # 如果某类不足，从排名中补充
    ranking = vote_result.get("ranking", [])
    for r in ranking:
        if len(swing_picks) >= 3 and len(ultra_picks) >= 3:
            break
        code = r.get("code", "")
        if code in [s.get("code") for s in swing_picks + ultra_picks]:
            continue
        # 根据特征分配
        if r.get("votes", 0) >= 2:
            if len(ultra_picks) < 3:
                ultra_picks.append(r)
            elif len(swing_picks) < 3:
                swing_picks.append(r)

    # 6. 保存结果
    now = datetime.now()
    results = {
        "session": session_name,
        "timestamp": now.isoformat(),
        "market": {
            "temperature": market.get("sentiment", {}).get("temperature", 0),
            "stage": market.get("sentiment", {}).get("stage", ""),
            "limit_up": market.get("stats", {}).get("limit_up_count", 0),
            "limit_down": market.get("stats", {}).get("limit_down_count", 0),
        },
        "swing": {
            "title": "📈 波段策略推荐",
            "stocks": swing_picks[:3],
            "count": len(swing_picks[:3]),
            "advice": vote_result.get("advice", ""),
        },
        "ultra": {
            "title": "⚡ 超短策略推荐",
            "stocks": ultra_picks[:3],
            "count": len(ultra_picks[:3]),
            "advice": vote_result.get("advice", ""),
        },
        "agents": vote_result.get("agent_results", []),
        "hot_sectors": vote_result.get("hot_sectors", []),
        "total_votes": vote_result.get("total_votes", 0),
    }

    _save_results(results)

    # 更新调度状态
    state = _load_state()
    state["last_run"][session_name] = now.isoformat()
    state["history"].append({
        "session": session_name,
        "time": now.isoformat(),
        "swing_count": len(swing_picks[:3]),
        "ultra_count": len(ultra_picks[:3]),
    })
    # 只保留最近50条
    state["history"] = state["history"][-50:]
    _save_state(state)

    print(f"[调度器] 完成: 波段{len(swing_picks[:3])}只 超短{len(ultra_picks[:3])}只")
    return results


# ─── 后台调度线程 ───

_scheduler_thread = None
_running = False


def _get_current_time_str() -> str:
    """获取当前时间 HH:MM"""
    return datetime.now().strftime("%H:%M")


def _scheduler_loop():
    """调度主循环"""
    global _running
    _running = True
    print("[调度器] 启动，等待交易时段...")

    while _running:
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        weekday = now.weekday()  # 0=周一, 6=周日

        # 只在交易日运行（周一到周五）
        if weekday < 5:
            for sched in SCHEDULES:
                if current_time == sched["time"]:
                    state = _load_state()
                    last = state.get("last_run", {}).get(sched["name"], "")
                    today = now.strftime("%Y-%m-%d")
                    # 防止重复执行
                    if today in last:
                        continue
                    try:
                        run_analysis(sched["name"])
                    except Exception as e:
                        print(f"[调度器] {sched['name']} 执行失败: {e}")

        # 每30秒检查一次
        time.sleep(30)


def start_scheduler():
    """启动后台调度器"""
    global _scheduler_thread
    if _scheduler_thread and _scheduler_thread.is_alive():
        return {"ok": True, "message": "调度器已在运行"}
    _scheduler_thread = threading.Thread(target=_scheduler_loop, daemon=True)
    _scheduler_thread.start()
    return {"ok": True, "message": "调度器已启动"}


def stop_scheduler():
    """停止调度器"""
    global _running
    _running = False
    return {"ok": True, "message": "调度器已停止"}


def get_scheduler_status() -> Dict:
    """获取调度器状态"""
    state = _load_state()
    return {
        "running": _running,
        "schedules": SCHEDULES,
        "last_run": state.get("last_run", {}),
        "history_count": len(state.get("history", [])),
    }
