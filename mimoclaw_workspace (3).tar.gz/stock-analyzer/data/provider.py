#!/usr/bin/env python3
"""
数据层 - 统一数据源
所有价格来自 stock_pool.py，保证一致性
"""
import json
import os
import time
import math
from datetime import datetime
from typing import Dict, List

from data.stock_pool import (
    STOCKS, get_stock_full, get_stock_price, get_all_stocks,
    get_hot_stocks, is_st, _wave, _gauss,
)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")
os.makedirs(DATA_DIR, exist_ok=True)

# ─── 指数基准 ───
INDICES_BASE = {
    "上证指数": 3380.56, "深证成指": 10856.23, "创业板指": 2178.90,
    "科创50": 1012.45, "沪深300": 3956.78, "中证500": 6234.12,
}

# ─── 板块基准 ───
SECTOR_POOL = [
    {"name": "AI算力", "base_pct": 3.2, "base_flow": 28.5},
    {"name": "机器人", "base_pct": 2.8, "base_flow": 22.3},
    {"name": "半导体", "base_pct": 1.5, "base_flow": 15.8},
    {"name": "新能源", "base_pct": 1.2, "base_flow": 12.6},
    {"name": "光伏", "base_pct": 0.8, "base_flow": 8.4},
    {"name": "医药", "base_pct": -0.5, "base_flow": -3.2},
    {"name": "军工", "base_pct": 1.8, "base_flow": 10.5},
    {"name": "芯片", "base_pct": 2.1, "base_flow": 14.2},
    {"name": "数据要素", "base_pct": 3.5, "base_flow": 25.8},
    {"name": "低空经济", "base_pct": -1.2, "base_flow": -5.8},
]


def gen_indices() -> List[Dict]:
    result = []
    for name, base in INDICES_BASE.items():
        pct = round(_wave(f"idx_{name}", 2.5), 2)
        price = round(base * (1 + pct / 100), 2)
        result.append({"name": name, "price": price, "change_pct": pct})
    return result


def gen_stats() -> Dict:
    lu = max(10, int(_wave("stat_lu", 40) + 65))
    ld = max(1, int(_wave("stat_ld", 10) + 8))
    br = max(2, int(_wave("stat_br", 8) + 12))
    seal = round((lu - br) / max(lu, 1) * 100, 1)
    north = round(_wave("stat_north", 80) + 25, 1)
    amount = round(_wave("stat_amount", 3000) + 11000, 0)
    return {
        "limit_up_count": lu, "limit_down_count": ld, "broken_count": br,
        "seal_rate": seal, "north_flow": north, "total_amount": amount,
    }


def gen_sectors() -> List[Dict]:
    result = []
    for s in SECTOR_POOL:
        pct = round(_gauss(f"sec_{s['name']}_pct", s["base_pct"], 2.5), 2)
        flow = round(_gauss(f"sec_{s['name']}_flow", s["base_flow"] + pct * 3, 5), 2)
        result.append({
            "name": s["name"], "change_pct": pct,
            "main_net": round(flow * 1e8, 0),
            "turnover": round(abs(_wave(f"sec_{s['name']}_tr", 4)), 2),
        })
    result.sort(key=lambda x: x["main_net"], reverse=True)
    return result


def gen_sentiment(stats: Dict) -> Dict:
    lu = stats["limit_up_count"]
    ld = stats["limit_down_count"]
    seal = stats["seal_rate"]
    temp = 50
    if lu > 80: temp += 20
    elif lu > 50: temp += 10
    elif lu < 20: temp -= 20
    if ld > 30: temp -= 15
    elif ld < 10: temp += 5
    if seal > 80: temp += 10
    elif seal < 60: temp -= 10
    temp = max(0, min(100, temp + int(_wave("sent_drift", 5))))
    if temp >= 80: stage, icon = "高潮", "🔥"
    elif temp >= 65: stage, icon = "偏暖", "☀️"
    elif temp >= 45: stage, icon = "震荡", "⚖️"
    elif temp >= 30: stage, icon = "偏冷", "🌧️"
    else: stage, icon = "冰点", "❄️"
    return {"temperature": temp, "stage": stage, "icon": icon}


def gen_stocks(count: int = 6, strategy: str = "swing") -> List[Dict]:
    """选股（价格统一来自 stock_pool）"""
    import random
    random.seed(int(time.time() / 120))  # 每2分钟重选
    pool = [s for s in STOCKS if not is_st(s["name"])]
    selected = random.sample(pool, min(count, len(pool)))
    random.seed()

    result = []
    for stock in selected:
        full = get_stock_full(stock["code"])
        if not full:
            continue

        if strategy == "swing":
            score = max(30, min(100, int(_wave(f"score_{stock['code']}", 20) + 70)))
            full["score"] = score
            full["strategy"] = "swing"
            full["buy_zone"] = [round(full["price"] * 0.97, 2), round(full["price"] * 1.01, 2)]
            full["stop_loss"] = round(full["price"] * 0.95, 2)
            full["target"] = round(full["price"] * 1.10, 2)
        elif strategy == "ultra":
            full["strategy"] = "ultra"
            full["score"] = max(40, min(100, int(_wave(f"uscore_{stock['code']}", 20) + 75)))
            full["board_type"] = ["首板", "二板", "三板", "龙头"][min(full.get("limit_times", 1) - 1, 3)]
        else:
            full["strategy"] = "sector"

        result.append(full)

    result.sort(key=lambda x: x.get("score", x["change_pct"]), reverse=True)
    return result


def gen_kline(code: str, base_price: float, days: int = 60) -> List[Dict]:
    changes = []
    for i in range(days):
        h = hash(f"kl_{code}_{i}_{int(time.time()/30)//60}") & 0xFFFFFFFF
        r = h / 0xFFFFFFFF
        changes.append((r - 0.45) * 6)
    factor = 1.0
    for pct in changes:
        factor *= (1 + pct / 100)
    start_price = base_price / factor
    result = []
    price = start_price
    for i in range(days):
        from datetime import timedelta
        date = (datetime.now() - timedelta(days=days - i)).strftime("%Y-%m-%d")
        pct = changes[i]
        h = hash(f"kl_{code}_{i}_{int(time.time()/30)//60}") & 0xFFFFFFFF
        r = h / 0xFFFFFFFF
        o = round(price * (1 + (r - 0.5) * 0.04), 2)
        c = round(price * (1 + pct / 100), 2)
        h2 = round(max(o, c) * (1 + r * 0.02), 2)
        l = round(min(o, c) * (1 - r * 0.02), 2)
        v = int(5000 + r * 40000)
        result.append({"date": date, "open": o, "high": h2, "low": l, "close": c, "volume": v, "amount": round(v * c * 100, 0)})
        price = c
    if result:
        result[-1]["close"] = base_price
        result[-1]["high"] = max(result[-1]["high"], base_price)
        result[-1]["low"] = min(result[-1]["low"], base_price)
    return result


class DataProvider:
    def get_market_overview(self) -> Dict:
        stats = gen_stats()
        return {
            "indices": gen_indices(), "stats": stats,
            "sectors": gen_sectors(), "sentiment": gen_sentiment(stats),
            "timestamp": datetime.now().isoformat(),
        }

    def get_strategy_stocks(self, strategy: str = "swing", count: int = 6) -> List[Dict]:
        return gen_stocks(count, strategy)

    def get_kline(self, code: str, base_price: float = None, days: int = 60) -> List[Dict]:
        if base_price is None:
            base_price = get_stock_price(code) or 50.0
        return gen_kline(code, base_price, days)

    def get_all_data(self) -> Dict:
        from strategies.engine import engine
        market = self.get_market_overview()
        swing = self.get_strategy_stocks("swing", 6)
        ultra = self.get_strategy_stocks("ultra", 6)
        for s in swing:
            kline = self.get_kline(s["code"], s["price"])
            s["analysis"] = engine.analyze_swing(kline, s["price"])
        for s in ultra:
            s["analysis"] = engine.analyze_ultra(market, s)
        return {"market": market, "swing": swing, "ultra": ultra, "sectors": self.get_strategy_stocks("sector", 6), "timestamp": datetime.now().isoformat()}


provider = DataProvider()
