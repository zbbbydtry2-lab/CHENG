#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
StockPulse Pro - AI 智能分析系统
纯标准库 HTTP 服务
新增: 自定义策略 + AI智能体
"""
import json
import os
import sys
import urllib.request
import urllib.error
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import parse_qs, urlparse
from datetime import datetime


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """多线程HTTP服务器，支持并发请求"""
    daemon_threads = True

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data.provider import provider
from strategies.engine import engine
from strategies.custom import run_custom_strategy, get_templates, get_indicators
from strategies.ultra_pick import pick_ultra_leaders
from strategies.ultra_v2 import pick_ultra_v2
from strategies.swing_screener import screen_swing_stocks
from strategies.backtest import run_backtest, optimize_params
from strategies.backtest_v2 import run_backtest_v2, find_best_strategy
from ai.analyzer import analyzer
from ai.agent import agent
from ai.deepseek import (
    analyze_leaders, analyze_swing, analyze_ultra, chat as ds_chat,
    get_status as ds_status, set_api_key as ds_set_key, test_connection as ds_test,
    get_api_key as ds_get_key,
)
from ai.multi_agent import run_multi_agent_vote, register_agent, get_available_agents
from ai.scheduler import run_analysis, start_scheduler, stop_scheduler, get_scheduler_status, load_results

# ─── 后台任务 ───
import threading
_bg_tasks = {}  # task_id -> {status, result, error}
from ai.xunfei import (
    get_status as xf_status, set_api_key as xf_set_key,
    test_connection as xf_test, get_api_key as xf_get_key,
    analyze_leaders as xf_analyze_leaders, chat as xf_chat,
)


def _fetch_realtime_indices():
    """实时指数行情（腾讯主 + 新浪备）"""
    import re
    result = {}

    # ── 腾讯行情（优先，更稳定） ──
    try:
        url = "https://qt.gtimg.cn/q=sh000001,sz399001,sz399006,sh000688"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            raw = resp.read().decode("gbk", errors="ignore")

        for line in raw.strip().split(";"):
            line = line.strip()
            m = re.match(r'v_(s[hz]\d+)="(.+)"', line)
            if not m:
                continue
            code = m.group(1)
            parts = m.group(2).split("~")
            if len(parts) < 40:
                continue
            price = float(parts[3])
            prev_close = float(parts[4])
            open_p = float(parts[5])
            volume = int(parts[6]) if parts[6] else 0
            high = float(parts[33]) if parts[33] else price
            low = float(parts[34]) if parts[34] else price
            amount_str = parts[37] if len(parts) > 37 else "0"
            amount = float(amount_str) * 10000 if amount_str else 0  # 万->元

            result[code] = {
                "name": parts[1],
                "open": open_p,
                "prev_close": prev_close,
                "price": price,
                "high": high,
                "low": low,
                "volume": volume,
                "amount": amount,
                "time": parts[30] if len(parts) > 30 else "",
            }
        if result:
            return result
    except Exception as e:
        print(f"[Tencent Error] {e}")

    # ── 新浪行情（备用） ──
    try:
        url = "https://hq.sinajs.cn/list=sh000001,sz399001,sz399006,sh000688"
        req = urllib.request.Request(url, headers={
            "Referer": "https://finance.sina.com.cn",
            "User-Agent": "Mozilla/5.0",
        })
        with urllib.request.urlopen(req, timeout=3) as resp:
            raw = resp.read().decode("gbk", errors="ignore")

        for line in raw.strip().split("\n"):
            m = re.match(r'hq_str_(s[hz]\d+)="(.+)"', line.strip())
            if not m:
                continue
            code = m.group(1)
            parts = m.group(2).split(",")
            if len(parts) < 32:
                continue
            result[code] = {
                "name": parts[0],
                "open": float(parts[1]),
                "prev_close": float(parts[2]),
                "price": float(parts[3]),
                "high": float(parts[4]),
                "low": float(parts[5]),
                "volume": int(parts[8]),
                "amount": float(parts[9]),
                "time": parts[31],
            }
    except Exception as e:
        print(f"[Sina Error] {e}")

    return result


def _build_market_data():
    """构建前端兼容的 market_data 格式"""
    m = provider.get_market_overview()
    swing = provider.get_strategy_stocks("swing", 6)
    ultra = provider.get_strategy_stocks("ultra", 6)

    # AI 分析选股
    for s in swing:
        kline = provider.get_kline(s["code"], s.get("base_price"))
        s["analysis"] = engine.analyze_swing(kline, s["price"])

    stats = m.get("stats", {})
    indices = m.get("indices", [])
    sectors = m.get("sectors", [])
    sent = m.get("sentiment", {})

    # 填充 limit_up_stocks（前端需要）
    limit_up_stocks = []
    for s in ultra:
        limit_up_stocks.append({
            "name": s["name"], "code": s["code"], "price": s["price"],
            "change_pct": s["change_pct"], "turnover": s["turnover"],
            "amount": s["amount"], "reason": s.get("sector", ""),
            "limit_times": s.get("limit_times", 1),
        })

    return {
        "market": {
            "indices": indices,
            "limit_up_count": stats.get("limit_up_count", 0),
            "limit_down_count": stats.get("limit_down_count", 0),
            "broken_count": stats.get("broken_count", 0),
            "north_flow": stats.get("north_flow", 0),
            "total_amount": stats.get("total_amount", 0),
        },
        "sectors": sectors,
        "limit_up_stocks": limit_up_stocks,
        "recommendations": limit_up_stocks,
        "sentiment": sent,
    }


def _build_swing_scan():
    """构建波段策略扫描结果（含AI选股）"""
    swing = provider.get_strategy_stocks("swing", 6)
    recommendations = []
    for s in swing:
        kline = provider.get_kline(s["code"], s.get("base_price"))
        analysis = engine.analyze_swing(kline, s["price"])
        recommendations.append({
            "name": s["name"], "code": s["code"], "price": s["price"],
            "pct_1d": s["change_pct"], "pct_5d": round(s["change_pct"] * 0.7, 2),
            "trend": analysis.get("indicators", {}).get("ma5", 0) > analysis.get("indicators", {}).get("ma10", 0) and "多头排列" or "震荡整理",
            "main_flow": s["amount"], "amount": s["amount"],
            "ma5": analysis.get("indicators", {}).get("ma5", 0),
            "ma10": analysis.get("indicators", {}).get("ma10", 0),
            "score": analysis.get("score", 0),
            "signal": analysis.get("signal", ""),
        })
    recommendations.sort(key=lambda x: x.get("score", 0), reverse=True)
    return {"recommendations": recommendations}


def _build_ultra_scan():
    """构建超短策略扫描结果"""
    ultra = provider.get_strategy_stocks("ultra", 6)
    market = provider.get_market_overview()
    recommendations = []
    for s in ultra:
        analysis = engine.analyze_ultra(market, s)
        recommendations.append({
            "name": s["name"], "code": s["code"], "price": s["price"],
            "change_pct": s["change_pct"], "turnover": s["turnover"],
            "amount": s["amount"], "limit_times": s.get("limit_times", 1),
            "reason": s.get("sector", ""), "board_type": s.get("board_type", ""),
            "score": analysis.get("score", 0), "signal": analysis.get("signal", ""),
        })
    recommendations.sort(key=lambda x: x.get("score", 0), reverse=True)
    return {"recommendations": recommendations}

PORT = 8080
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")


# ─── 注册AI智能体 ───
def _init_agents():
    """初始化注册所有可用AI智能体"""
    # DeepSeek
    def ds_analyze(system, user):
        from ai.deepseek import _call_deepseek, get_api_key
        if not get_api_key():
            return {"answer": "[DeepSeek未配置]", "confidence": 0}
        answer = _call_deepseek(system, user, temperature=0.6)
        return {"answer": answer, "confidence": 75}

    def ds_chat_fn(question, market):
        from ai.deepseek import chat
        return chat(question, market)

    register_agent("DeepSeek", "deepseek", ds_analyze, ds_chat_fn)

    # 讯飞星辰
    def xf_analyze(system, user):
        from ai.xunfei import _call_xunfei, get_api_key
        if not get_api_key():
            return {"answer": "[讯飞未配置]", "confidence": 0}
        answer = _call_xunfei(system, user, temperature=0.6)
        return {"answer": answer, "confidence": 70}

    def xf_chat_fn(question, market):
        from ai.xunfei import chat
        return chat(question, market)

    register_agent("讯飞星辰", "xunfei", xf_analyze, xf_chat_fn)


_init_agents()


class StockPulseHandler(SimpleHTTPRequestHandler):

    def __init__(self, *args, **kwargs):
        self.directory = STATIC_DIR
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path.startswith("/api/"):
            self._handle_api(path, params)
            return

        if path == "/" or path == "":
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                data = {}
            self._handle_post_api(path, data)
        else:
            self.send_error(404)

    def _handle_api(self, path: str, params: dict):
        try:
            if path == "/api/all":
                data = provider.get_all_data()
                data["ai_report"] = analyzer.generate_report(
                    data["market"], data["swing"] + data["ultra"]
                )
                # 附加模板列表
                data["templates"] = get_templates()
                data["indicators"] = get_indicators()
                self._json_response(data)

            elif path == "/api/market":
                self._json_response(provider.get_market_overview())

            elif path == "/api/strategy":
                strategy = params.get("type", ["swing"])[0]
                count = int(params.get("count", ["6"])[0])
                stocks = provider.get_strategy_stocks(strategy, count)
                if strategy == "swing":
                    for s in stocks:
                        kline = provider.get_kline(s["code"], s.get("base_price"))
                        s["analysis"] = engine.analyze_swing(kline, s["price"])
                elif strategy == "ultra":
                    market = provider.get_market_overview()
                    for s in stocks:
                        s["analysis"] = engine.analyze_ultra(market, s)
                self._json_response(stocks)

            elif path == "/api/sectors":
                sectors = provider.get_market_overview().get("sectors", [])
                rotation = engine.analyze_sector_rotation(sectors)
                self._json_response(rotation)

            elif path == "/api/kline":
                code = params.get("code", ["000001"])[0]
                days = int(params.get("days", ["60"])[0])
                self._json_response(provider.get_kline(code, days=days))

            elif path == "/api/patterns":
                code = params.get("code", ["300750"])[0]
                kline = provider.get_kline(code)
                patterns = analyzer.recognize_patterns(kline)
                self._json_response(patterns)

            elif path == "/api/sentiment":
                market = provider.get_market_overview()
                self._json_response(analyzer.analyze_sentiment(market))

            elif path == "/api/report":
                market = provider.get_market_overview()
                swing = provider.get_strategy_stocks("swing", 6)
                ultra = provider.get_strategy_stocks("ultra", 6)
                report = analyzer.generate_report(market, swing + ultra)
                self._json_response({"report": report})

            elif path == "/api/chat":
                q = params.get("q", [""])[0]
                market = provider.get_market_overview()
                result = ds_chat(q, market)
                self._json_response({"answer": result.get("answer", "")})

            elif path == "/api/review":
                market = provider.get_market_overview()
                strategies = {
                    "swing": provider.get_strategy_stocks("swing", 6),
                    "ultra": provider.get_strategy_stocks("ultra", 6),
                }
                review = engine.generate_review(market, strategies)
                self._json_response({"review": review})

            # ── 多智能体协同投票（后台执行） ──
            elif path == "/api/multi_vote":
                import uuid
                task_id = str(uuid.uuid4())[:8]
                _bg_tasks[task_id] = {"status": "running", "result": None, "error": None}

                def _run_vote(tid):
                    try:
                        print(f"[Vote] 任务 {tid} 开始")
                        market = provider.get_market_overview()
                        print(f"[Vote] {tid} 获取行情完成")
                        from data.stock_pool import fetch_real_prices, STOCKS
                        fetch_real_prices([s["code"] for s in STOCKS])
                        print(f"[Vote] {tid} 刷新价格完成")
                        candidates = pick_ultra_v2(market).get("stocks", [])
                        print(f"[Vote] {tid} 候选池: {len(candidates)}只")
                        agents_config = [
                            {"name": "DeepSeek", "roles": ["technical", "sentiment", "sector", "risk"]},
                            {"name": "讯飞星辰", "roles": ["technical", "sentiment", "sector", "risk"]},
                        ]
                        print(f"[Vote] {tid} 开始多智能体分析...")
                        result = run_multi_agent_vote(candidates, market, agents_config)
                        print(f"[Vote] {tid} 完成! 获胜者: {[s['name'] for s in result.get('winners',[])]}")
                        _bg_tasks[tid] = {"status": "done", "result": result, "error": None}
                    except Exception as e:
                        import traceback
                        print(f"[Vote] {tid} 错误: {e}")
                        print(traceback.format_exc())
                        _bg_tasks[tid] = {"status": "error", "result": None, "error": str(e)}

                threading.Thread(target=_run_vote, args=(task_id,), daemon=True).start()
                self._json_response({"task_id": task_id, "status": "running"})

            # ── 查询投票任务状态 ──
            elif path == "/api/multi_vote/status":
                tid = params.get("id", [""])[0]
                task = _bg_tasks.get(tid, {"status": "not_found"})
                self._json_response(task)

            # ── 可用智能体列表 ──
            elif path == "/api/agents":
                self._json_response({"agents": get_available_agents()})

            # ── 定时调度 ──
            elif path == "/api/scheduler/status":
                self._json_response(get_scheduler_status())

            elif path == "/api/scheduler/results":
                self._json_response(load_results())

            # ── DeepSeek 配置管理 ──
            elif path == "/api/deepseek/status":
                self._json_response(ds_status())

            # ── 讯飞星辰 配置管理 ──
            elif path == "/api/xunfei/status":
                self._json_response(xf_status())

            # ── 实时指数（腾讯+新浪双源） ──
            elif path == "/api/realtime_indices":
                data = _fetch_realtime_indices()
                self._json_response(data)

            # ── 超短龙头AI选股 v1 ──
            elif path == "/api/ultra_leaders":
                market = provider.get_market_overview()
                result = pick_ultra_leaders(market)
                self._json_response(result)

            # ── 超短龙头AI选股 v2（多因子 → DeepSeek精选） ──
            elif path == "/api/ultra_v2":
                market = provider.get_market_overview()
                result = pick_ultra_v2(market)
                candidates = result.get("stocks", [])
                if ds_get_key():
                    ds_result = analyze_leaders(candidates, market)
                    result["agent"] = {
                        "analysis": ds_result.get("answer", ""),
                        "confidence": ds_result.get("confidence", 0),
                        "model": ds_result.get("model", ""),
                        "candidates_count": len(candidates),
                    }
                else:
                    # 回退到规则引擎
                    agent_result = agent.select_leaders(candidates, market)
                    result["stocks"] = agent_result.get("picks", [])
                    result["qualified_count"] = len(result["stocks"])
                    result["agent"] = {
                        "analysis": agent_result.get("answer", ""),
                        "confidence": agent_result.get("confidence", 0),
                        "model": "rule-based",
                        "candidates_count": len(candidates),
                    }
                self._json_response(result)

            # ── 回测模拟 ──
            elif path == "/api/backtest":
                result = run_backtest()
                self._json_response(result)

            elif path == "/api/backtest_v2":
                # 用最优参数跑回测
                result = run_backtest_v2(
                    max_positions=4, position_pct=0.35,
                    stop_loss_pct=-5, take_profit_pct=12,
                    max_hold_days=2, min_score=60, seed=42,
                )
                self._json_response(result)

            elif path == "/api/optimize":
                result = optimize_params()
                self._json_response(result)

            # ── 前端兼容接口（实时数据） ──
            elif path == "/api/market_data":
                self._json_response(_build_market_data())

            # ── 波段全市场筛选 ──
            elif path == "/api/swing_screen":
                result = screen_swing_stocks()
                # AI分析
                if ds_get_key() and result.get("stocks"):
                    from ai.deepseek import analyze_swing
                    ds_result = analyze_swing(result["stocks"], provider.get_market_overview())
                    result["agent"] = {"analysis": ds_result.get("answer", ""), "confidence": ds_result.get("confidence", 0), "model": "deepseek"}
                self._json_response(result)

            elif path == "/api/swing_scan":
                data = _build_swing_scan()
                market = provider.get_market_overview()
                stocks = data.get("recommendations", [])
                if ds_get_key():
                    ds_result = analyze_swing(stocks, market)
                    data["agent"] = {
                        "analysis": ds_result.get("answer", ""),
                        "confidence": ds_result.get("confidence", 0),
                        "model": ds_result.get("model", ""),
                    }
                else:
                    data["agent"] = {"analysis": "", "confidence": 0, "model": "", "note": "请配置DeepSeek API Key"}
                self._json_response(data)

            elif path == "/api/ultra_scan":
                data = _build_ultra_scan()
                market = provider.get_market_overview()
                stocks = data.get("recommendations", [])
                if ds_get_key():
                    ds_result = analyze_ultra(stocks, market)
                    data["agent"] = {
                        "analysis": ds_result.get("answer", ""),
                        "confidence": ds_result.get("confidence", 0),
                        "model": ds_result.get("model", ""),
                    }
                else:
                    data["agent"] = {"analysis": "", "confidence": 0, "model": "", "note": "请配置DeepSeek API Key"}
                self._json_response(data)

            # ── 新增: 自定义策略 ──
            elif path == "/api/templates":
                self._json_response(get_templates())

            elif path == "/api/indicators":
                self._json_response(get_indicators())

            elif path == "/api/custom_strategy":
                # GET: 用模板执行
                tpl = params.get("template", [""])[0]
                templates = get_templates()
                if tpl in templates:
                    all_stocks = (
                        provider.get_strategy_stocks("swing", 20)
                        + provider.get_strategy_stocks("ultra", 20)
                    )
                    result = run_custom_strategy(all_stocks, templates[tpl])
                    self._json_response(result)
                else:
                    self._json_response({"error": f"模板 '{tpl}' 不存在", "available": list(templates.keys())}, 400)

            # ── 新增: AI智能体 ──
            elif path == "/api/agent/history":
                self._json_response({"history": agent.get_history()})

            else:
                self._json_response({"error": "Unknown endpoint"}, 404)

        except Exception as e:
            self._json_response({"error": str(e)}, 500)

    def _handle_post_api(self, path: str, body: dict):
        try:
            # ── 自定义策略执行 ──
            if path == "/api/custom_strategy":
                strategy = body
                if not strategy.get("rules"):
                    self._json_response({"error": "缺少rules字段"}, 400)
                    return

                all_stocks = (
                    provider.get_strategy_stocks("swing", 20)
                    + provider.get_strategy_stocks("ultra", 20)
                )
                # 去重
                seen = set()
                unique = []
                for s in all_stocks:
                    if s["code"] not in seen:
                        seen.add(s["code"])
                        unique.append(s)

                result = run_custom_strategy(unique, strategy)
                # 附加K线和分析
                for s in result["stocks"]:
                    kline = provider.get_kline(s["code"], s.get("base_price"))
                    s["analysis"] = engine.analyze_swing(kline, s["price"])
                self._json_response(result)

            # ── AI智能体查询（DeepSeek） ──
            elif path == "/api/agent/query":
                q = body.get("query", "")
                if not q:
                    self._json_response({"error": "缺少query字段"}, 400)
                    return

                market = provider.get_market_overview()
                all_stocks = (
                    provider.get_strategy_stocks("swing", 15)
                    + provider.get_strategy_stocks("ultra", 15)
                )
                seen = set()
                unique = []
                for s in all_stocks:
                    if s["code"] not in seen:
                        seen.add(s["code"])
                        unique.append(s)

                result = ds_chat(q, market, unique)
                self._json_response(result)

            # ── DeepSeek API Key 设置 ──
            elif path == "/api/deepseek/set_key":
                key = body.get("key", "")
                if not key:
                    self._json_response({"ok": False, "error": "key为空"}, 400)
                    return
                ds_set_key(key)
                self._json_response({"ok": True, "status": ds_status()})

            elif path == "/api/deepseek/test":
                self._json_response(ds_test())

            # ── 讯飞星辰 Key设置 ──
            elif path == "/api/xunfei/set_key":
                key = body.get("key", "")
                if not key:
                    self._json_response({"ok": False, "error": "key为空"}, 400)
                    return
                xf_set_key(key)
                self._json_response({"ok": True, "status": xf_status()})

            elif path == "/api/xunfei/test":
                self._json_response(xf_test())

            # ── 调度器控制 ──
            elif path == "/api/scheduler/start":
                self._json_response(start_scheduler())

            elif path == "/api/scheduler/stop":
                self._json_response(stop_scheduler())

            elif path == "/api/scheduler/run":
                # 手动触发一次分析
                session = body.get("session", "手动触发")
                try:
                    result = run_analysis(session)
                    self._json_response({"ok": True, "result": result})
                except Exception as e:
                    self._json_response({"ok": False, "error": str(e)}, 500)

            # ── 保存自定义策略 ──
            elif path == "/api/strategy/save":
                name = body.get("name", "未命名")
                strategy = body.get("strategy", {})
                save_file = os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "data", "cache", f"custom_{name}.json"
                )
                with open(save_file, "w", encoding="utf-8") as f:
                    json.dump(strategy, f, ensure_ascii=False, indent=2)
                self._json_response({"ok": True, "name": name})

            else:
                self._json_response({"error": "Unknown POST endpoint"}, 404)

        except Exception as e:
            self._json_response({"error": str(e)}, 500)

    def _json_response(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def log_message(self, format, *args):
        if "/api/" in str(args[0]):
            print(f"[API] {args[0]}")


def run_server(port=PORT):
    os.makedirs(STATIC_DIR, exist_ok=True)
    server = ThreadedHTTPServer(("0.0.0.0", port), StockPulseHandler)
    print(f"""
╔══════════════════════════════════════════════╗
║   StockPulse Pro v2 - AI 智能分析系统        ║
║   http://0.0.0.0:{port}                      ║
║   自定义策略: POST /api/custom_strategy       ║
║   AI智能体:   POST /api/agent/query           ║
╚══════════════════════════════════════════════╝
    """)
    server.serve_forever()


if __name__ == "__main__":
    run_server()
