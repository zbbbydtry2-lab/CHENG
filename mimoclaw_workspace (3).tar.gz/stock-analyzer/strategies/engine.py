#!/usr/bin/env python3
"""
策略引擎 - 三大核心策略实现
波段策略 / 超短策略 / 板块轮动策略
"""
import random
from typing import Dict, List, Optional
from datetime import datetime


class StrategyEngine:
    """策略计算引擎"""

    # ─── 波段策略 ───
    @staticmethod
    def analyze_swing(kline: List[Dict], current_price: float = None) -> Dict:
        """
        波段策略分析
        核心逻辑: 多头排列 + 回踩MA10 + RSI 35-70 + 量能确认
        """
        if not kline or len(kline) < 20:
            return {"signal": "insufficient_data", "score": 0}

        closes = [k["close"] for k in kline]
        volumes = [k["volume"] for k in kline]

        # 使用传入的当前价（确保和显示价一致）
        current = current_price if current_price else closes[-1]

        # 计算均线（最后一天用当前价替换）
        closes_adj = closes[:-1] + [current]
        ma5 = sum(closes_adj[-5:]) / 5
        ma10 = sum(closes_adj[-10:]) / 10
        ma20 = sum(closes_adj[-20:]) / 20

        # 计算RSI
        gains, losses = [], []
        for i in range(1, min(15, len(closes))):
            diff = closes[-i] - closes[-i - 1]
            if diff > 0:
                gains.append(diff)
            else:
                losses.append(abs(diff))
        avg_gain = sum(gains) / 14 if gains else 0.001
        avg_loss = sum(losses) / 14 if losses else 0.001
        rsi = 100 - (100 / (1 + avg_gain / avg_loss))

        # 计算MACD
        ema12 = sum(closes[-12:]) / 12
        ema26 = sum(closes[-26:]) / 26 if len(closes) >= 26 else ema12
        dif = ema12 - ema26

        # 量比
        vol_avg = sum(volumes[-20:]) / 20 if len(volumes) >= 20 else sum(volumes) / len(volumes)
        vol_ratio = volumes[-1] / vol_avg if vol_avg > 0 else 1

        # 评分逻辑
        score = 50
        reasons = []

        # 均线多头排列
        if ma5 > ma10 > ma20:
            score += 15
            reasons.append("均线多头排列")
        elif ma5 > ma10:
            score += 8
            reasons.append("短期均线走强")

        # 回踩MA10
        if abs(current - ma10) / ma10 < 0.03:
            score += 10
            reasons.append("回踩MA10支撑")

        # RSI区间
        if 35 <= rsi <= 70:
            score += 10
            reasons.append(f"RSI健康({rsi:.0f})")
        elif rsi < 30:
            score += 5
            reasons.append(f"RSI超卖({rsi:.0f})")

        # 量能确认
        if vol_ratio > 1.3:
            score += 8
            reasons.append(f"放量({vol_ratio:.1f}倍)")
        elif vol_ratio > 1.0:
            score += 3

        # MACD金叉
        if dif > 0:
            score += 7
            reasons.append("MACD金叉")

        score = min(100, max(0, score))

        # 信号判定
        if score >= 80:
            signal = "strong_buy"
        elif score >= 65:
            signal = "buy"
        elif score >= 50:
            signal = "hold"
        elif score >= 35:
            signal = "weak"
        else:
            signal = "avoid"

        # 计算止损止盈
        buy_low = round(current * 0.97, 2)
        buy_high = round(current * 1.01, 2)
        stop_loss = round(current * 0.95, 2)
        target = round(current * 1.10, 2)

        return {
            "signal": signal,
            "score": score,
            "reasons": reasons,
            "indicators": {
                "ma5": round(ma5, 2), "ma10": round(ma10, 2), "ma20": round(ma20, 2),
                "rsi": round(rsi, 1), "macd_dif": round(dif, 3),
                "vol_ratio": round(vol_ratio, 2),
            },
            "trading": {
                "buy_zone": [buy_low, buy_high],
                "stop_loss": stop_loss,
                "target": target,
                "hold_days": "3-15天",
                "risk_reward": "2:1",
            },
        }

    # ─── 超短策略 ───
    @staticmethod
    def analyze_ultra(market_data: Dict, stock: Dict) -> Dict:
        """
        超短策略分析
        核心逻辑: 龙头打板 + 情绪共振 + 量能验证
        """
        stats = market_data.get("stats", {})
        sentiment = market_data.get("sentiment", {})

        lu_count = stats.get("limit_up_count", 0)
        seal_rate = stats.get("seal_rate", 50)
        temp = sentiment.get("temperature", 50)
        max_board = sentiment.get("max_board", 1)

        limit_times = stock.get("limit_times", 1)
        turnover = stock.get("turnover", 10)
        vol_ratio = stock.get("volume_ratio", 1)

        score = 50
        reasons = []

        # 连板高度
        if limit_times >= 4:
            score += 20
            reasons.append(f"{limit_times}连板龙头")
        elif limit_times >= 2:
            score += 12
            reasons.append(f"{limit_times}连板")

        # 情绪温度
        if temp >= 70:
            score += 12
            reasons.append("情绪偏暖")
        elif temp >= 50:
            score += 5
        elif temp < 30:
            score -= 10
            reasons.append("情绪冰点风险")

        # 封板率
        if seal_rate >= 80:
            score += 8
            reasons.append(f"封板率{seal_rate:.0f}%")

        # 换手率
        if 8 <= turnover <= 25:
            score += 5
            reasons.append("换手健康")
        elif turnover > 30:
            score -= 5
            reasons.append("换手过高")

        # 量比
        if vol_ratio >= 2.0:
            score += 5
            reasons.append(f"量比{vol_ratio:.1f}")

        # 涨停家数
        if lu_count >= 60:
            score += 5
            reasons.append(f"涨停{lu_count}家")

        score = min(100, max(0, score))

        if score >= 80:
            signal = "打板"
        elif score >= 65:
            signal = "追涨"
        elif score >= 50:
            signal = "观望"
        else:
            signal = "回避"

        return {
            "signal": signal,
            "score": score,
            "reasons": reasons,
            "risk_level": "高" if score >= 70 else "中" if score >= 50 else "低",
        }

    # ─── 板块轮动策略 ───
    @staticmethod
    def analyze_sector_rotation(sectors: List[Dict]) -> Dict:
        """
        板块轮动分析
        核心逻辑: 资金流向 + 涨幅排序 + 持续性判断
        """
        if not sectors:
            return {"phases": {}, "ranking": []}

        # 按资金流入排序
        sorted_by_flow = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)

        # 板块生命周期判断
        phases = {}
        for s in sorted_by_flow[:8]:
            name = s["name"]
            pct = s.get("change_pct", 0)
            flow = s.get("main_net", 0)

            if pct > 5 and flow > 5e8:
                phase = "高潮"
                icon = "🔥"
            elif pct > 3 and flow > 0:
                phase = "发酵"
                icon = "🚀"
            elif pct > 0 and flow > 0:
                phase = "启动"
                icon = "🌱"
            elif pct < 0 and flow < 0:
                phase = "退潮"
                icon = "🌊"
            else:
                phase = "分歧"
                icon = "⚡"

            phases[name] = {
                "phase": phase, "icon": icon,
                "change_pct": pct, "main_net": flow,
            }

        # 推荐排序
        ranking = []
        for i, s in enumerate(sorted_by_flow[:5]):
            ranking.append({
                "rank": i + 1,
                "name": s["name"],
                "change_pct": s.get("change_pct", 0),
                "main_net": s.get("main_net", 0),
                "phase": phases.get(s["name"], {}).get("phase", "未知"),
            })

        # 主线判断
        hot_sectors = [s for s in sorted_by_flow[:3] if s.get("main_net", 0) > 2e8]
        main_line = "、".join([s["name"] for s in hot_sectors]) if hot_sectors else "无明确主线"

        return {
            "phases": phases,
            "ranking": ranking,
            "main_line": main_line,
            "hot_count": len(hot_sectors),
        }

    # ─── AI复盘摘要 ───
    @staticmethod
    def generate_review(market: Dict, strategies: Dict) -> str:
        """生成AI复盘文本"""
        stats = market.get("stats", {})
        sent = market.get("sentiment", {})

        lu = stats.get("limit_up_count", 0)
        ld = stats.get("limit_down_count", 0)
        temp = sent.get("temperature", 50)
        stage = sent.get("stage", "震荡")
        style = sent.get("style", "分歧震荡")

        swing_count = len(strategies.get("swing", []))
        ultra_count = len(strategies.get("ultra", []))

        lines = [
            f"📊 今日市场{stage}，情绪温度{temp}度。",
            f"涨停{lu}家，跌停{ld}家，资金风格为{style}。",
            f"波段策略筛出{swing_count}只标的，超短策略{ultra_count}只标的。",
        ]

        if temp >= 70:
            lines.append("✅ 情绪偏暖，可积极参与主线龙头。")
        elif temp >= 50:
            lines.append("⚖️ 情绪震荡，建议控制仓位，关注回踩低吸机会。")
        elif temp >= 30:
            lines.append("⚠️ 情绪偏冷，轻仓试错为主。")
        else:
            lines.append("🚫 情绪冰点，建议空仓观望。")

        return "\n".join(lines)


# 全局实例
engine = StrategyEngine()
