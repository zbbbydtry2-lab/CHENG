#!/usr/bin/env python3
"""
自定义策略引擎
支持: 声明式规则DSL / 条件组合 / 安全执行
"""
import json
import operator
from typing import Dict, List, Any, Callable


# ─── 操作符映射 ───
OPS = {
    ">": operator.gt, "<": operator.lt, ">=": operator.ge,
    "<=": operator.le, "==": operator.eq, "!=": operator.ne,
    "between": lambda v, r: r[0] <= v <= r[1],
    "not_between": lambda v, r: v < r[0] or v > r[1],
    "in": lambda v, lst: v in lst,
    "contains": lambda v, s: str(s).lower() in str(v).lower(),
}

# ─── 可用指标 ───
INDICATORS = {
    "price": "当前价格",
    "change_pct": "涨跌幅(%)",
    "turnover": "换手率(%)",
    "volume_ratio": "量比",
    "amount": "成交额",
    "ma5": "5日均线",
    "ma10": "10日均线",
    "ma20": "20日均线",
    "rsi": "RSI(14)",
    "macd": "MACD DIF",
    "limit_times": "连板数",
    "sector": "所属板块",
    "score": "综合评分",
}

# ─── 预设策略模板 ───
TEMPLATES = {
    "强势突破": {
        "name": "强势突破",
        "desc": "放量突破前高，量价齐升",
        "rules": [
            {"field": "change_pct", "op": ">", "value": 3},
            {"field": "volume_ratio", "op": ">", "value": 1.5},
            {"field": "turnover", "op": "between", "value": [5, 25]},
            {"field": "rsi", "op": "between", "value": [50, 80]},
        ],
        "sort_by": "change_pct",
        "sort_order": "desc",
        "limit": 10,
    },
    "底部回踩": {
        "name": "底部回踩",
        "desc": "回踩MA10支撑，RSI低位，等待反弹",
        "rules": [
            {"field": "change_pct", "op": ">", "value": -2},
            {"field": "change_pct", "op": "<", "value": 3},
            {"field": "rsi", "op": "between", "value": [25, 50]},
            {"field": "ma10", "op": ">", "value": 0},
        ],
        "sort_by": "rsi",
        "sort_order": "asc",
        "limit": 10,
    },
    "龙头打板": {
        "name": "龙头打板",
        "desc": "连板龙头，高换手，情绪共振",
        "rules": [
            {"field": "limit_times", "op": ">=", "value": 2},
            {"field": "change_pct", "op": ">", "value": 5},
            {"field": "turnover", "op": "between", "value": [8, 35]},
        ],
        "sort_by": "limit_times",
        "sort_order": "desc",
        "limit": 10,
    },
    "低换手潜伏": {
        "name": "低换手潜伏",
        "desc": "低换手率，缩量整理，等待放量",
        "rules": [
            {"field": "turnover", "op": "<", "value": 5},
            {"field": "change_pct", "op": "between", "value": [-3, 3]},
            {"field": "rsi", "op": "between", "value": [30, 55]},
        ],
        "sort_by": "turnover",
        "sort_order": "asc",
        "limit": 10,
    },
    "量价齐升": {
        "name": "量价齐升",
        "desc": "放量上涨，趋势健康",
        "rules": [
            {"field": "change_pct", "op": ">", "value": 2},
            {"field": "volume_ratio", "op": ">", "value": 2.0},
            {"field": "amount", "op": ">", "value": 5e8},
        ],
        "sort_by": "volume_ratio",
        "sort_order": "desc",
        "limit": 10,
    },
}


def evaluate_condition(stock: Dict, rule: Dict) -> bool:
    """评估单个条件"""
    field = rule.get("field", "")
    op = rule.get("op", ">")
    value = rule.get("value")

    stock_val = stock.get(field)

    # 特殊处理：板块匹配
    if field == "sector":
        if isinstance(value, list):
            return OPS.get("in", lambda a, b: False)(stock_val, value)
        return OPS.get("contains", lambda a, b: False)(stock_val, value)

    # 数值比较
    if stock_val is None:
        return False

    try:
        stock_val = float(stock_val)
    except (TypeError, ValueError):
        return False

    fn = OPS.get(op)
    if fn is None:
        return False

    try:
        return fn(stock_val, value)
    except Exception:
        return False


def run_custom_strategy(stocks: List[Dict], strategy: Dict) -> Dict:
    """
    执行自定义策略

    strategy 格式:
    {
        "name": "策略名",
        "desc": "描述",
        "rules": [
            {"field": "change_pct", "op": ">", "value": 3},
            {"field": "rsi", "op": "between", "value": [30, 70]},
        ],
        "logic": "and",  # and / or
        "sort_by": "score",
        "sort_order": "desc",
        "limit": 10,
    }
    """
    rules = strategy.get("rules", [])
    logic = strategy.get("logic", "and")
    sort_by = strategy.get("sort_by", "score")
    sort_order = strategy.get("sort_order", "desc")
    limit = strategy.get("limit", 10)

    if not rules:
        return {"stocks": [], "count": 0, "error": "无规则"}

    # 过滤
    matched = []
    for stock in stocks:
        results = [evaluate_condition(stock, r) for r in rules]
        if logic == "or":
            passed = any(results)
        else:
            passed = all(results)

        if passed:
            # 计算匹配置信度
            conf = sum(results) / len(results) * 100
            stock_copy = dict(stock)
            stock_copy["match_confidence"] = round(conf, 1)
            stock_copy["matched_rules"] = sum(results)
            stock_copy["total_rules"] = len(results)
            matched.append(stock_copy)

    # 排序
    reverse = sort_order == "desc"
    try:
        matched.sort(key=lambda x: float(x.get(sort_by, 0)), reverse=reverse)
    except (TypeError, ValueError):
        matched.sort(key=lambda x: str(x.get(sort_by, "")), reverse=reverse)

    # 截断
    matched = matched[:limit]

    return {
        "stocks": matched,
        "count": len(matched),
        "strategy_name": strategy.get("name", "自定义"),
        "strategy_desc": strategy.get("desc", ""),
        "rules_count": len(rules),
    }


def get_templates() -> Dict:
    """获取所有预设模板"""
    return TEMPLATES


def get_indicators() -> Dict:
    """获取可用指标列表"""
    return INDICATORS
