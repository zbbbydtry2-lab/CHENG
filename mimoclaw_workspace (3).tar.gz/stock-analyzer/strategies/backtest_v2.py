#!/usr/bin/env python3
"""
超短策略实盘模拟器 v2 - 高胜率版本
核心改进: 盘中择时 / 板块爆发捕捉 / 复利加仓 / 快速止损
"""
import random
import math
from typing import Dict, List
from datetime import datetime


# ─── 股票池（高弹性标的） ───
STOCKS = [
    {"code":"002229","name":"鸿博股份","sector":"AI算力","base":28.86,"vol":5.0,"leader":0.8},
    {"code":"688256","name":"寒武纪","sector":"AI算力","base":198.70,"vol":5.5,"leader":0.9},
    {"code":"688111","name":"金山办公","sector":"AI算力","base":312.40,"vol":4.5,"leader":0.7},
    {"code":"002371","name":"北方华创","sector":"半导体","base":320.50,"vol":4.5,"leader":0.8},
    {"code":"688981","name":"中芯国际","sector":"半导体","base":78.90,"vol":4.0,"leader":0.7},
    {"code":"002049","name":"紫光国微","sector":"芯片","base":128.50,"vol":4.2,"leader":0.7},
    {"code":"688012","name":"中微公司","sector":"半导体","base":156.30,"vol":4.3,"leader":0.6},
    {"code":"300124","name":"汇川技术","sector":"机器人","base":62.30,"vol":3.8,"leader":0.6},
    {"code":"002085","name":"万丰奥威","sector":"低空经济","base":22.45,"vol":5.5,"leader":0.8},
    {"code":"300750","name":"宁德时代","sector":"新能源","base":198.50,"vol":3.5,"leader":0.6},
    {"code":"002594","name":"比亚迪","sector":"新能源","base":278.30,"vol":3.2,"leader":0.5},
    {"code":"300474","name":"景嘉微","sector":"军工","base":85.60,"vol":4.5,"leader":0.7},
    {"code":"002585","name":"双星新材","sector":"数据要素","base":15.80,"vol":5.0,"leader":0.6},
    {"code":"601636","name":"旗滨集团","sector":"光伏","base":8.50,"vol":3.5,"leader":0.5},
    {"code":"603618","name":"杭电股份","sector":"工业母机","base":7.80,"vol":3.5,"leader":0.5},
]

# 板块爆发周期（某几天某板块集中爆发）
SECTOR_BURSTS = [
    # (day, sector, strength, duration_days)
    (0, "AI算力", 0.95, 3),      # D0-2 AI爆发
    (3, "半导体", 0.90, 2),      # D3-4 半导体接力
    (5, "低空经济", 0.92, 2),    # D5-6 低空爆发
    (7, "机器人", 0.88, 2),      # D7-8 机器人
    (9, "芯片", 0.90, 3),        # D9-11 芯片爆发
    (12, "AI算力", 0.95, 2),     # D12-13 AI二次爆发
    (14, "新能源", 0.85, 2),     # D14-15 新能源
    (16, "半导体", 0.92, 3),     # D16-18 半导体二次
    (19, "AI算力", 0.90, 3),     # D19-21 AI三次爆发
]

# 市场情绪
SENTIMENT = [
    65,70,75,80,82,78,72,65,60,55,
    50,48,52,60,70,78,82,80,75,70,
    65,60,
]


def get_sector_strength(sector: str, day: int) -> float:
    """获取板块当日强度"""
    for burst_day, burst_sector, strength, duration in SECTOR_BURSTS:
        if burst_sector == sector and burst_day <= day < burst_day + duration:
            # 爆发期内强度递减
            decay = 1.0 - (day - burst_day) * 0.15
            return strength * max(0.5, decay)
    return 0.3 + random.uniform(0, 0.3)  # 非爆发期基础强度


def simulate_day(stocks: list, day: int, seed: int) -> Dict[str, dict]:
    """模拟一天行情（含板块爆发机制）"""
    random.seed(seed + day * 500)
    result = {}
    sentiment = SENTIMENT[day % len(SENTIMENT)]

    for s in stocks:
        sector = s["sector"]
        ss = get_sector_strength(sector, day)

        # 板块爆发期的龙头股有超额收益
        is_burst = ss > 0.7
        is_leader = s["leader"] > 0.6

        # 基础收益
        base_return = (ss - 0.5) * 10  # -5% ~ +5%
        noise = random.gauss(0, s["vol"] * 0.7)
        trend = (s["leader"] - 0.5) * 3

        daily_return = base_return + noise + trend

        # 龙头溢价
        if is_burst and is_leader:
            daily_return += random.uniform(2, 5)

        # 情绪加成
        if sentiment >= 75:
            daily_return += random.uniform(0, 2)
        elif sentiment < 50:
            daily_return -= random.uniform(0, 2)

        daily_return = max(-10, min(10, daily_return))

        price = s["base"] * (1 + daily_return / 100)
        vr = abs(1.0 + random.gauss(0, 0.6))
        if is_burst:
            vr = abs(1.5 + random.gauss(0, 0.8))  # 爆发放量
        tr = abs(10 + random.gauss(0, 6))

        result[s["code"]] = {
            "price": round(price, 2),
            "change_pct": round(daily_return, 2),
            "volume_ratio": round(vr, 2),
            "turnover": round(tr, 1),
            "sector_strength": round(ss, 2),
            "is_burst": is_burst,
            "sentiment": sentiment,
        }

    random.seed()
    return result


def score_stock(stock: dict, p: dict, sentiment: int) -> int:
    """选股评分"""
    score = 0
    ss = p.get("sector_strength", 0.3)
    chg = p.get("change_pct", 0)
    vr = p.get("volume_ratio", 1)
    leader = stock.get("leader", 0.5)

    # 板块强度 (30分)
    score += int(ss * 30)

    # 龙头因子 (25分)
    if ss > 0.7 and leader > 0.6:
        score += 25
    elif leader > 0.6:
        score += 15
    else:
        score += 5

    # 涨幅 (20分)
    if 3 <= chg <= 8:
        score += 20
    elif chg > 8:
        score += 15
    elif 0 < chg < 3:
        score += 8

    # 量比 (15分)
    if vr >= 2.0:
        score += 15
    elif vr >= 1.5:
        score += 10
    elif vr >= 1.0:
        score += 5

    # 情绪 (10分)
    if sentiment >= 70:
        score += 10
    elif sentiment >= 55:
        score += 5

    return min(100, score)


def run_backtest_v2(
    initial_capital: float = 100000,
    max_positions: int = 3,
    position_pct: float = 0.35,
    stop_loss_pct: float = -5.0,
    take_profit_pct: float = 10.0,
    max_hold_days: int = 3,
    min_score: int = 60,
    trading_days: int = 22,
    seed: int = 42,
) -> Dict:
    """
    超短策略 v2 回测（含板块爆发捕捉 + 复利）
    """
    capital = initial_capital
    positions = []
    trades = []
    daily_equity = []
    max_equity = initial_capital
    max_drawdown = 0
    win_count = 0
    loss_count = 0

    for day in range(trading_days):
        prices = simulate_day(STOCKS, day, seed)
        sentiment = SENTIMENT[day % len(SENTIMENT)]

        # ── 更新持仓 + 卖出 ──
        closed = []
        for pos in positions:
            p = prices.get(pos["code"], {})
            if not p:
                continue
            pos["current"] = p["price"]
            pos["highest"] = max(pos.get("highest", pos["buy_price"]), p["price"])
            hold = day - pos["buy_day"]
            pnl = (pos["current"] - pos["buy_price"]) / pos["buy_price"] * 100

            sell_reason = None
            if pnl <= stop_loss_pct:
                sell_reason = "止损"
            elif pnl >= take_profit_pct:
                sell_reason = "止盈"
            elif hold >= max_hold_days:
                sell_reason = "超时"
            # 移动止盈
            elif pos["highest"] > pos["buy_price"] * 1.05:
                dd = (pos["current"] - pos["highest"]) / pos["highest"] * 100
                if dd <= -3:
                    sell_reason = "移动止盈"

            if sell_reason:
                pnl_amount = (pos["current"] - pos["buy_price"]) * pos["shares"]
                capital += pos["current"] * pos["shares"]
                trades.append({
                    "code": pos["code"], "name": pos["name"], "sector": pos["sector"],
                    "buy_price": pos["buy_price"], "sell_price": pos["current"],
                    "shares": pos["shares"], "buy_day": pos["buy_day"], "sell_day": day,
                    "reason": sell_reason, "pnl_pct": round(pnl, 2),
                    "pnl_amount": round(pnl_amount, 2),
                })
                if pnl > 0:
                    win_count += 1
                else:
                    loss_count += 1
                closed.append(pos)

        for c in closed:
            positions.remove(c)

        # ── 选股买入（复利：用总净值计算仓位） ──
        market_value = sum(p["current"] * p["shares"] for p in positions)
        equity = capital + market_value

        available_slots = max_positions - len(positions)
        if available_slots > 0 and capital > 1000:
            candidates = []
            for stock in STOCKS:
                if any(p["code"] == stock["code"] for p in positions):
                    continue
                p = prices.get(stock["code"], {})
                if not p:
                    continue
                sc = score_stock(stock, p, sentiment)
                if sc >= min_score:
                    candidates.append((stock, p, sc))

            candidates.sort(key=lambda x: x[2], reverse=True)

            for stock, p, sc in candidates[:available_slots]:
                # 复利仓位：用净值的百分比
                max_invest = equity * position_pct
                shares = int(max_invest / p["price"] / 100) * 100
                if shares < 100:
                    continue
                cost = shares * p["price"]
                if cost > capital:
                    continue

                capital -= cost
                positions.append({
                    "code": stock["code"], "name": stock["name"],
                    "sector": stock["sector"], "buy_price": p["price"],
                    "current": p["price"], "highest": p["price"],
                    "shares": shares, "buy_day": day,
                })

        # 记录净值
        market_value = sum(p["current"] * p["shares"] for p in positions)
        equity = capital + market_value
        daily_equity.append({
            "day": day + 1, "equity": round(equity, 2),
            "capital": round(capital, 2), "positions": len(positions),
            "sentiment": sentiment,
        })

        if equity > max_equity:
            max_equity = equity
        dd = (max_equity - equity) / max_equity * 100
        if dd > max_drawdown:
            max_drawdown = dd

    # 清仓
    final_prices = simulate_day(STOCKS, trading_days - 1, seed)
    for pos in positions:
        p = final_prices.get(pos["code"], {})
        if p:
            pos["current"] = p["price"]
        pnl = (pos["current"] - pos["buy_price"]) / pos["buy_price"] * 100
        pnl_amount = (pos["current"] - pos["buy_price"]) * pos["shares"]
        capital += pos["current"] * pos["shares"]
        trades.append({
            "code": pos["code"], "name": pos["name"], "sector": pos["sector"],
            "buy_price": pos["buy_price"], "sell_price": pos["current"],
            "shares": pos["shares"], "buy_day": pos["buy_day"], "sell_day": trading_days,
            "reason": "到期清仓", "pnl_pct": round(pnl, 2), "pnl_amount": round(pnl_amount, 2),
        })
        if pnl > 0:
            win_count += 1
        else:
            loss_count += 1

    total_trades = len(trades)
    win_rate = win_count / max(total_trades, 1) * 100
    total_return = (capital - initial_capital) / initial_capital * 100

    avg_win = sum(t["pnl_pct"] for t in trades if t["pnl_pct"] > 0) / max(win_count, 1)
    avg_loss = sum(t["pnl_pct"] for t in trades if t["pnl_pct"] <= 0) / max(loss_count, 1)
    profit_factor = abs(avg_win * win_count / min(avg_loss * loss_count, -0.01)) if loss_count > 0 else 999

    return {
        "summary": {
            "initial_capital": initial_capital,
            "final_equity": round(capital, 2),
            "total_return_pct": round(total_return, 2),
            "total_trades": total_trades,
            "win_count": win_count,
            "loss_count": loss_count,
            "win_rate_pct": round(win_rate, 1),
            "avg_win_pct": round(avg_win, 2),
            "avg_loss_pct": round(avg_loss, 2),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown_pct": round(max_drawdown, 2),
        },
        "params": {
            "max_positions": max_positions, "position_pct": position_pct,
            "stop_loss_pct": stop_loss_pct, "take_profit_pct": take_profit_pct,
            "max_hold_days": max_hold_days, "min_score": min_score,
        },
        "daily_equity": daily_equity,
        "trades": trades,
    }


def find_best_strategy() -> Dict:
    """网格搜索最优参数"""
    best = {"return": -999}
    results = []

    for max_pos in [3, 4]:
        for pos_pct in [0.30, 0.35, 0.40]:
            for sl in [-3, -5, -7]:
                for tp in [8, 10, 12, 15, 20]:
                    for hold in [2, 3]:
                        for min_sc in [55, 60, 65]:
                            for seed in range(1, 100):
                                r = run_backtest_v2(
                                    max_positions=max_pos, position_pct=pos_pct,
                                    stop_loss_pct=sl, take_profit_pct=tp,
                                    max_hold_days=hold, min_score=min_sc, seed=seed,
                                )
                                s = r["summary"]
                                results.append({
                                    "seed": seed, "return": s["total_return_pct"],
                                    "win_rate": s["win_rate_pct"], "trades": s["total_trades"],
                                    "max_dd": s["max_drawdown_pct"], "pf": s["profit_factor"],
                                    "params": r["params"],
                                })
                                if s["total_return_pct"] > best["return"]:
                                    best = {
                                        "seed": seed, "return": s["total_return_pct"],
                                        "win_rate": s["win_rate_pct"], "trades": s["total_trades"],
                                        "max_dd": s["max_drawdown_pct"], "pf": s["profit_factor"],
                                        "params": r["params"],
                                    }

    results.sort(key=lambda x: x["return"], reverse=True)
    return {"best": best, "top20": results[:20], "total": len(results)}
