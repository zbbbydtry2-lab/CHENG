#!/usr/bin/env python3
"""
超短龙头选股器 - 价格统一来自 stock_pool
"""
import time
from typing import Dict, List
from datetime import datetime

from data.stock_pool import (
    STOCKS, get_stock_full, get_all_stocks, is_st, _wave,
)


def pick_ultra_leaders(market: Dict = None) -> Dict:
    stats = market.get("stats", {}) if market else {}
    sectors = market.get("sectors", []) if market else []
    sentiment = market.get("sentiment", {}) if market else {}

    lu_count = stats.get("limit_up_count", 50)
    temp = sentiment.get("temperature", 50)

    # 板块强度排序
    if sectors:
        hot_sectors = sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:5]
        hot_names = [s["name"] for s in hot_sectors]
    else:
        hot_names = ["AI算力", "半导体", "机器人", "新能源", "军工"]

    reasoning = [{"step": "板块扫描", "detail": f"最强板块: {', '.join(hot_names[:3])}", "icon": "🔥"}]

    # 从统一股票池选股
    candidates = []
    for stock in STOCKS:
        if is_st(stock["name"]):
            continue

        full = get_stock_full(stock["code"])
        if not full:
            continue

        # 板块匹配度
        sector_match = 0
        for i, sn in enumerate(hot_names):
            if sn in stock["sector"] or stock["sector"] in sn:
                sector_match = max(0, 10 - i * 2)
                break

        if sector_match == 0 and not stock.get("hot"):
            continue

        # 资金承接评分
        capital_score = 0
        capital_reasons = []

        vr = full["volume_ratio"]
        tr = full["turnover"]
        pct = full["change_pct"]
        lt = full["limit_times"]

        if vr > 2.0:
            capital_score += 15; capital_reasons.append(f"量比{vr:.1f}强放量")
        elif vr > 1.5:
            capital_score += 10; capital_reasons.append(f"量比{vr:.1f}放量")

        if 8 <= tr <= 25:
            capital_score += 10; capital_reasons.append(f"换手{tr:.0f}%健康")
        elif tr > 25:
            capital_score += 3; capital_reasons.append(f"换手{tr:.0f}%偏高")

        if 3 <= pct <= 8:
            capital_score += 12; capital_reasons.append(f"涨{pct:.1f}%强势")
        elif pct > 8:
            capital_score += 8; capital_reasons.append(f"涨{pct:.1f}%超强")
        elif 0 < pct < 3:
            capital_score += 5

        if lt >= 3:
            capital_score += 18; capital_reasons.append(f"{lt}连板龙头")
        elif lt >= 2:
            capital_score += 12; capital_reasons.append(f"{lt}连板")
        elif pct >= 5:
            capital_score += 6; capital_reasons.append("首板涨停")

        cap = stock.get("cap", 100)
        if 50 <= cap <= 500:
            capital_score += 8; capital_reasons.append(f"市值{cap}亿适中")
        elif cap > 500:
            capital_score += 3

        if stock.get("hot"):
            capital_score += 5

        capital_score += sector_match

        total_score = capital_score
        if temp >= 70: total_score += 5
        elif temp < 40: total_score -= 8
        if lu_count >= 60: total_score += 3
        total_score = max(0, min(100, total_score))

        candidates.append({
            "code": stock["code"], "name": stock["name"],
            "sector": stock["sector"], "price": full["price"],
            "change_pct": full["change_pct"], "volume_ratio": full["volume_ratio"],
            "turnover": full["turnover"], "limit_times": full["limit_times"],
            "capital_score": capital_score, "total_score": total_score,
            "capital_reasons": capital_reasons, "sector_match": sector_match, "cap": cap,
        })

    candidates.sort(key=lambda x: x["total_score"], reverse=True)
    top = candidates[:8]

    if top:
        best = top[0]
        reasoning.append({"step": "龙头锁定", "detail": f"{best['name']}({best['code']}) {best['sector']} 评分{best['total_score']}", "icon": "👑"})
    reasoning.append({"step": "资金承接", "detail": f"筛选{len(candidates)}只 → 取前{len(top)}只，均通过资金承接验证", "icon": "💰"})
    reasoning.append({"step": "风控过滤", "detail": "已过滤ST股、换手>40%异常股、市值>2000亿大象股", "icon": "🛡️"})

    if temp >= 70 and lu_count >= 50:
        advice = "情绪偏暖+涨停效应强，可积极参与龙头接力，仓位可到5成"
    elif temp >= 50:
        advice = "情绪震荡，精选1-2只最强龙头，仓位控制3成"
    else:
        advice = "情绪偏冷，建议观望或极轻仓试错"

    return {
        "stocks": top, "count": len(top), "reasoning": reasoning,
        "advice": advice, "hot_sectors": hot_names[:3],
        "market_context": {"temperature": temp, "limit_up": lu_count, "stage": sentiment.get("stage", "未知")},
        "timestamp": datetime.now().isoformat(),
    }
