#!/usr/bin/env python3
"""
超短策略实盘模拟器 - 1个月回测
模拟22个交易日，验证策略胜率与收益率
"""
import random
import math
import json
import os
from typing import Dict, List, Tuple
from datetime import datetime, timedelta


# ─── 模拟股票池（真实A股参数） ───
SIM_STOCKS = [
    {"code":"002229","name":"鸿博股份","sector":"AI算力","base":28.86,"vol":4.5,"trend":0.6},
    {"code":"688256","name":"寒武纪","sector":"AI算力","base":198.70,"vol":5.0,"trend":0.7},
    {"code":"002371","name":"北方华创","sector":"半导体","base":320.50,"vol":4.0,"trend":0.5},
    {"code":"688981","name":"中芯国际","sector":"半导体","base":78.90,"vol":3.8,"trend":0.5},
    {"code":"300124","name":"汇川技术","sector":"机器人","base":62.30,"vol":3.5,"trend":0.55},
    {"code":"002085","name":"万丰奥威","sector":"低空经济","base":22.45,"vol":5.5,"trend":0.65},
    {"code":"300750","name":"宁德时代","sector":"新能源","base":198.50,"vol":3.2,"trend":0.5},
    {"code":"002594","name":"比亚迪","sector":"新能源","base":278.30,"vol":3.0,"trend":0.5},
    {"code":"300474","name":"景嘉微","sector":"军工","base":85.60,"vol":4.2,"trend":0.6},
    {"code":"002049","name":"紫光国微","sector":"芯片","base":128.50,"vol":3.8,"trend":0.55},
    {"code":"688012","name":"中微公司","sector":"半导体","base":156.30,"vol":4.0,"trend":0.5},
    {"code":"688111","name":"金山办公","sector":"AI算力","base":312.40,"vol":4.5,"trend":0.6},
    {"code":"002415","name":"海康威视","sector":"AI算力","base":32.70,"vol":2.5,"trend":0.4},
    {"code":"300015","name":"爱尔眼科","sector":"医药","base":18.90,"vol":2.8,"trend":0.35},
    {"code":"600519","name":"贵州茅台","sector":"白酒","base":1680.00,"vol":1.5,"trend":0.3},
    {"code":"601318","name":"中国平安","sector":"金融","base":52.80,"vol":2.0,"trend":0.35},
    {"code":"600036","name":"招商银行","sector":"银行","base":38.45,"vol":1.8,"trend":0.3},
    {"code":"002585","name":"双星新材","sector":"数据要素","base":15.80,"vol":4.8,"trend":0.55},
    {"code":"601636","name":"旗滨集团","sector":"光伏","base":8.50,"vol":3.5,"trend":0.45},
    {"code":"603618","name":"杭电股份","sector":"工业母机","base":7.80,"vol":3.2,"trend":0.4},
]

# 板块轮动周期（模拟一个月内板块强弱变化）
SECTOR_CYCLES = {
    "AI算力":    [1,1,1,0.8,0.6,0.4,0.3,0.5,0.7,0.9,1,1,0.8,0.6,0.5,0.7,0.9,1,1,0.8,0.6,0.5],
    "半导体":    [0.6,0.7,0.8,0.9,1,1,1,0.8,0.6,0.5,0.4,0.6,0.8,1,1,1,0.8,0.6,0.5,0.7,0.9,1],
    "机器人":    [0.5,0.6,0.8,1,1,1,0.8,0.6,0.5,0.4,0.6,0.8,1,1,0.8,0.6,0.5,0.7,0.9,1,1,0.8],
    "低空经济":  [0.4,0.5,0.7,0.9,1,1,1,0.8,0.6,0.5,0.4,0.5,0.7,0.9,1,1,0.8,0.6,0.5,0.4,0.6,0.8],
    "新能源":    [0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.7,0.9,1,1,0.8,0.6,0.5,0.7,0.9,1,1,0.8,0.6,0.5],
    "芯片":      [0.5,0.6,0.7,0.8,0.9,1,1,1,0.8,0.6,0.5,0.4,0.6,0.8,1,1,0.8,0.6,0.5,0.7,0.9,1],
    "军工":      [0.8,0.9,1,1,0.8,0.6,0.5,0.7,0.9,1,1,0.8,0.6,0.5,0.4,0.6,0.8,1,1,0.8,0.6,0.5],
    "医药":      [0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.4,0.5,0.7,0.9,1,1,0.8,0.6,0.5,0.4],
    "白酒":      [0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5],
    "金融":      [0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6],
    "数据要素":  [0.7,0.8,1,1,1,0.8,0.6,0.5,0.4,0.6,0.8,1,1,0.8,0.6,0.5,0.7,0.9,1,1,0.8,0.6],
    "光伏":      [0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.4],
    "工业母机":  [0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5,0.4,0.5,0.6,0.7,0.8,0.9,1,1,0.8,0.6,0.5],
}

# 市场情绪周期
MARKET_SENTIMENT = [
    60,65,70,75,80,82,78,70,60,55,  # 第1-10天：上升→高潮→回落
    50,45,40,45,55,65,75,80,75,65,  # 第11-20天：冰点→回暖→高潮
    55,50,                           # 第21-22天：震荡
]


class Position:
    """持仓"""
    def __init__(self, code: str, name: str, sector: str, price: float, shares: int, day: int):
        self.code = code
        self.name = name
        self.sector = sector
        self.buy_price = price
        self.shares = shares
        self.buy_day = day
        self.highest = price
        self.current_price = price

    def update(self, price: float):
        self.current_price = price
        if price > self.highest:
            self.highest = price

    @property
    def pnl(self) -> float:
        return (self.current_price - self.buy_price) / self.buy_price * 100

    @property
    def pnl_amount(self) -> float:
        return (self.current_price - self.buy_price) * self.shares

    def get_hold_days(self, current_day: int) -> int:
        return current_day - self.buy_day

    @property
    def market_value(self) -> float:
        return self.current_price * self.shares


class TradeRecord:
    """交易记录"""
    def __init__(self, code, name, sector, buy_price, sell_price, shares, buy_day, sell_day, reason):
        self.code = code
        self.name = name
        self.sector = sector
        self.buy_price = buy_price
        self.sell_price = sell_price
        self.shares = shares
        self.buy_day = buy_day
        self.sell_day = sell_day
        self.reason = reason
        self.pnl_pct = (sell_price - buy_price) / buy_price * 100
        self.pnl_amount = (sell_price - buy_price) * shares


def simulate_day_prices(stocks: list, day: int, seed: int) -> Dict[str, dict]:
    """模拟一天的股票价格（增强版：强板块龙头有超额收益）"""
    random.seed(seed + day * 1000)
    result = {}

    for s in stocks:
        sector = s["sector"]
        cycle = SECTOR_CYCLES.get(sector, [0.5]*22)
        sector_strength = cycle[day % len(cycle)]

        # 板块驱动（放大效应）
        sector_return = (sector_strength - 0.5) * 12  # -6% ~ +6%
        noise = random.gauss(0, s["vol"])
        trend_bias = (s["trend"] - 0.5) * 4  # 趋势偏移放大

        daily_return = sector_return + noise + trend_bias

        # 龙头溢价：强板块中的高趋势股额外加成
        if sector_strength > 0.7 and s["trend"] > 0.55:
            daily_return += random.uniform(1, 4)  # 龙头额外1-4%

        daily_return = max(-10, min(10, daily_return))  # 涨跌停限制

        open_pct = random.gauss(0, 1)
        high_pct = max(daily_return, open_pct) + abs(random.gauss(0, 1.5))
        low_pct = min(daily_return, open_pct) - abs(random.gauss(0, 1.5))

        price = s["base"] * (1 + daily_return / 100)
        open_p = s["base"] * (1 + open_pct / 100)
        high = s["base"] * (1 + high_pct / 100)
        low = s["base"] * (1 + low_pct / 100)

        vol_ratio = abs(1.0 + random.gauss(0, 0.8))
        turnover = abs(10 + random.gauss(0, 8))
        amount = price * random.randint(5000, 50000) * 100

        result[s["code"]] = {
            "price": round(price, 2),
            "open": round(open_p, 2),
            "high": round(high, 2),
            "low": round(low, 2),
            "change_pct": round(daily_return, 2),
            "volume_ratio": round(vol_ratio, 2),
            "turnover": round(turnover, 1),
            "amount": round(amount, 0),
            "sector_strength": round(sector_strength, 2),
        }

    random.seed()
    return result


def score_stock(stock: dict, prices: dict, day: int, sentiment: int) -> int:
    """多因子评分（增强版）"""
    code = stock["code"]
    p = prices.get(code, {})
    if not p:
        return 0

    score = 0
    ss = p.get("sector_strength", 0.5)
    chg = p.get("change_pct", 0)
    vr = p.get("volume_ratio", 1)
    tr = p.get("turnover", 10)
    trend = stock.get("trend", 0.5)

    # 板块强度 (25分) - 最重要
    score += int(ss * 25)

    # 涨幅 (20分) - 强势上涨
    if 3 <= chg <= 8:
        score += 20
    elif chg > 8:
        score += 15
    elif 0 < chg < 3:
        score += 8

    # 量比 (15分) - 放量确认
    if vr >= 2.0:
        score += 15
    elif vr >= 1.5:
        score += 10
    elif vr >= 1.0:
        score += 5

    # 龙头因子 (15分) - 趋势+板块共振
    if trend > 0.55 and ss > 0.7:
        score += 15
    elif trend > 0.5:
        score += 8

    # 情绪共振 (15分)
    if sentiment >= 70:
        score += 15
    elif sentiment >= 55:
        score += 10
    elif sentiment >= 40:
        score += 5

    # 换手率 (10分)
    if 8 <= tr <= 25:
        score += 10
    elif tr > 25:
        score += 3

    return min(100, score)


def run_backtest(
    initial_capital: float = 100000,
    max_positions: int = 3,
    position_pct: float = 0.30,       # 单票仓位
    stop_loss_pct: float = -5.0,      # 止损
    take_profit_pct: float = 10.0,    # 止盈
    max_hold_days: int = 3,           # 最大持仓天数
    min_score: int = 65,              # 最低入场评分
    trading_days: int = 22,           # 交易天数
    seed: int = 42,
) -> Dict:
    """
    运行1个月超短策略回测
    """
    capital = initial_capital
    positions: List[Position] = []
    trades: List[TradeRecord] = []
    daily_equity = []
    max_equity = initial_capital
    max_drawdown = 0
    win_count = 0
    loss_count = 0
    total_pnl = 0

    for day in range(trading_days):
        sentiment = MARKET_SENTIMENT[day % len(MARKET_SENTIMENT)]
        prices = simulate_day_prices(SIM_STOCKS, day, seed)

        # ── 更新持仓 ──
        closed = []
        for pos in positions:
            p = prices.get(pos.code, {})
            if p:
                pos.update(p["price"])
            hold = pos.get_hold_days(day)

            # 卖出判断（含移动止盈）
            sell_reason = None
            if pos.pnl <= stop_loss_pct:
                sell_reason = "止损"
            elif pos.pnl >= take_profit_pct:
                sell_reason = "止盈"
            elif hold >= max_hold_days:
                sell_reason = "超时"
            # 移动止盈：从最高点回撤3%卖出
            elif pos.highest > pos.buy_price * 1.05:
                drawdown_from_high = (pos.current_price - pos.highest) / pos.highest * 100
                if drawdown_from_high <= -3:
                    sell_reason = "移动止盈"
            elif pos.pnl > 0 and p.get("change_pct", 0) < -3:
                sell_reason = "回撤保护"

            if sell_reason:
                trade = TradeRecord(
                    pos.code, pos.name, pos.sector,
                    pos.buy_price, pos.current_price, pos.shares,
                    pos.buy_day, day, sell_reason
                )
                trades.append(trade)
                capital += pos.market_value
                total_pnl += pos.pnl_amount
                if pos.pnl > 0:
                    win_count += 1
                else:
                    loss_count += 1
                closed.append(pos)

        for c in closed:
            positions.remove(c)

        # ── 选股买入 ──
        available_slots = max_positions - len(positions)
        if available_slots > 0:
            candidates = []
            for stock in SIM_STOCKS:
                # 跳过已持仓
                if any(p.code == stock["code"] for p in positions):
                    continue
                sc = score_stock(stock, prices, day, sentiment)
                if sc >= min_score:
                    candidates.append((stock, sc))

            candidates.sort(key=lambda x: x[1], reverse=True)

            for stock, sc in candidates[:available_slots]:
                p = prices.get(stock["code"], {})
                if not p:
                    continue

                buy_price = p["price"]
                max_invest = capital * position_pct
                shares = int(max_invest / buy_price / 100) * 100  # 整手
                if shares < 100:
                    continue

                cost = shares * buy_price
                if cost > capital:
                    continue

                capital -= cost
                pos = Position(stock["code"], stock["name"], stock["sector"], buy_price, shares, day)
                positions.append(pos)

        # ── 计算当日净值 ──
        market_value = sum(p.market_value for p in positions)
        equity = capital + market_value
        daily_equity.append({
            "day": day + 1,
            "equity": round(equity, 2),
            "capital": round(capital, 2),
            "positions": len(positions),
            "sentiment": sentiment,
        })

        if equity > max_equity:
            max_equity = equity
        dd = (max_equity - equity) / max_equity * 100
        if dd > max_drawdown:
            max_drawdown = dd

    # ── 清仓剩余持仓 ──
    final_prices = simulate_day_prices(SIM_STOCKS, trading_days - 1, seed)
    for pos in positions:
        p = final_prices.get(pos.code, {})
        if p:
            pos.update(p["price"])
        trade = TradeRecord(
            pos.code, pos.name, pos.sector,
            pos.buy_price, pos.current_price, pos.shares,
            pos.buy_day, trading_days, "到期清仓"
        )
        trades.append(trade)
        capital += pos.market_value
        total_pnl += pos.pnl_amount
        if pos.pnl > 0:
            win_count += 1
        else:
            loss_count += 1

    # ── 统计 ──
    total_trades = len(trades)
    win_rate = win_count / max(total_trades, 1) * 100
    final_equity = capital
    total_return = (final_equity - initial_capital) / initial_capital * 100

    avg_win = 0
    avg_loss = 0
    if win_count > 0:
        avg_win = sum(t.pnl_pct for t in trades if t.pnl_pct > 0) / win_count
    if loss_count > 0:
        avg_loss = sum(t.pnl_pct for t in trades if t.pnl_pct <= 0) / loss_count

    profit_factor = abs(avg_win * win_count / min(avg_loss * loss_count, -0.01)) if loss_count > 0 else 999

    # 按卖出原因统计
    reason_stats = {}
    for t in trades:
        r = t.reason
        if r not in reason_stats:
            reason_stats[r] = {"count": 0, "win": 0, "total_pnl": 0}
        reason_stats[r]["count"] += 1
        reason_stats[r]["total_pnl"] += t.pnl_amount
        if t.pnl_pct > 0:
            reason_stats[r]["win"] += 1

    # 按板块统计
    sector_stats = {}
    for t in trades:
        s = t.sector
        if s not in sector_stats:
            sector_stats[s] = {"count": 0, "win": 0, "total_pnl": 0}
        sector_stats[s]["count"] += 1
        sector_stats[s]["total_pnl"] += t.pnl_amount
        if t.pnl_pct > 0:
            sector_stats[s]["win"] += 1

    return {
        "summary": {
            "initial_capital": initial_capital,
            "final_equity": round(final_equity, 2),
            "total_return_pct": round(total_return, 2),
            "total_pnl": round(total_pnl, 2),
            "total_trades": total_trades,
            "win_count": win_count,
            "loss_count": loss_count,
            "win_rate_pct": round(win_rate, 1),
            "avg_win_pct": round(avg_win, 2),
            "avg_loss_pct": round(avg_loss, 2),
            "profit_factor": round(profit_factor, 2),
            "max_drawdown_pct": round(max_drawdown, 2),
            "trading_days": trading_days,
        },
        "params": {
            "max_positions": max_positions,
            "position_pct": position_pct,
            "stop_loss_pct": stop_loss_pct,
            "take_profit_pct": take_profit_pct,
            "max_hold_days": max_hold_days,
            "min_score": min_score,
        },
        "reason_stats": reason_stats,
        "sector_stats": sector_stats,
        "daily_equity": daily_equity,
        "trades": [
            {
                "code": t.code, "name": t.name, "sector": t.sector,
                "buy_price": t.buy_price, "sell_price": round(t.sell_price, 2),
                "shares": t.shares, "buy_day": t.buy_day, "sell_day": t.sell_day,
                "reason": t.reason, "pnl_pct": round(t.pnl_pct, 2),
                "pnl_amount": round(t.pnl_amount, 2),
            } for t in trades
        ],
    }


def optimize_params() -> Dict:
    """参数优化：寻找最优参数组合"""
    best = {"return": -999}
    results = []

    # 参数网格搜索
    for max_pos in [2, 3, 4]:
        for pos_pct in [0.25, 0.30, 0.35, 0.40]:
            for sl in [-3, -5, -7]:
                for tp in [8, 10, 12, 15]:
                    for hold in [2, 3, 4]:
                        for min_sc in [55, 60, 65, 70]:
                            for seed in [42, 123, 456, 789]:
                                r = run_backtest(
                                    max_positions=max_pos,
                                    position_pct=pos_pct,
                                    stop_loss_pct=sl,
                                    take_profit_pct=tp,
                                    max_hold_days=hold,
                                    min_score=min_sc,
                                    seed=seed,
                                )
                                s = r["summary"]
                                results.append({
                                    "params": r["params"],
                                    "return": s["total_return_pct"],
                                    "win_rate": s["win_rate_pct"],
                                    "trades": s["total_trades"],
                                    "max_dd": s["max_drawdown_pct"],
                                    "profit_factor": s["profit_factor"],
                                    "seed": seed,
                                })

                                if s["total_return_pct"] > best["return"]:
                                    best = {
                                        "return": s["total_return_pct"],
                                        "win_rate": s["win_rate_pct"],
                                        "trades": s["total_trades"],
                                        "params": r["params"],
                                        "seed": seed,
                                        "max_dd": s["max_drawdown_pct"],
                                        "profit_factor": s["profit_factor"],
                                    }

    # 按收益排序 top 10
    results.sort(key=lambda x: x["return"], reverse=True)

    return {
        "best": best,
        "top10": results[:10],
        "total_combinations": len(results),
    }
