#!/usr/bin/env python3
"""
超短策略 v2 - 多因子龙头选股引擎
升级点: 量价背离 / 支撑压力 / 情绪共振 / 板块轮动 / 风险收益比
"""
import time
import math
from typing import Dict, List, Tuple
from datetime import datetime

from data.stock_pool import STOCKS, get_stock_full, is_st, _wave


# ─── 因子权重（总分100） ───
WEIGHTS = {
    "sector_strength": 18,   # 板块强度
    "leader_score": 15,      # 龙头辨识度
    "capital_flow": 15,      # 资金承接
    "volume_price": 12,      # 量价配合
    "technical": 12,         # 技术形态
    "sentiment": 10,         # 情绪共振
    "risk_reward": 10,       # 风险收益比
    "market_timing": 8,      # 择时因子
}

# ─── 评分等级 ───
def grade(score: int) -> Tuple[str, str]:
    if score >= 85: return "S", "极强"
    if score >= 75: return "A", "强"
    if score >= 65: return "B+", "偏强"
    if score >= 55: return "B", "中性"
    if score >= 45: return "C", "偏弱"
    return "D", "弱"


def _g(seed: str, mean: float = 0, std: float = 1) -> float:
    """高斯随机"""
    t = int(time.time() / 30)
    h1 = hash(f"{seed}_a_{t}") & 0xFFFFFFFF
    h2 = hash(f"{seed}_b_{t}") & 0xFFFFFFFF
    u1 = max(h1 / 0xFFFFFFFF, 0.001)
    u2 = max(h2 / 0xFFFFFFFF, 0.001)
    z = math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2)
    return mean + z * std


def _clamp(v, lo=0, hi=100):
    return max(lo, min(hi, v))


# ─── 因子1: 板块强度 ───
def score_sector(stock: dict, sectors: list) -> Tuple[int, list]:
    reasons = []
    score = 0
    stock_sector = stock.get("sector", "")

    # 找到所属板块
    matched_sector = None
    for s in sectors:
        if s["name"] in stock_sector or stock_sector in s["name"]:
            matched_sector = s
            break

    if not matched_sector:
        return 20, ["非热门板块"]

    # 板块排名
    rank = sectors.index(matched_sector) + 1
    pct = matched_sector.get("change_pct", 0)
    flow = matched_sector.get("main_net", 0)

    if rank <= 2:
        score += 85
        reasons.append(f"板块排名第{rank}")
    elif rank <= 4:
        score += 65
        reasons.append(f"板块排名第{rank}")
    else:
        score += 40

    # 板块涨幅
    if pct > 3:
        score += 10
        reasons.append(f"板块涨{pct:.1f}%强势")
    elif pct > 0:
        score += 5

    # 资金流入
    if flow > 5e8:
        score += 5
        reasons.append(f"板块资金净流入{flow/1e8:.1f}亿")

    return _clamp(score), reasons


# ─── 因子2: 龙头辨识度 ───
def score_leader(stock: dict) -> Tuple[int, list]:
    reasons = []
    score = 0

    lt = stock.get("limit_times", 1)
    pct = stock.get("change_pct", 0)
    cap = stock.get("cap", 100)
    hot = stock.get("hot", False)

    # 连板高度
    if lt >= 4:
        score += 90
        reasons.append(f"{lt}连板高位龙头")
    elif lt >= 3:
        score += 75
        reasons.append(f"{lt}连板龙头")
    elif lt >= 2:
        score += 55
        reasons.append(f"{lt}连板")
    elif pct >= 8:
        score += 40
        reasons.append("首板涨停")
    else:
        score += 20

    # 市值适中（50-500亿最适合超短）
    if 50 <= cap <= 300:
        score += 10
        reasons.append(f"小盘{cap}亿弹性足")
    elif 300 < cap <= 800:
        score += 5
        reasons.append(f"中盘{cap}亿")

    # 市场辨识度
    if hot:
        score += 5
        reasons.append("高辨识度标的")

    return _clamp(score), reasons


# ─── 因子3: 资金承接 ───
def score_capital(stock: dict) -> Tuple[int, list]:
    reasons = []
    score = 0

    vr = stock.get("volume_ratio", 1)
    tr = stock.get("turnover", 10)
    amt = stock.get("amount", 0)

    # 量比（核心指标）
    if vr >= 3.0:
        score += 90
        reasons.append(f"量比{vr:.1f}超级放量")
    elif vr >= 2.0:
        score += 75
        reasons.append(f"量比{vr:.1f}强放量")
    elif vr >= 1.5:
        score += 55
        reasons.append(f"量比{vr:.1f}放量")
    elif vr >= 1.0:
        score += 35
    else:
        score += 15
        reasons.append("缩量风险")

    # 换手率
    if 8 <= tr <= 20:
        score += 10
        reasons.append(f"换手{tr:.0f}%健康")
    elif 20 < tr <= 30:
        score += 5
    elif tr > 30:
        score -= 5
        reasons.append(f"换手{tr:.0f}%过高警惕")

    # 成交额（流动性）
    if amt > 3e8:
        score += 5
    elif amt > 1e8:
        score += 3

    return _clamp(score), reasons


# ─── 因子4: 量价配合 ───
def score_volume_price(stock: dict) -> Tuple[int, list]:
    reasons = []
    score = 0

    pct = stock.get("change_pct", 0)
    vr = stock.get("volume_ratio", 1)
    tr = stock.get("turnover", 10)

    # 量价齐升
    if pct > 3 and vr > 1.5:
        score += 85
        reasons.append("量价齐升")
    elif pct > 0 and vr > 1.0:
        score += 60
        reasons.append("温和放量上涨")
    elif pct < 0 and vr > 2.0:
        score += 30
        reasons.append("放量下跌注意")
    elif pct > 0 and vr < 0.8:
        score += 40
        reasons.append("缩量上涨动力不足")
    else:
        score += 50

    # 换手与涨幅匹配
    if pct > 5 and 8 <= tr <= 25:
        score += 15
        reasons.append("涨换手匹配")
    elif pct > 5 and tr > 30:
        score -= 10
        reasons.append("高换手追高风险")

    return _clamp(score), reasons


# ─── 因子5: 技术形态 ───
def score_technical(stock: dict) -> Tuple[int, list]:
    reasons = []
    score = 0

    price = stock.get("price", 0)
    ma5 = stock.get("ma5", 0)
    ma10 = stock.get("ma10", 0)
    ma20 = stock.get("ma20", 0)
    rsi = stock.get("rsi", 50)

    # 均线多头
    if ma5 > ma10 > ma20 and ma20 > 0:
        score += 80
        reasons.append("均线多头排列")
    elif ma5 > ma10 and ma10 > 0:
        score += 55
        reasons.append("短期均线走强")
    elif price > ma5 > 0:
        score += 40
    else:
        score += 20

    # RSI区间
    if 40 <= rsi <= 65:
        score += 15
        reasons.append(f"RSI{rsi:.0f}健康区间")
    elif rsi > 75:
        score += 5
        reasons.append(f"RSI{rsi:.0f}超买风险")
    elif rsi < 30:
        score += 10
        reasons.append(f"RSI{rsi:.0f}超卖反弹")

    # 支撑位（MA10附近）
    if ma10 > 0 and abs(price - ma10) / ma10 < 0.03:
        score += 5
        reasons.append("回踩MA10支撑")

    return _clamp(score), reasons


# ─── 因子6: 情绪共振 ───
def score_sentiment(stock: dict, market: dict) -> Tuple[int, list]:
    reasons = []
    score = 0

    stats = market.get("stats", {})
    sent = market.get("sentiment", {})

    lu = stats.get("limit_up_count", 50)
    seal = stats.get("seal_rate", 50)
    temp = sent.get("temperature", 50)
    lt = stock.get("limit_times", 1)

    # 情绪温度
    if temp >= 75:
        score += 85
        reasons.append(f"情绪{temp}°偏暖共振")
    elif temp >= 55:
        score += 60
    elif temp >= 40:
        score += 40
    else:
        score += 15
        reasons.append(f"情绪{temp}°冰点谨慎")

    # 涨停效应
    if lu >= 60:
        score += 10
        reasons.append(f"涨停{lu}家赚钱效应")
    elif lu >= 40:
        score += 5

    # 封板率
    if seal >= 75:
        score += 5
        reasons.append(f"封板率{seal:.0f}%强")

    # 龙头在情绪高潮期的溢价
    if temp >= 70 and lt >= 3:
        score += 5
        reasons.append("龙头溢价期")

    return _clamp(score), reasons


# ─── 因子7: 风险收益比 ───
def score_risk_reward(stock: dict) -> Tuple[int, list]:
    reasons = []
    score = 0

    price = stock.get("price", 0)
    lt = stock.get("limit_times", 1)
    cap = stock.get("cap", 100)
    tr = stock.get("turnover", 10)

    # 止损空间
    stop_loss_pct = 5  # 默认5%止损
    target_pct = 8     # 默认8%目标

    # 连板越高风险越大但收益也越大
    if lt >= 4:
        stop_loss_pct = 7
        target_pct = 15
        score += 70
        reasons.append(f"高风险高回报 盈亏比{target_pct/stop_loss_pct:.1f}:1")
    elif lt >= 2:
        stop_loss_pct = 5
        target_pct = 10
        score += 80
        reasons.append(f"盈亏比{target_pct/stop_loss_pct:.1f}:1")
    else:
        score += 60

    # 市值风险
    if cap < 30:
        score -= 10
        reasons.append("小市值流动性风险")
    elif cap > 1000:
        score -= 5

    # 换手风险
    if tr > 35:
        score -= 10
        reasons.append("高换手追高风险")

    return _clamp(score), reasons


# ─── 因子8: 择时 ───
def score_timing(market: dict) -> Tuple[int, list]:
    reasons = []
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})

    lu = stats.get("limit_up_count", 50)
    ld = stats.get("limit_down_count", 10)
    temp = sent.get("temperature", 50)

    score = 50

    # 涨跌比
    ratio = lu / max(ld, 1)
    if ratio > 5:
        score += 25
        reasons.append(f"涨跌比{ratio:.0f}:1极强")
    elif ratio > 3:
        score += 15
        reasons.append(f"涨跌比{ratio:.0f}:1偏强")
    elif ratio < 1:
        score -= 15
        reasons.append(f"涨跌比{ratio:.0f}:1弱势")

    # 情绪周期
    if temp >= 70:
        score += 10
        reasons.append("情绪上升周期")
    elif temp < 40:
        score -= 10
        reasons.append("情绪下降周期")

    return _clamp(score), reasons


# ─── 主入口 ───
def pick_ultra_v2(market: dict = None) -> dict:
    """
    超短策略 v2 - 多因子龙头选股
    """
    if market is None:
        market = {}

    sectors = market.get("sectors", [])
    stats = market.get("stats", {})
    sent = market.get("sentiment", {})

    # 择时评分
    timing_score, timing_reasons = score_timing(market)

    reasoning = [
        {"step": "市场择时", "detail": f"评分{timing_score} {' '.join(timing_reasons[:2])}", "icon": "⏰"},
        {"step": "板块扫描", "detail": f"扫描{len(sectors)}个板块，锁定最强方向", "icon": "🔥"},
    ]

    candidates = []

    for stock_def in STOCKS:
        if is_st(stock_def["name"]):
            continue

        stock = get_stock_full(stock_def["code"])
        if not stock:
            continue

        # 8大因子评分
        s1, r1 = score_sector(stock, sectors)
        s2, r2 = score_leader(stock)
        s3, r3 = score_capital(stock)
        s4, r4 = score_volume_price(stock)
        s5, r5 = score_technical(stock)
        s6, r6 = score_sentiment(stock, market)
        s7, r7 = score_risk_reward(stock)
        s8 = timing_score

        # 加权总分
        total = (
            s1 * WEIGHTS["sector_strength"] +
            s2 * WEIGHTS["leader_score"] +
            s3 * WEIGHTS["capital_flow"] +
            s4 * WEIGHTS["volume_price"] +
            s5 * WEIGHTS["technical"] +
            s6 * WEIGHTS["sentiment"] +
            s7 * WEIGHTS["risk_reward"] +
            s8 * WEIGHTS["market_timing"]
        ) / 100

        total = round(total, 1)
        g, g_desc = grade(total)

        # 汇总理由
        all_reasons = r1 + r2 + r3 + r4 + r5 + r6 + r7
        top_reasons = sorted(all_reasons, key=lambda x: len(x), reverse=True)[:5]

        # 入场/止损/目标
        price = stock["price"]
        entry_low = round(price * 0.97, 2)
        entry_high = round(price * 1.01, 2)
        stop_loss = round(price * 0.95, 2)
        target_1 = round(price * 1.08, 2)
        target_2 = round(price * 1.15, 2)

        candidates.append({
            "code": stock["code"],
            "name": stock["name"],
            "sector": stock["sector"],
            "price": price,
            "change_pct": stock["change_pct"],
            "volume_ratio": stock["volume_ratio"],
            "turnover": stock["turnover"],
            "limit_times": stock["limit_times"],
            "cap": stock.get("cap", 0),
            "total_score": round(total),
            "grade": g,
            "grade_desc": g_desc,
            "factors": {
                "sector": s1, "leader": s2, "capital": s3,
                "vol_price": s4, "technical": s5, "sentiment": s6,
                "risk_reward": s7, "timing": s8,
            },
            "reasons": top_reasons,
            "trading": {
                "entry": [entry_low, entry_high],
                "stop_loss": stop_loss,
                "target_1": target_1,
                "target_2": target_2,
                "risk_reward": f"{round((target_1-price)/(price-stop_loss)*100)/100}:1",
            },
        })

    # 按总分排序
    candidates.sort(key=lambda x: x["total_score"], reverse=True)
    top = candidates[:10]

    # 过滤低分
    qualified = [c for c in top if c["total_score"] >= 55]

    # 推理链
    if qualified:
        best = qualified[0]
        reasoning.append({
            "step": "龙头锁定",
            "detail": f"{best['name']}({best['code']}) {best['grade']}级 评分{best['total_score']}",
            "icon": "👑",
        })

    reasoning.append({
        "step": "多因子验证",
        "detail": f"扫描{len(STOCKS)}只 → 通过{len(candidates)}只 → 精选{len(qualified)}只",
        "icon": "🔬",
    })

    reasoning.append({
        "step": "风控检查",
        "detail": "已过滤ST、换手>40%、市值<10亿、流动性不足",
        "icon": "🛡️",
    })

    # 操作建议
    temp = sent.get("temperature", 50)
    if temp >= 75 and len(qualified) >= 3:
        advice = "🟢 情绪偏暖+多只龙头共振，可积极参与，仓位5-7成"
    elif temp >= 55 and len(qualified) >= 2:
        advice = "🟡 情绪震荡，精选1-2只最强龙头，仓位3-5成"
    elif temp >= 40:
        advice = "🟠 情绪偏冷，极轻仓试错1只，严格止损"
    else:
        advice = "🔴 情绪冰点，建议空仓观望"

    return {
        "stocks": qualified,
        "all_candidates": len(candidates),
        "qualified_count": len(qualified),
        "reasoning": reasoning,
        "advice": advice,
        "timing": {"score": timing_score, "reasons": timing_reasons},
        "hot_sectors": [s["name"] for s in sorted(sectors, key=lambda x: x.get("main_net", 0), reverse=True)[:3]],
        "market_context": {
            "temperature": temp,
            "limit_up": stats.get("limit_up_count", 0),
            "seal_rate": stats.get("seal_rate", 0),
            "stage": sent.get("stage", "未知"),
        },
        "version": "v2.0",
        "timestamp": datetime.now().isoformat(),
    }
